# Copilot Instructions for EmerEviro

## Purpose
EmerEviro is a research framework for measuring **structural emergence** in learning agents. It's a "pressure chamber" where agents can invent and reuse mathematical abstractions (primitives) under constrained capacity and budget.

## Architecture Overview

### The Bus: Protocol-First Design
Everything crosses through a single protocol boundary: **EnvironmentBus**. This is the critical architectural insight.

- **Agent side**: Subclass `AgentClient`, override `select_action(obs: Observation) → Action`
- **Environment side**: Implement dynamics for math tasks
- **Protocol**: Three schemas define the entire interface:
  - `Action` (agent → env): tier + payload dict
  - `Observation` (env → agent): task, library, budget, atoms
  - `StepResult` (env → agent): next observation + reward

See [bus.py](bus.py) and [schemas.py](schemas.py) — every agent and environment must speak this language.

### Core Components

| Component | Purpose | Key Insight |
|-----------|---------|-------------|
| [math_env.py](math_env.py) | Task generation + library management | Hidden invariants (distributivity, factoring) never exposed to agent; surface varies (vars, ordering, coefficients) to defeat surface-level shortcuts |
| [bus.py](bus.py) | Agent ↔ Environment boundary | Validates actions, routes observations; only passage between domains |
| [schemas.py](schemas.py) | Protocol contract | Action tiers (ASSEMBLE 0.05¢, MUTATE 0.30¢, MINT 1.00¢); capacity-constrained library (50 AST nodes max) |
| [null_models.py](null_models.py) | Ablation baselines | Three precise ablations: no persistence, no minting, no structure — emergence claimed only if candidate beats **all three** |
| [tracker.py](tracker.py) | Emergence metrics | Reuse Rate, BCG (Behavioral Compression Gain), Time-to-Stability |
| [run_experiment.py](run_experiment.py) | Harness | Wires environment → bus → agent → metrics; runs comparison suite |

## The Economics Model

**Agents have a budget and compete for library capacity:**

1. **Action tiers** (costs deducted from `budget_remaining` per episode):
   - **ASSEMBLE** (0.05¢): Combine existing primitives/atoms → new solution
   - **MUTATE** (0.30¢): Edit/perturb an existing primitive
   - **MINT** (1.00¢): Define a new primitive (uses library capacity)

2. **Library capacity** (hard limit 50 AST nodes):
   - Each primitive costs its AST node count
   - Reuse is free (never punished)
   - Storage rent is implicit in capacity scarcity

3. **Reward**: Task performance minus action costs; episodic budget (~5.0¢) limits total steps/episode

## Adding an Agent

All agents inherit from `AgentClient`:

```python
class MyAgent(AgentClient):
    def __init__(self, bus: EnvironmentBus):
        super().__init__(bus)
        # your state here
    
    def select_action(self, obs: Observation) -> Action:
        # obs.task: {input, target, variables, atoms}
        # obs.library: [LibraryEntry(id, canonical_form, size, use_count)]
        # obs.capacity_used, obs.capacity_total
        # obs.budget_remaining
        return Action(
            tier=ActionTier.ASSEMBLE,  # or MUTATE, MINT
            payload={...}  # tier-specific dict
        )
```

**Payload formats by tier:**
- `ASSEMBLE`: `{"op": "combine", "primitives": ["id1", "id2"], "result": "expr", "used_library_primitive": True/False}`
- `MUTATE`: `{"op": "mutate", "primitive_id": "pid", "edits": [...]}`
- `MINT`: `{"op": "mint", "definition": expr_obj, "name": "label"}`

Register in [CONFIG.md](CONFIG.md): set `ACTIVE_AGENT = "candidate"` and point `CUSTOM_AGENT_PATH` if needed.

### Using BioRAG Agents (5/6-pillar Cognitive Architecture)

The `deployable_biorag_hybrids/` folder contains sophisticated agents (Quint/Sext) with 5-6 cognitive pillars:
1. **CME** (Constrained Memory)
2. **Bandit** (Thompson Sampling)
3. **TFE** (Temporal Field Engine)
4. **PEE** (Prediction Error Engine)
5. **BioRAG** (Biological Retrieval-Augmented Generation)
6. **PFC** (Prefrontal Cortex — impulse control, Sext only)

Use adapters in [agents/biorag_adapters.py](agents/biorag_adapters.py) to bridge them into EmerEviro:

```python
from deployable_biorag_hybrids.quint_biorag import QuintBioRAGAgent
from agents.biorag_adapters import QuintBioRAGAdapter

native_agent = QuintBioRAGAgent(seed=42)
adapter = QuintBioRAGAdapter(bus, native_agent, seed=42)
```

The adapter handles:
- Converting `Observation` → `(condition_dict, available_actions)` 
- Calling native `choose_action()` 
- Mapping results back to EmerEviro `Action` tier + payload
- Tracking library reuse for metrics

See [BIORAG_INTEGRATION.md](BIORAG_INTEGRATION.md) for full setup.

## Task Generation & Hidden Structure

[math_env.py](math_env.py) / `TaskGenerator`:
- **Domain**: Algebraic expression simplification (e.g., expand → factor)
- **Hidden invariants** (never exposed): Commutativity, distributivity, binomial expansion, etc.
- **Surface variation** (to avoid shortcuts): Variable names rotate through pools ([x,y,z], [a,b,c], [u,v,w], [p,q,r]), coefficients vary, term ordering varies
- **Multi-generator probes** (CONFIG: `RUN_LEAKAGE_PROBE`): Swap generator style mid-run to detect if agent learned deep invariants vs. surface patterns

## Null Models: The Emergence Threshold

**Emergence is claimed only when the candidate beats all three nulls on:**
- Mean reward, reuse rate, BCG, cross-generator transfer

| Null | Ablation | What it Tests |
|------|----------|---------------|
| **A** (Library Reset) | Persistence wipes every episode | Is long-term memory necessary? |
| **B** (No Minting) | Assembly + existing library only | Are tasks solvable without abstraction? |
| **C** (Episodic Memory) | Persistent cache, no compositional library | Does structure help over raw caching? |

See [null_models.py](null_models.py) — each is a precise removal of one capability.

## Metrics & Signals

[tracker.py](tracker.py) computes:
1. **Reuse Rate**: Fraction of steps invoking a library primitive (compositional reuse indicator)
2. **BCG**: DL(no library) − DL(with library); approximated via entropy of action vocabulary
3. **Time-to-Stability**: Episodes until per-episode reward variance drops below threshold (convergence speed)
4. **Counterfactual Avoidance** (planned): Does agent avoid actions it has seen fail?

## Configuration & Running

[CONFIG.md](CONFIG.md) is the control panel:
- `EPISODES`, `PROBE_INTERVAL`, `CAPACITY_TOTAL`, `EPISODE_BUDGET`
- Action costs, compression thresholds
- Agent selection (`ACTIVE_AGENT`), task generator style (`GENERATOR_STYLE`)
- Which nulls to run, which metrics to report

Run:
```bash
python run_experiment.py
```

## Common Patterns & Conventions

1. **State in Observation**: Never store state on environment — read from `obs` every step. Bus resets episode state automatically.
2. **Payload dicts**: Use `payload.get()` defensively; schemas document expected keys but are flexible.
3. **Library reuse signal**: `used_library_primitive: True` in payload flags metrics tracking.
4. **Probes don't block agents**: `bus.probe()` called by harness only, not by agent during episode.
5. **AST node counting**: Capacity tracking is exact (sympy AST walk). Always check `capacity_used` before MINT.

## Known Limitations & Next Steps

- **NullA** (Library Reset): Env-side reset hook not yet wired (TODO)
- **BCG computation**: Fixed, but verify `used_library_primitive` flag flows through all agent types
- **Multi-generator leakage probe**: Harness stub exists; needs second generator instance in environment
- **Scaling**: Math domain MVP only; generalization to other domains (symbolic logic, compression) requires task interface redesign
