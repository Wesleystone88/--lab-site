const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  AlignmentType, HeadingLevel, BorderStyle, WidthType, ShadingType,
  VerticalAlign, PageNumber, PageBreak, LevelFormat, Header, Footer,
  TabStopType, TabStopPosition
} = require('docx');
const fs = require('fs');

const data = JSON.parse(fs.readFileSync('/tmp/observatory_data.json', 'utf8'));

// ─── PALETTE ───────────────────────────────────────────────
const C = {
  black:      '111111',
  dark:       '1A1A2E',
  accent:     '0F4C75',
  accent2:    '1B6CA8',
  highlight:  'E8F4FD',
  green:      '1B7A4E',
  greenLight: 'E8F5EE',
  red:        'B91C1C',
  redLight:   'FEE2E2',
  amber:      'B45309',
  amberLight: 'FEF3C7',
  grey:       '6B7280',
  greyLight:  'F3F4F6',
  white:      'FFFFFF',
  rule:       'D1D5DB',
};

// ─── HELPERS ───────────────────────────────────────────────
const sp = (n) => new Paragraph({ children: [new TextRun({ text: '', size: n })] });
const rule = () => new Paragraph({
  border: { bottom: { style: BorderStyle.SINGLE, size: 2, color: C.rule } },
  spacing: { before: 80, after: 80 },
  children: [],
});

const cell = (children, opts = {}) => new TableCell({
  borders: {
    top:    { style: BorderStyle.SINGLE, size: 1, color: C.rule },
    bottom: { style: BorderStyle.SINGLE, size: 1, color: C.rule },
    left:   { style: BorderStyle.SINGLE, size: 1, color: C.rule },
    right:  { style: BorderStyle.SINGLE, size: 1, color: C.rule },
  },
  margins: { top: 100, bottom: 100, left: 140, right: 140 },
  width:  opts.width  ? { size: opts.width, type: WidthType.DXA } : undefined,
  shading: opts.fill  ? { fill: opts.fill, type: ShadingType.CLEAR } : undefined,
  verticalAlign: VerticalAlign.CENTER,
  children: Array.isArray(children) ? children : [children],
});

const txt = (text, opts = {}) => new TextRun({
  text: String(text),
  size: opts.size || 20,
  bold: opts.bold || false,
  color: opts.color || C.black,
  font: opts.mono ? 'Courier New' : 'Calibri',
  italics: opts.italic || false,
});

const para = (children, opts = {}) => new Paragraph({
  alignment: opts.center ? AlignmentType.CENTER : AlignmentType.LEFT,
  spacing: { before: opts.before || 0, after: opts.after || 60 },
  indent: opts.indent ? { left: opts.indent } : undefined,
  children: Array.isArray(children) ? children : [children],
});

// Accuracy bar: uses block chars
const accBar = (acc) => {
  const filled = Math.round(acc * 12);
  const empty  = 12 - filled;
  return '█'.repeat(filled) + '░'.repeat(empty);
};

// Q-value color
const qColor = (q) => q >= 0.8 ? C.green : q >= 0.5 ? C.accent : C.red;
const qBg    = (q) => q >= 0.8 ? C.greenLight : q >= 0.5 ? C.highlight : C.redLight;

// ─── SECTION BUILDERS ──────────────────────────────────────

function buildCoverPage() {
  return [
    sp(120),
    para([txt('EMERGENCE ARTIFACT REPORT', { size: 40, bold: true, color: C.accent })], { center: true }),
    sp(20),
    para([txt('Observable Evidence of Non-LLM Intelligence', { size: 26, italic: true, color: C.grey })], { center: true }),
    sp(60),
    rule(),
    sp(40),
    para([txt('Agent Architecture: SextBioRAG — 6-Pillar Cognitive System', { size: 22, color: C.dark })], { center: true }),
    sp(20),
    para([txt('Three Hidden-Rule Scenarios  ·  300 Episodes Each  ·  Zero Prompting', { size: 20, color: C.grey })], { center: true }),
    sp(200),
    // Summary box
    new Table({
      width: { size: 7200, type: WidthType.DXA },
      columnWidths: [2400, 2400, 2400],
      rows: [
        new TableRow({ children: [
          cell(para([txt('TRIAGE', { bold: true, size: 20, color: C.white })], { center: true }), { fill: C.accent,  width: 2400 }),
          cell(para([txt('NAVIGATION', { bold: true, size: 20, color: C.white })], { center: true }), { fill: C.accent2, width: 2400 }),
          cell(para([txt('DIAGNOSIS', { bold: true, size: 20, color: C.white })], { center: true }), { fill: C.green,  width: 2400 }),
        ]}),
        new TableRow({ children: [
          cell(para([txt('100% final accuracy', { size: 20, color: C.dark })], { center: true }), { fill: C.highlight, width: 2400 }),
          cell(para([txt('100% final accuracy', { size: 20, color: C.dark })], { center: true }), { fill: C.highlight, width: 2400 }),
          cell(para([txt('98% final accuracy', { size: 20, color: C.dark })], { center: true }), { fill: C.highlight, width: 2400 }),
        ]}),
        new TableRow({ children: [
          cell(para([txt('Converged ep. 60', { size: 18, color: C.grey })], { center: true }), { fill: C.white, width: 2400 }),
          cell(para([txt('Converged ep. 10', { size: 18, color: C.grey })], { center: true }), { fill: C.white, width: 2400 }),
          cell(para([txt('Converged ep. 90', { size: 18, color: C.grey })], { center: true }), { fill: C.white, width: 2400 }),
        ]}),
      ]
    }),
    sp(200),
    para([txt('No gradient descent. No prompting. No LLM.', { size: 22, bold: true, color: C.accent })], { center: true }),
    para([txt('Pattern discovery through biological memory dynamics.', { size: 20, italic: true, color: C.grey })], { center: true }),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

function buildIntro() {
  return [
    new Paragraph({ heading: HeadingLevel.HEADING_1, children: [txt('What This Document Is', { bold: true, size: 28, color: C.dark })] }),
    sp(10),
    para([
      txt('This is not a benchmark score. It is ', { size: 22 }),
      txt('evidence', { size: 22, bold: true, color: C.accent }),
      txt('. The agent shown here — SextBioRAG — was given a scenario with hidden rules and a task. It started knowing nothing. This document shows what it learned, how it learned it, and what its internal state looks like after 300 episodes of experience.', { size: 22 }),
    ], { after: 120 }),
    para([
      txt('The agent has no language model. No prompt. No fine-tuning. It learns through six cognitive pillars inspired by biological neuroscience:', { size: 22 }),
    ], { after: 80 }),
    new Table({
      width: { size: 9000, type: WidthType.DXA },
      columnWidths: [1600, 7400],
      rows: [
        ['Pillar 1 — CME',    'Constrained Memory Engine. Declarative rule memory with hard blocks.'],
        ['Pillar 2 — Bandit', 'Thompson Sampling. Procedural action selection under uncertainty.'],
        ['Pillar 3 — TFE',    'Temporal Field Engine. Time-aware staleness and recency weighting.'],
        ['Pillar 4 — PEE',    'Prediction Error Engine. Dopaminergic surprise signal.'],
        ['Pillar 5 — BioRAG', 'Hopfield attractor network. Episodic memory via energy landscape dynamics.'],
        ['Pillar 6 — PFC',    'Prefrontal Cortex. Impulse control and metacognitive self-calibration.'],
      ].map((row, i) => new TableRow({ children: [
        cell(para([txt(row[0], { bold: true, size: 19, color: C.accent })]), { fill: i % 2 ? C.greyLight : C.white, width: 1600 }),
        cell(para([txt(row[1], { size: 19 })]), { fill: i % 2 ? C.greyLight : C.white, width: 7400 }),
      ]})),
    }),
    sp(40),
    para([
      txt('Each scenario below has a set of ', { size: 22 }),
      txt('hidden invariants', { size: 22, bold: true }),
      txt(' — rules the agent must discover through experience alone. The agent is never told the rules. The surface (variable names, specific values) changes each episode. Only the underlying pattern stays constant.', { size: 22 }),
    ], { after: 120 }),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

function buildScenario(key) {
  const d = data[key];
  const sc_colors = {
    triage:     { h: C.accent,  hl: C.highlight },
    navigation: { h: C.accent2, hl: C.highlight },
    diagnosis:  { h: C.green,   hl: C.greenLight },
  };
  const col = sc_colors[key] || sc_colors.triage;
  const sections = [];

  // ── HEADER ─────────────────────────────────────────────
  sections.push(
    new Paragraph({ heading: HeadingLevel.HEADING_1, children: [
      txt(`Scenario: ${d.display.toUpperCase()}`, { bold: true, size: 30, color: col.h })
    ]}),
    para([txt(`${d.n_episodes} episodes  ·  Final accuracy: ${Math.round(d.final_accuracy * 100)}%  ·  Converged: episode ${d.convergence_episode}`,
      { size: 19, color: C.grey })], { after: 80 }),
    rule(),
    sp(20),
  );

  // ── HIDDEN RULES ────────────────────────────────────────
  sections.push(
    new Paragraph({ heading: HeadingLevel.HEADING_2, children: [txt('Hidden Rules (agent never sees these)', { bold: true, size: 23, color: C.dark })] }),
    sp(10),
  );
  d.hidden_rules.forEach(rule_text => {
    sections.push(para([
      txt('▸  ', { bold: true, color: col.h, size: 20 }),
      txt(rule_text, { size: 20 }),
    ], { indent: 360, after: 40 }));
  });
  sections.push(sp(40));

  // ── COLD vs LEARNED ─────────────────────────────────────
  sections.push(
    new Paragraph({ heading: HeadingLevel.HEADING_2, children: [txt('Before vs. After', { bold: true, size: 23, color: C.dark })] }),
    para([txt('The same three contexts, tested on episode 0 (cold) and episode 300 (learned).', { size: 20, italic: true, color: C.grey })], { after: 60 }),
  );

  const tcRows = [
    new TableRow({
      tableHeader: true,
      children: [
        cell(para([txt('Context', { bold: true, size: 19, color: C.white })]), { fill: col.h, width: 2800 }),
        cell(para([txt('Correct Answer', { bold: true, size: 19, color: C.white })], { center: true }), { fill: col.h, width: 1800 }),
        cell(para([txt('Episode 0 (Cold)', { bold: true, size: 19, color: C.white })], { center: true }), { fill: col.h, width: 2000 }),
        cell(para([txt('Episode 300 (Learned)', { bold: true, size: 19, color: C.white })], { center: true }), { fill: col.h, width: 2400 }),
      ]
    })
  ];

  d.test_cases.forEach((tc, i) => {
    const ctxStr = Object.entries(tc.ctx).map(([k,v]) => `${k}=${v}`).join('  ');
    const coldOk = tc.cold_chosen === tc.correct;
    const learnOk = tc.learned_correct;
    tcRows.push(new TableRow({ children: [
      cell(para([txt(ctxStr, { size: 17, mono: true })]), { fill: i%2 ? C.greyLight : C.white, width: 2800 }),
      cell(para([txt(tc.correct, { bold: true, size: 18, color: col.h })], { center: true }), { fill: i%2 ? C.greyLight : C.white, width: 1800 }),
      cell(para([
        txt(coldOk ? '✓ ' : '✗ ', { bold: true, color: coldOk ? C.green : C.red, size: 19 }),
        txt(tc.cold_chosen, { size: 18 }),
      ], { center: true }), { fill: i%2 ? C.greyLight : C.white, width: 2000 }),
      cell(para([
        txt(learnOk ? '✓ ' : '✗ ', { bold: true, color: learnOk ? C.green : C.red, size: 19 }),
        txt(tc.learned_chosen, { size: 18, bold: learnOk }),
        txt(learnOk ? '  (via ' + tc.learned_source + ')' : '', { size: 15, color: C.grey, italic: true }),
      ], { center: true }), { fill: i%2 ? C.greyLight : C.white, width: 2400 }),
    ]}));
  });

  sections.push(
    new Table({ width: { size: 9000, type: WidthType.DXA }, columnWidths: [2800, 1800, 2000, 2400], rows: tcRows }),
    sp(40),
  );

  // ── LEARNING CURVE ──────────────────────────────────────
  sections.push(
    new Paragraph({ heading: HeadingLevel.HEADING_2, children: [txt('Learning Curve', { bold: true, size: 23, color: C.dark })] }),
    para([txt('Accuracy per 10-episode window. Watch the agent go from random to confident.', { size: 20, italic: true, color: C.grey })], { after: 40 }),
  );

  const curveRows = [
    new TableRow({ tableHeader: true, children: [
      cell(para([txt('Episodes', { bold: true, size: 18, color: C.white })]), { fill: col.h, width: 1400 }),
      cell(para([txt('Accuracy', { bold: true, size: 18, color: C.white })]), { fill: col.h, width: 4800 }),
      cell(para([txt('%', { bold: true, size: 18, color: C.white })], { center: true }), { fill: col.h, width: 1000 }),
    ]})
  ];

  d.accuracy_windows.forEach((w, i) => {
    const bar = accBar(w.acc);
    const barColor = w.acc >= 0.9 ? C.green : w.acc >= 0.5 ? C.amber : C.red;
    const bg = i % 2 ? C.greyLight : C.white;
    curveRows.push(new TableRow({ children: [
      cell(para([txt(`${w.start}–${w.end}`, { size: 17, mono: true })]), { fill: bg, width: 1400 }),
      cell(para([txt(bar, { size: 17, mono: true, color: barColor })]), { fill: bg, width: 4800 }),
      cell(para([txt(`${Math.round(w.acc*100)}%`, { bold: w.acc >= 0.9, size: 18, color: barColor })], { center: true }), { fill: bg, width: 1000 }),
    ]}));
  });

  sections.push(
    new Table({ width: { size: 7200, type: WidthType.DXA }, columnWidths: [1400, 4800, 1000], rows: curveRows }),
    sp(40),
  );

  // ── LEARNED POLICY ──────────────────────────────────────
  sections.push(
    new Paragraph({ heading: HeadingLevel.HEADING_2, children: [txt('Learned Policy (Bandit Q-Values)', { bold: true, size: 23, color: C.dark })] }),
    para([txt('What the Thompson Sampling bandit now believes about each context. Q-values are posterior means of Beta distributions — not hard-coded, not prompted. Earned.', { size: 20, italic: true, color: C.grey })], { after: 60 }),
  );

  const policyEntries = Object.entries(d.policy);
  if (policyEntries.length > 0) {
    const pRows = [
      new TableRow({ tableHeader: true, children: [
        cell(para([txt('Context', { bold: true, size: 18, color: C.white })]), { fill: col.h, width: 3800 }),
        cell(para([txt('Top Choice', { bold: true, size: 18, color: C.white })], { center: true }), { fill: col.h, width: 1800 }),
        cell(para([txt('Q-Value', { bold: true, size: 18, color: C.white })], { center: true }), { fill: col.h, width: 1200 }),
        cell(para([txt('Confidence', { bold: true, size: 18, color: C.white })], { center: true }), { fill: col.h, width: 2200 }),
      ]})
    ];

    policyEntries.slice(0, 12).forEach(([ctx, actions], i) => {
      const sorted = Object.entries(actions).sort((a,b) => b[1]-a[1]);
      const [topAction, topQ] = sorted[0];
      const bar = '█'.repeat(Math.round(topQ * 10)) + '░'.repeat(10 - Math.round(topQ * 10));
      const bg = i % 2 ? C.greyLight : C.white;
      pRows.push(new TableRow({ children: [
        cell(para([txt(ctx, { size: 16, mono: true })]), { fill: bg, width: 3800 }),
        cell(para([txt(topAction, { bold: true, size: 18, color: qColor(topQ) })], { center: true }), { fill: bg, width: 1800 }),
        cell(para([txt(topQ.toFixed(3), { bold: true, size: 18, color: qColor(topQ) })], { center: true }), { fill: bg, width: 1200 }),
        cell(para([txt(bar, { mono: true, size: 16, color: qColor(topQ) })]), { fill: bg, width: 2200 }),
      ]}));
    });

    sections.push(
      new Table({ width: { size: 9000, type: WidthType.DXA }, columnWidths: [3800, 1800, 1200, 2200], rows: pRows }),
      sp(20),
    );
  }

  sections.push(sp(60), new Paragraph({ children: [new PageBreak()] }));
  return sections;
}

function buildConclusion() {
  return [
    new Paragraph({ heading: HeadingLevel.HEADING_1, children: [txt('What This Demonstrates', { bold: true, size: 28, color: C.dark })] }),
    sp(10),
    para([
      txt('The agent you just watched is not a language model. It has no transformer weights, no token embeddings, no attention heads. It cannot be prompted. It does not use few-shot examples or chain-of-thought reasoning. ', { size: 22 }),
    ], { after: 80 }),
    para([
      txt('What it has instead:', { size: 22, bold: true }),
    ], { after: 40 }),
    ...([
      ['Hopfield Attractor Memory', 'Queries fall into the nearest energy basin. Retrieval is convergence dynamics, not lookup. The memory landscape is shaped by experience.'],
      ['Dopaminergic Surprise Signal', 'The PEE publishes encoding weight to the signal bus. High-surprise outcomes get deeper hippocampal encoding — exactly like emotional memory consolidation.'],
      ['Competitive Action Selection', 'Thompson Sampling maintains Beta distributions over every action in every context. Uncertainty drives exploration early; confidence drives exploitation late.'],
      ['Impulse Control', 'The PFC layer vetoes low-confidence actions before they execute. This is why Sext outperforms Quint — the 6th pillar stops the Bandit from wasting budget.'],
      ['Zero Prompting', 'Every Q-value in every policy table above was earned from binary outcome feedback alone. Correct/incorrect. Nothing else.'],
    ].map(([title, desc]) =>
      para([
        txt(`${title}: `, { bold: true, size: 21, color: C.accent }),
        txt(desc, { size: 21 }),
      ], { indent: 400, after: 60 })
    )),
    sp(60),
    rule(),
    sp(40),
    para([
      txt('The environment engine this runs inside is designed to grow. Each new environment is a plugin — one class, four methods. The agent plugs into any of them through the bus protocol. Results are structured and comparable across runs, environments, and agents. ', { size: 22 }),
    ], { after: 80 }),
    para([
      txt('This is the foundation. The artifact you are reading is what the first version already produces.', { size: 22, bold: true, color: C.accent }),
    ]),
  ];
}

// ─── ASSEMBLE DOCUMENT ─────────────────────────────────────
const allChildren = [
  ...buildCoverPage(),
  ...buildIntro(),
  ...buildScenario('triage'),
  ...buildScenario('navigation'),
  ...buildScenario('diagnosis'),
  ...buildConclusion(),
];

const doc = new Document({
  styles: {
    default: {
      document: { run: { font: 'Calibri', size: 22 } },
    },
    paragraphStyles: [
      {
        id: 'Heading1', name: 'Heading 1', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run:  { size: 30, bold: true, font: 'Calibri', color: C.dark },
        paragraph: { spacing: { before: 320, after: 160 }, outlineLevel: 0 },
      },
      {
        id: 'Heading2', name: 'Heading 2', basedOn: 'Normal', next: 'Normal', quickFormat: true,
        run:  { size: 24, bold: true, font: 'Calibri', color: C.dark },
        paragraph: { spacing: { before: 240, after: 120 }, outlineLevel: 1 },
      },
    ],
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1080, right: 1080, bottom: 1080, left: 1080 },
      },
    },
    footers: {
      default: new Footer({
        children: [
          new Paragraph({
            alignment: AlignmentType.CENTER,
            children: [
              new TextRun({ text: 'EmerEviro · Emergence Observatory · SextBioRAG Report  ', size: 16, color: C.grey }),
              new TextRun({ children: [PageNumber.CURRENT], size: 16, color: C.grey }),
            ],
          }),
        ],
      }),
    },
    children: allChildren,
  }],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync('/mnt/user-data/outputs/emergence_artifact_report.docx', buf);
  console.log('Done: emergence_artifact_report.docx');
});
