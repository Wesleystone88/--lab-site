"""
IQ Pattern Observatory
======================
Run the agent through high-IQ patterns.
Produce an artifact that shows the work — not the score.

Output: five snapshots at episodes 1, 10, 50, 100, 200+
Each snapshot shows:
    - What the problem was (exactly as presented)
    - What choices were available
    - What the agent chose
    - What was correct
    - Right or wrong — you can see it immediately
"""

import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, 'agents/deployable_biorag_hybrids')

from environments.iq_patterns import IQPatternEnv, INVARIANT_CLASSES
from agents.deployable_biorag_hybrids.sext_biorag import SextBioRAGAgent
from bus.schemas import Action, ActionTier


def run_iq_observatory(n_episodes: int = 300, seed: int = 42) -> list:
    env   = IQPatternEnv(seed=seed)
    agent = SextBioRAGAgent(seed=seed)

    snapshot_at = {1, 5, 20, 50, 100, 200, n_episodes}
    snapshots   = []

    print(f"\n{'='*60}")
    print(f"  IQ PATTERN OBSERVATORY")
    print(f"  5 hard classes · {n_episodes} episodes · SextBioRAG")
    print(f"  Surface rotates every episode (same rule, new clothes)")
    print(f"{'='*60}\n")

    for ep in range(1, n_episodes + 1):
        obs  = env.reset(episode_id=ep)
        task = obs['task']
        ctx  = task['context']
        choices = task['choices']

        if not choices:
            continue

        chosen, source = agent.choose_action(ctx, choices)

        action = Action(
            tier=ActionTier.ASSEMBLE,
            payload={'result': chosen, 'primitives': [chosen]}
        )
        new_obs, reward, done, info = env.step(action)
        agent.update(condition=ctx, action=chosen,
                     success=info['success'], step=ep)

        if ep in snapshot_at:
            snapshots.append({
                'episode':  ep,
                'class':    info['class'],
                'surface':  info['surface'],
                'problem':  task['given'],
                'hint':     task['hint'],
                'choices':  choices,
                'chosen':   str(chosen),
                'correct':  str(info['correct_answer']),
                'right':    info['success'],
                'source':   source,
                'reward':   reward,
            })

        if ep % 50 == 0:
            recent = env.get_snapshots()[-20:]
            acc = sum(1 for s in recent if s['right']) / max(1, len(recent))
            # Accuracy by class
            by_class = {}
            for s in env.get_snapshots():
                by_class.setdefault(s['class'], []).append(s['right'])
            class_str = '  '.join(
                f"{k[:6]}={sum(v)/len(v):.0%}"
                for k, v in by_class.items()
            )
            print(f"  ep {ep:4d} | acc(last20)={acc:.0%} | {class_str}")

    return snapshots


def render_artifact(snapshots: list) -> str:
    lines = [
        "=" * 64,
        "  IQ PATTERN ARTIFACT — What the Agent Saw and Did",
        "=" * 64,
        "",
        "  Each block: one episode. Problem shown exactly as given.",
        "  Agent had no memory of the answer. Only experience.",
        "",
    ]

    for snap in snapshots:
        mark  = "✓  CORRECT" if snap['right'] else "✗  WRONG"
        color = "→" if snap['right'] else "✗"

        lines += [
            f"{'─'*64}",
            f"  EPISODE {snap['episode']:4d}  |  Class: {snap['class']}  |  Surface: {snap['surface']}",
            f"{'─'*64}",
            "",
            "  PROBLEM:",
        ]

        # Indent each line of the problem
        for pline in snap['problem'].split('\n'):
            lines.append(f"    {pline}")

        lines += [
            "",
            f"  HINT: {snap['hint']}",
            "",
            "  CHOICES:",
        ]
        for i, ch in enumerate(snap['choices']):
            marker = "  ►" if str(ch) == snap['chosen'] else "   "
            correct_mark = "  ← correct" if str(ch) == snap['correct'] else ""
            lines.append(f"  {marker} {ch}{correct_mark}")

        lines += [
            "",
            f"  AGENT CHOSE:   {snap['chosen']}  (via {snap['source']})",
            f"  CORRECT WAS:   {snap['correct']}",
            f"  VERDICT:       {mark}",
            "",
        ]

    lines += [
        "=" * 64,
        "  END OF ARTIFACT",
        "=" * 64,
    ]

    return "\n".join(lines)


if __name__ == '__main__':
    snapshots = run_iq_observatory(n_episodes=300)
    artifact  = render_artifact(snapshots)

    print("\n")
    print(artifact)

    os.makedirs('results/artifacts', exist_ok=True)
    out = 'results/artifacts/iq_pattern_artifact.txt'
    with open(out, 'w') as f:
        f.write(artifact)

    json_out = 'results/artifacts/iq_pattern_snapshots.json'
    with open(json_out, 'w') as f:
        json.dump(snapshots, f, indent=2)

    print(f"\n  Artifact saved: {out}")
    print(f"  Snapshots JSON: {json_out}")
