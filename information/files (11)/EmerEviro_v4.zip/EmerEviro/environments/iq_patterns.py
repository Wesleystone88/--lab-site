"""
IQ Pattern Environment — High Difficulty
==========================================
Domain: Relational pattern completion

NOT designed for easy wins.
Designed to show the difference between:
    - Systems that pattern-match surfaces (fail on new surfaces)
    - Systems that learn the underlying invariant (transfer across surfaces)

The five hard classes:
    A: Cross-sequence dependency  — rule lives BETWEEN series
    B: Constraint satisfaction    — multiple rules must ALL hold
    C: Rule inversion             — the inversion IS the pattern
    D: Structural analogy         — A:B as C:? where relationship is a transformation
    E: Code-pattern hybrid        — same rule, wildly different surface

What makes these hard:
    Any system that reads the surface and guesses will hit ~20% (random).
    Any system that learned the structural invariant transfers immediately.
    There is no in-between. You either see the rule or you don't.

The output is human-readable.
You look at what the agent produced and you know if it's right.
No measurement required.
"""

from __future__ import annotations
import sys, os, random, json
from dataclasses import dataclass, field
from typing import Any

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from engine.base import EnvironmentBase, EnvironmentSpec
from bus.schemas import Action, ActionTier


# ============================================================
# INVARIANT CLASSES — the hidden rules
# Each class has one true invariant expressed across many surfaces
# ============================================================

class InvariantClass:
    """Base: one hidden rule, many surfaces."""
    name = "base"
    description = ""

    def generate(self, rng: random.Random, surface: str) -> dict:
        raise NotImplementedError

    def verify(self, problem: dict, answer: Any) -> bool:
        raise NotImplementedError


# ─────────────────────────────────────────────────────────────
# CLASS A: Cross-sequence dependency
# The answer to sequence C requires understanding A AND B together.
# Surface pattern matchers only see C and fail.
# ─────────────────────────────────────────────────────────────

class CrossSequence(InvariantClass):
    """
    Hidden rule: C[n] = A[n] OP B[n], where OP is hidden.
    
    The OP is always the same within a run (add, subtract, multiply, xor-parity).
    Surface varies: numbers, lengths of words, counts of shapes, line counts in code.
    
    Why this breaks LLMs: they look at C alone and guess a progression.
    Why this tests BioRAG: it must hold A, B, C in working memory simultaneously
    and converge on the operation that makes all three consistent.
    """
    name = "cross_sequence"
    description = "C[n] depends on A[n] and B[n] together. Rule is hidden."

    OPERATIONS = {
        'add':      lambda a, b: a + b,
        'subtract': lambda a, b: a - b,
        'multiply': lambda a, b: a * b,
        'parity':   lambda a, b: (a + b) % 2,  # 0 or 1
    }

    SURFACES = {
        'numeric': {
            'render': lambda a, b, c: {
                'A': str(a),
                'B': str(b),
                'C': str(c[:-1]) + ' ?',
                'choices': None,  # generated later
            },
            'answer_type': 'number',
        },
        'word_length': {
            'render': lambda a, b, c: {
                # A and B are words whose lengths match the sequences
                'A': 'words with lengths: ' + str(a),
                'B': 'words with lengths: ' + str(b),
                'C': 'complete the lengths: ' + str(c[:-1]) + ' ?',
                'choices': None,
            },
            'answer_type': 'number',
        },
        'code': {
            'render': lambda a, b, c: {
                # A = number of inputs, B = number of steps, C = number of outputs
                'A': f"functions with {a[0]},{a[1]},{a[2]} input params",
                'B': f"functions with {b[0]},{b[1]},{b[2]} body lines",
                'C': f"outputs were {c[0]},{c[1]},? — complete it",
                'choices': None,
            },
            'answer_type': 'number',
        },
    }

    def generate(self, rng: random.Random, surface: str = 'numeric') -> dict:
        op_name = rng.choice(list(self.OPERATIONS.keys()))
        op = self.OPERATIONS[op_name]

        # Generate A and B sequences (length 3)
        A = [rng.randint(1, 8) for _ in range(3)]
        B = [rng.randint(1, 8) for _ in range(3)]
        C = [op(a, b) for a, b in zip(A, B)]

        correct = C[-1]

        # Decoys: plausible wrong answers
        decoys = list({
            correct + rng.randint(1, 4),
            correct - rng.randint(1, 4),
            C[-2] + (C[-2] - C[-3]) if len(C) >= 3 else correct + 2,  # naive progression
            A[-1] + rng.randint(1, 3),
        } - {correct})[:3]

        choices = [correct] + decoys[:3]
        rng.shuffle(choices)

        return {
            'class':    self.name,
            'surface':  surface,
            'A':        A,
            'B':        B,
            'C_given':  C[:-1],
            'correct':  correct,
            'choices':  choices,
            'op_name':  op_name,  # hidden from agent
            'display': {
                'given': f"A: {A}\nB: {B}\nC: {C[:-1]} + [?]",
                'hint':  f"How does C relate to A and B?",
            }
        }

    def verify(self, problem: dict, answer: Any) -> bool:
        try:
            return int(answer) == problem['correct']
        except:
            return False


# ─────────────────────────────────────────────────────────────
# CLASS B: Constraint satisfaction
# Multiple rules must ALL hold simultaneously.
# One answer satisfies all. Distractors satisfy some.
# This is the one that kills transformers — they optimize locally.
# ─────────────────────────────────────────────────────────────

class ConstraintSatisfaction(InvariantClass):
    """
    Hidden rule: the correct answer satisfies N constraints simultaneously.
    Each distractor violates exactly one constraint (looks almost right).
    
    Why this is hard: you can find answers that satisfy 2/3 constraints easily.
    Finding the one that satisfies all 3 requires global reasoning.
    
    BioRAG angle: Hopfield network converges to energy minimum = all constraints satisfied.
    This is literally what it was designed for.
    """
    name = "constraint_satisfaction"
    description = "One answer satisfies all rules. Distractors satisfy some but not all."

    def generate(self, rng: random.Random, surface: str = 'numeric') -> dict:
        # Generate three constraints and the unique satisfying answer
        # Constraint types: divisible_by, in_range, same_parity, digit_sum
        
        base = rng.randint(10, 50)
        div  = rng.choice([2, 3, 4, 5])
        
        # Find correct answer: divisible by div, in range, specific digit sum
        correct = base - (base % div)
        if correct < 10:
            correct += div

        digit_sum_target = sum(int(d) for d in str(correct))
        parity = correct % 2

        constraints = [
            f"divisible by {div}",
            f"digit sum = {digit_sum_target}",
            f"{'even' if parity == 0 else 'odd'} number",
        ]

        # Generate distractors that satisfy exactly 2/3 constraints
        d1 = correct + div              # divisible, wrong digit sum
        d2 = correct - 1               # right parity range, not divisible
        d3 = correct + (10 if digit_sum_target < 10 else -10)  # throws off digit sum

        choices = list({correct, d1, d2, d3})
        rng.shuffle(choices)

        surface_display = {
            'numeric': {
                'given': f"Find the number that satisfies ALL of:\n" +
                         '\n'.join(f"  • {c}" for c in constraints),
                'hint': "All rules must hold. Not just some.",
            },
            'code': {
                'given': f"Find the value N where your function must:\n"
                         f"  • accept N inputs (N divisible by {div})\n"
                         f"  • produce output whose digits sum to {digit_sum_target}\n"
                         f"  • return {'even' if parity==0 else 'odd'} count",
                'hint': "All constraints must be satisfied simultaneously.",
            },
        }.get(surface, {
            'given': f"Satisfies: {constraints}",
            'hint': "All rules must hold.",
        })

        return {
            'class':       self.name,
            'surface':     surface,
            'constraints': constraints,
            'correct':     correct,
            'choices':     choices,
            'display':     surface_display,
        }

    def verify(self, problem: dict, answer: Any) -> bool:
        try:
            return int(answer) == problem['correct']
        except:
            return False


# ─────────────────────────────────────────────────────────────
# CLASS C: Rule inversion
# Pattern holds for N steps. Then inverts. The inversion IS the rule.
# Systems that find the first pattern and extrapolate always fail.
# ─────────────────────────────────────────────────────────────

class RuleInversion(InvariantClass):
    """
    Hidden rule: sequence follows rule R for steps 1-N, then rule ~R for steps N+1-end.
    The inversion point and inversion type are the hidden invariants.
    
    Example:
        Steps 1-4: +3 each time → 2, 5, 8, 11
        Steps 5-8: -3 each time → 11, 8, 5, ?    ← correct: 2
        
    Naive answer: 14 (extrapolate +3)
    Correct answer: 2 (inversion happened at step 5)
    
    This catches every system that pattern-matches the beginning and extrapolates.
    """
    name = "rule_inversion"
    description = "Rule applies then inverts. The inversion is the real pattern."

    def generate(self, rng: random.Random, surface: str = 'numeric') -> dict:
        delta = rng.randint(2, 6)
        start = rng.randint(2, 10)
        pivot_steps = rng.randint(3, 5)

        # Build: start → increase → invert → decrease
        ascending  = [start + delta * i for i in range(pivot_steps)]
        descending = [ascending[-1] - delta * i for i in range(1, pivot_steps)]

        full = ascending + descending
        given = full[:-1]
        correct = full[-1]

        # Decoys
        naive_extrapolate = given[-1] + delta       # wrong: extrapolates ascending
        wrong_delta       = given[-1] - (delta + 2) # wrong delta
        mirror_mistake    = ascending[1]             # off by one on inversion point

        choices = list({correct, naive_extrapolate, wrong_delta, mirror_mistake} - {correct})
        choices = [correct] + choices[:3]
        rng.shuffle(choices)

        surface_variants = {
            'numeric': f"Sequence: {given} + [?]",
            'code':    f"Loop iterations per function call:\n{given} + [?]\n(pattern inverts at some point)",
            'symbolic': f"Stack depth over time: {given} + [?]",
        }

        return {
            'class':       self.name,
            'surface':     surface,
            'full':        full,
            'given':       given,
            'correct':     correct,
            'choices':     choices,
            'pivot':       pivot_steps,
            'delta':       delta,
            'display': {
                'given': surface_variants.get(surface, f"{given} + [?]"),
                'hint':  "The rule changes at some point. When and how?",
            }
        }

    def verify(self, problem: dict, answer: Any) -> bool:
        try:
            return int(answer) == problem['correct']
        except:
            return False


# ─────────────────────────────────────────────────────────────
# CLASS D: Structural analogy (hardest)
# A is to B as C is to ?
# But the A→B transformation is itself compound (not a single mapping).
# ─────────────────────────────────────────────────────────────

class StructuralAnalogy(InvariantClass):
    """
    Hidden rule: the transformation T that maps A→B also maps C→?
    But T is compound: rotate + scale, or negate + shift, or mirror + offset.
    
    Simple analogy: 2→4 as 3→6 (multiply by 2). Easy. Solved.
    Hard analogy:   2→7 as 5→?  (multiply by 2 then add 3). Requires decomposing T.
    Harder:         [2,3]→[6,4] as [4,1]→?  (swap then multiply). 2D transformation.
    
    The surface changes every episode (numbers, coordinates, code structure, symbols).
    The transformation T stays the same within a run.
    """
    name = "structural_analogy"
    description = "A→B transformation applied to C. Transformation is compound."

    TRANSFORMS = {
        'double_plus':   {'fn': lambda x: x*2+3,   'inv_desc': "×2 then +3"},
        'negate_shift':  {'fn': lambda x: -x+10,   'inv_desc': "-x then +10"},
        'square_minus':  {'fn': lambda x: x**2-1,  'inv_desc': "square then -1"},
        'triple_minus':  {'fn': lambda x: x*3-2,   'inv_desc': "×3 then -2"},
    }

    def generate(self, rng: random.Random, surface: str = 'numeric') -> dict:
        t_name = rng.choice(list(self.TRANSFORMS.keys()))
        t = self.TRANSFORMS[t_name]
        fn = t['fn']

        a = rng.randint(1, 6)
        b = fn(a)
        c = rng.randint(1, 6)
        while c == a:
            c = rng.randint(1, 6)
        correct = fn(c)

        # Decoys: apply wrong transforms
        decoys = list({
            c * 2,          # just double (ignores +3)
            b + (c - a),    # linear shift (wrong)
            fn(a) + c,      # confused A's output with C
            correct + rng.randint(1, 5),
        } - {correct})[:3]

        choices = [correct] + decoys
        rng.shuffle(choices)

        surface_variants = {
            'numeric': f"{a} → {b}\n{c} → ?",
            'code':    f"function_v1({a} args) → {b} lines\nfunction_v2({c} args) → ?",
            'symbolic': f"pattern[{a}] transforms to pattern[{b}]\npattern[{c}] transforms to ?",
        }

        return {
            'class':      self.name,
            'surface':    surface,
            'a': a, 'b': b, 'c': c,
            'correct':    correct,
            'choices':    choices,
            't_name':     t_name,  # hidden
            'display': {
                'given': surface_variants.get(surface, f"{a}→{b}, {c}→?"),
                'hint':  "Find the transformation. Apply it exactly.",
            }
        }

    def verify(self, problem: dict, answer: Any) -> bool:
        try:
            return int(answer) == problem['correct']
        except:
            return False


# ─────────────────────────────────────────────────────────────
# CLASS E: Code-pattern hybrid
# A structural programming invariant expressed as:
#   - a sequence problem
#   - a matrix problem
#   - a broken code snippet with a gap
# Same hidden rule, three completely different surfaces.
# ─────────────────────────────────────────────────────────────

class CodePatternHybrid(InvariantClass):
    """
    Hidden rule: a structural invariant from computation theory.
    Expressed across numeric, visual, and code surfaces.
    
    Invariants used:
        - Off-by-one: boundary conditions
        - Dependency order: B requires A before it can run
        - Null check: guard before use
        - Accumulator pattern: build before return
    
    The correct answer is the structural completion — not just a number,
    but the thing that makes the structure hold.
    """
    name = "code_pattern_hybrid"
    description = "Structural programming invariant across numeric, visual, and code surfaces."

    INVARIANTS = {
        'dependency_order': {
            'numeric':  {
                'template': "Steps complete in order: {seq}\nWhich step is missing?",
                'gen': lambda rng: {
                    'seq': [1,2,'?',4,5],
                    'correct': 3,
                    'decoys': [0, 2, 6],
                    'hint': "Each step depends on the previous."
                }
            },
            'code': {
                'template': """# Which line belongs at position [?]?
{before}
[?]
{after}""",
                'gen': lambda rng: {
                    'before': "data = load()\nvalidated = validate(data)",
                    'after': "result = transform(processed)\nreturn result",
                    'correct': "processed = process(validated)",
                    'choices': [
                        "processed = process(validated)",  # correct
                        "result = transform(data)",        # skips validation
                        "return transform(validated)",     # skips processing
                        "validated = validate(result)",    # uses undefined result
                    ],
                    'hint': "Data must flow: load → validate → process → transform → return"
                }
            },
        },
        'guard_before_use': {
            'numeric': {
                'template': "Values: {seq}\nThe rule: check before use. Which is wrong?",
                'gen': lambda rng: {
                    'seq': [1, None, 3, 4],  # None = unguarded null
                    'correct': 1,  # index of the violation
                    'decoys': [0, 2, 3],
                    'hint': "One value is used without being checked first."
                }
            },
            'code': {
                'template': "Which version is structurally correct?",
                'gen': lambda rng: {
                    'choices': [
                        "if x: result = x.value",          # correct: guard then use
                        "result = x.value if x else None", # correct alt
                        "result = x.value; if not x: raise", # use before guard
                        "result = x.value",                 # no guard
                    ],
                    'correct': "if x: result = x.value",
                    'hint': "Check exists before accessing. Always."
                }
            },
        },
    }

    def generate(self, rng: random.Random, surface: str = 'code') -> dict:
        inv_name = rng.choice(list(self.INVARIANTS.keys()))
        inv = self.INVARIANTS[inv_name]

        if surface not in inv:
            surface = list(inv.keys())[0]

        surface_def = inv[surface]
        generated   = surface_def['gen'](rng)

        choices = generated.get('choices', [generated['correct']] + generated.get('decoys', []))
        if isinstance(choices[0], int):
            rng.shuffle(choices)

        return {
            'class':    self.name,
            'surface':  surface,
            'inv_name': inv_name,
            'correct':  generated['correct'],
            'choices':  choices,
            'display': {
                'given': surface_def['template'].format(**{
                    k: v for k, v in generated.items()
                    if k in ['seq', 'before', 'after', 'values']
                }) if '{' in surface_def['template'] else surface_def['template'],
                'hint': generated.get('hint', ''),
            }
        }

    def verify(self, problem: dict, answer: Any) -> bool:
        correct = problem['correct']
        if isinstance(correct, int):
            try:
                return int(answer) == correct
            except:
                return False
        return str(answer).strip() == str(correct).strip()


# ============================================================
# IQ PATTERN ENVIRONMENT
# ============================================================

INVARIANT_CLASSES = {
    'cross_sequence':       CrossSequence(),
    'constraint_sat':       ConstraintSatisfaction(),
    'rule_inversion':       RuleInversion(),
    'structural_analogy':   StructuralAnalogy(),
    'code_pattern':         CodePatternHybrid(),
}

SURFACES = ['numeric', 'code', 'symbolic', 'word_length']


class IQPatternEnv(EnvironmentBase):
    """
    High-difficulty pattern completion environment.
    
    Each episode: one problem from one of the five hard classes.
    Surface rotates every episode — same invariant, different clothing.
    
    The agent that learned the invariant transfers immediately.
    The agent that learned the surface fails on surface change.
    That's the test.
    """

    def __init__(self, seed: int = 42, fixed_class: str = None):
        self.rng = random.Random(seed)
        self.fixed_class = fixed_class
        self._problem = None
        self._episode = 0
        self._surface_idx = 0
        self._snapshots = []  # stores (episode, problem, answer, correct) for artifact

    @property
    def spec(self) -> EnvironmentSpec:
        return EnvironmentSpec(
            name         = "iq_pattern",
            display_name = "High-IQ Pattern Completion",
            domain       = "relational_reasoning",
            description  = (
                "Five classes of patterns designed to fail surface-level systems. "
                "Hidden rules are relational, not sequential. "
                "Surface changes every episode. Rule stays constant within class."
            ),
            difficulty   = 5,
            invariants   = [
                "cross_sequence_dependency",
                "global_constraint_satisfaction",
                "rule_inversion_detection",
                "compound_structural_analogy",
                "code_structural_invariant",
            ],
            tags    = ["iq", "relational", "analogy", "constraint", "transfer"],
            version = "1.0.0",
        )

    def reset(self, episode_id: int = 0) -> dict:
        self._episode = episode_id

        # Rotate through classes and surfaces
        class_name = (self.fixed_class or
                      list(INVARIANT_CLASSES.keys())[episode_id % len(INVARIANT_CLASSES)])
        surface = SURFACES[episode_id % len(SURFACES)]

        inv_class = INVARIANT_CLASSES[class_name]
        self._problem = inv_class.generate(self.rng, surface)
        self._problem['episode'] = episode_id
        self._problem['inv_class_obj'] = inv_class

        return self._observe()

    def step(self, action: Action) -> tuple:
        answer = action.payload.get('result', action.payload.get('primitives', [''])[0])
        if isinstance(answer, list):
            answer = answer[0] if answer else ''

        inv_class = self._problem['inv_class_obj']
        correct   = inv_class.verify(self._problem, answer)
        reward    = 3.0 if correct else -0.5

        # Store snapshot for artifact
        self._snapshots.append({
            'episode':  self._episode,
            'class':    self._problem['class'],
            'surface':  self._problem['surface'],
            'display':  self._problem['display'],
            'choices':  [str(c) for c in self._problem.get('choices', [])],
            'correct':  str(self._problem['correct']),
            'given':    str(answer),
            'right':    correct,
        })

        info = {
            'correct_answer': self._problem['correct'],
            'agent_answer':   answer,
            'success':        correct,
            'class':          self._problem['class'],
            'surface':        self._problem['surface'],
        }

        return self._observe(), reward, True, info

    def run_probes(self, episode: int) -> dict:
        # Key probe: does accuracy drop when surface changes?
        # If yes: surface memorization. If no: true invariant learning.
        recent = self._snapshots[-20:] if len(self._snapshots) >= 20 else self._snapshots
        if not recent:
            return {'delta_transfer': 0.0, 'delta_style': 0.0,
                    'shortcut_index': 0.0, 'cache_index': 0.0, 'flags': []}

        # Accuracy by surface type
        by_surface = {}
        for s in recent:
            surf = s['surface']
            by_surface.setdefault(surf, []).append(1.0 if s['right'] else 0.0)

        accs = {k: sum(v)/len(v) for k, v in by_surface.items()}
        if len(accs) >= 2:
            vals = list(accs.values())
            delta_transfer = max(vals) - min(vals)
            flags = [f"Surface gap: {delta_transfer:.0%}"] if delta_transfer > 0.3 else []
        else:
            delta_transfer = 0.0
            flags = []

        return {
            'delta_transfer': delta_transfer,
            'delta_style':    0.0,
            'shortcut_index': 0.0,
            'cache_index':    0.0,
            'flags':          flags,
            'surface_accs':   accs,
        }

    def get_snapshots(self) -> list:
        """Return episode snapshots for artifact generation."""
        return self._snapshots

    def _observe(self) -> dict:
        p = self._problem
        choices_str = [str(c) for c in p.get('choices', [])]
        return {
            'episode_id':       self._episode,
            'step':             0,
            'task': {
                'class':        p['class'],
                'surface':      p['surface'],
                'display':      p['display'],
                'given':        p['display']['given'],
                'hint':         p['display']['hint'],
                'choices':      choices_str,
                'input':        p['display']['given'],
                'target':       '?',
                'actions':      choices_str,
                'context': {
                    'class':    p['class'],
                    'surface':  p['surface'],
                    'problem':  p['display']['given'][:100],
                },
            },
            'available_atoms':  choices_str,
            'library':          [],
            'capacity_total':   100,
            'budget_remaining': 5.0,
        }


    def _extract_structural_features(self, p: dict) -> dict:
        """
        Stable structural features — same class = same features even when numbers change.
        This is what the agent actually learns. Not the raw numbers.
        """
        cls = p['class']
        f = {'class': cls, 'surface': p['surface']}

        if cls == 'cross_sequence':
            A, B, C = p.get('A', []), p.get('B', []), p.get('C_given', [])
            if len(C) >= 2:
                f['c_trend'] = 'up' if C[-1] > C[0] else 'down' if C[-1] < C[0] else 'flat'
            if A and B:
                a_m, b_m = sum(A)/len(A), sum(B)/len(B)
                f['a_vs_b'] = 'a_bigger' if a_m > b_m else 'b_bigger' if b_m > a_m else 'equal'
            if A and B and C:
                checks = [
                    ('add', abs(C[0] - (A[0] + B[0]))),
                    ('mul', abs(C[0] - (A[0] * B[0]))),
                    ('sub', abs(C[0] - abs(A[0] - B[0]))),
                ]
                f['op_hint'] = min(checks, key=lambda x: x[1])[0]
            f['relationship'] = 'between_series'

        elif cls == 'constraint_satisfaction':
            constraints = p.get('constraints', [])
            f['constraint_count'] = '3'
            f['all_must_hold'] = 'true'
            f['has_divisibility'] = 'true' if any('divisible' in c for c in constraints) else 'false'
            f['has_parity'] = 'true' if any('even' in c or 'odd' in c for c in constraints) else 'false'

        elif cls == 'rule_inversion':
            given = p.get('given', [])
            if len(given) >= 2:
                f['pre_trend'] = 'up' if given[1] > given[0] else 'down'
            changes = []
            for i in range(1, len(given)-1):
                d1 = given[i] - given[i-1]
                d2 = given[i+1] - given[i]
                if d1 != 0 and d2 != 0 and ((d1 > 0) != (d2 > 0)):
                    changes.append(i)
            f['inversion_detected'] = 'true' if changes else 'false'
            f['inversion_point'] = ('early' if changes and changes[0] < len(given)//2
                                    else 'late' if changes else 'none')

        elif cls == 'structural_analogy':
            a, b, c = p.get('a', 1), p.get('b', 1), p.get('c', 1)
            f['transform_direction'] = 'up' if b > a else 'down'
            ratio = b / a if a != 0 else 1
            f['transform_magnitude'] = 'small' if ratio < 1.5 else 'large' if ratio > 3 else 'medium'
            f['c_relative'] = 'small' if c < 4 else 'large'

        elif cls == 'code_pattern':
            inv = p.get('inv_name', '')
            f['structural_type'] = 'dependency' if 'dependency' in inv else 'guard'
            f['inv_name'] = inv

        return {k: str(v) for k, v in f.items()}
