"""
Routed IQ Test
==============
The full system: SextBioRAG + CognitiveRouter + Substrates.

For each problem:
    1. Environment generates problem with structural features
    2. Router reads features → dispatches to correct substrate
    3. Substrate computes answer (or returns None → Bandit fallback)
    4. Outcome recorded, agent updated
    5. Everything logged for the artifact

The artifact shows:
    - What the problem was
    - Which substrate fired
    - What it computed
    - Right or wrong — you can see it
    - The routing trace for every decision
"""

import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, 'agents/deployable_biorag_hybrids')

from environments import iq_patterns as iq_mod
from environments.iq_patterns import IQPatternEnv
from agents.deployable_biorag_hybrids.sext_biorag import SextBioRAGAgent
from router import CognitiveRouter
from bus.schemas import Action, ActionTier


# ── PATCH _observe to use structural features ─────────────────
def patched_observe(self):
    p = self._problem
    choices_str = [str(c) for c in p.get('choices', [])]
    structural  = self._extract_structural_features(p)
    return {
        'episode_id': self._episode, 'step': 0,
        'task': {
            'class': p['class'], 'surface': p['surface'],
            'display': p['display'], 'given': p['display']['given'],
            'hint': p['display']['hint'], 'choices': choices_str,
            'input': p['display']['given'], 'target': '?',
            'actions': choices_str, 'context': structural,
        },
        'available_atoms': choices_str, 'library': [],
        'capacity_total': 100, 'budget_remaining': 5.0,
    }

iq_mod.IQPatternEnv._observe = patched_observe


# ── RUN ───────────────────────────────────────────────────────
def run_routed_test(n_episodes: int = 500, seed: int = 42):
    env    = IQPatternEnv(seed=seed)
    agent  = SextBioRAGAgent(seed=seed)
    router = CognitiveRouter()

    snapshot_at = {1, 5, 20, 50, 100, 200, 300, 500}
    snapshots   = []
    by_class    = {}

    print(f"\n{'='*64}")
    print(f"  ROUTED IQ TEST")
    print(f"  Agent: SextBioRAG + CognitiveRouter + 4 Substrates")
    print(f"  Episodes: {n_episodes}")
    print(f"  Surface rotates. Hidden rules constant.")
    print(f"{'='*64}\n")
    print(f"  {'Class':<28} {'Substrate':<16} {'Answer':<8} {'Correct':<8}")
    print(f"  {'-'*60}")

    for ep in range(1, n_episodes + 1):
        obs     = env.reset(episode_id=ep)
        task    = obs['task']
        ctx     = task['context']
        choices = task['choices']
        if not choices:
            continue

        # Get the raw problem for substrates
        raw_problem = env._problem

        # ── ROUTE ──────────────────────────────────────────────
        routed_answer, substrate_used, explanation = router.route(
            features=ctx,
            problem=raw_problem,
            choices=choices,
            episode=ep,
        )

        # ── DECIDE ─────────────────────────────────────────────
        if routed_answer is not None and str(routed_answer) in [str(c) for c in choices]:
            # Substrate gave a confident answer — use it
            final_answer = str(routed_answer)
            decision_src = substrate_used
        else:
            # Bandit fallback
            chosen, source = agent.choose_action(ctx, choices)
            final_answer   = str(chosen)
            decision_src   = f"bandit({source})"

        # ── STEP ───────────────────────────────────────────────
        action = Action(tier=ActionTier.ASSEMBLE,
                        payload={'result': final_answer, 'primitives': [final_answer]})
        new_obs, reward, done, info = env.step(action)

        correct = info['success']
        router.record_outcome(substrate_used, correct)
        agent.update(condition=ctx, action=final_answer,
                     success=correct, step=ep)

        cls = info['class']
        by_class.setdefault(cls, []).append(correct)

        # Verbose every 10 in early episodes, then less
        if ep <= 20 or ep % 50 == 0 or ep in snapshot_at:
            mark = '✓' if correct else '✗'
            print(f"  ep{ep:4d} {cls[:24]:<26} {decision_src[:14]:<16} "
                  f"{final_answer[:6]:<8} {info['correct_answer']!s:<6} {mark}")

        if ep in snapshot_at:
            snapshots.append({
                'episode':     ep,
                'class':       cls,
                'surface':     info['surface'],
                'problem':     task['given'],
                'choices':     choices,
                'chosen':      final_answer,
                'correct':     str(info['correct_answer']),
                'right':       correct,
                'substrate':   decision_src,
                'explanation': explanation,
                'ctx':         ctx,
            })

    # ── RESULTS ────────────────────────────────────────────────
    print(f"\n{'='*64}")
    print(f"  RESULTS BY CLASS")
    print(f"{'='*64}")
    print(f"  {'Class':<32} {'Acc':>6}  {'Progress'}")
    print(f"  {'-'*60}")

    for cls, results in sorted(by_class.items()):
        acc   = sum(results) / len(results)
        final = sum(results[-50:]) / min(50, len(results))
        bar   = '█' * int(final * 20) + '░' * (20 - int(final * 20))
        print(f"  {cls:<32} {final:>5.0%}  [{bar}]")

    print(f"\n  SUBSTRATE ACCURACY")
    print(f"  {'-'*40}")
    for name, stats in router.substrate_report().items():
        print(f"  {name:<20} {stats['accuracy']:>5.0%}  ({stats['attempts']} attempts)")

    return snapshots, router, by_class


# ── ARTIFACT ──────────────────────────────────────────────────
def render_routed_artifact(snapshots: list) -> str:
    lines = [
        "=" * 66,
        "  ROUTED IQ TEST ARTIFACT",
        "  What was given. What fired. What it built.",
        "=" * 66,
    ]

    for snap in snapshots:
        mark = "✓  CORRECT" if snap['right'] else "✗  WRONG"
        lines += [
            "",
            f"{'─'*66}",
            f"  EPISODE {snap['episode']:4d}  |  {snap['class']}  |  surface={snap['surface']}",
            f"{'─'*66}",
            "",
            "  PROBLEM GIVEN:",
        ]
        for line in snap['problem'].split('\n'):
            lines.append(f"    {line}")

        lines += [
            "",
            f"  STRUCTURAL FEATURES (what the router read):",
        ]
        for k, v in snap['ctx'].items():
            lines.append(f"    {k:<22} = {v}")

        lines += [
            "",
            f"  SUBSTRATE FIRED:   {snap['substrate']}",
            f"  REASONING:         {snap['explanation'][:80]}",
            "",
            "  CHOICES:",
        ]
        for ch in snap['choices']:
            chosen_mark  = " ►" if str(ch) == str(snap['chosen']) else "  "
            correct_mark = "  ← correct" if str(ch) == str(snap['correct']) else ""
            lines.append(f"  {chosen_mark} {ch}{correct_mark}")

        lines += [
            "",
            f"  AGENT CHOSE:   {snap['chosen']}",
            f"  CORRECT WAS:   {snap['correct']}",
            f"  VERDICT:       {mark}",
        ]

    lines += ["", "=" * 66, "  END", "=" * 66]
    return "\n".join(lines)


if __name__ == '__main__':
    snapshots, router, by_class = run_routed_test(n_episodes=500)

    artifact = render_routed_artifact(snapshots)
    print("\n")
    print(artifact)

    os.makedirs('results/artifacts', exist_ok=True)
    with open('results/artifacts/routed_iq_artifact.txt', 'w') as f:
        f.write(artifact)
    with open('results/artifacts/routed_iq_snapshots.json', 'w') as f:
        json.dump({
            'snapshots': snapshots,
            'substrate_report': router.substrate_report(),
            'class_accuracy': {
                cls: sum(v[-50:])/min(50,len(v))
                for cls, v in by_class.items()
            }
        }, f, indent=2)

    print("\n  Artifact: results/artifacts/routed_iq_artifact.txt")
