"""
Cold vs Warm Start Comparison
==============================
Run 1: agent starts cold (no prior memory)
Save: glyphs, cards, bandit posteriors, hippocampal traces
Run 2: agent warm-starts from persisted memory

Compare:
    - Accuracy at episode 10, 50, 100 (how fast does it converge?)
    - Final accuracy per class
    - Convergence episode (when does it hit 80%?)
    - Starting state vs ending state

The question: does persisted memory give a meaningful head start?
"""

import sys, os, json
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, 'agents/deployable_biorag_hybrids')

from environments import iq_patterns as iq_mod
from environments.iq_patterns import IQPatternEnv
from agents.deployable_biorag_hybrids.sext_biorag import SextBioRAGAgent
from router import CognitiveRouter
from persistent_memory import PersistentMemory
from bus.schemas import Action, ActionTier


def patched_observe(self):
    p = self._problem
    choices_str = [str(c) for c in p.get('choices', [])]
    structural  = self._extract_structural_features(p)
    return {
        'episode_id': self._episode, 'step': 0,
        'task': {
            'class': p['class'], 'surface': p['surface'],
            'display': p['display'], 'given': p['display']['given'],
            'hint': p['display']['hint'], 'choices': choices_str,
            'input': p['display']['given'], 'target': '?',
            'actions': choices_str, 'context': structural,
        },
        'available_atoms': choices_str, 'library': [],
        'capacity_total': 100, 'budget_remaining': 5.0,
    }

iq_mod.IQPatternEnv._observe = patched_observe


def run_once(n_episodes: int, seed: int, run_label: str,
             warm_memory: dict = None) -> dict:
    """Run one session. Returns full results for comparison."""

    env    = IQPatternEnv(seed=seed)
    agent  = SextBioRAGAgent(seed=seed)
    router = CognitiveRouter()
    mem    = PersistentMemory()

    # Warm start if memory provided
    if warm_memory:
        mem.warm_start_agent(agent, warm_memory)

    by_class    = {}
    snapshots   = []
    window_accs = []  # rolling 10-ep accuracy for convergence tracking
    snapshot_at = {1, 5, 10, 20, 50, 100, 150, 200, n_episodes}

    print(f"\n{'='*60}")
    print(f"  {run_label}")
    print(f"  Episodes: {n_episodes} | Seed: {seed}")
    if warm_memory:
        print(f"  Starting from persisted memory (run {warm_memory.get('run_number',0)})")
    else:
        print(f"  Starting cold (no prior memory)")
    print(f"{'='*60}")

    window = []  # last 10 outcomes for rolling acc
    for ep in range(1, n_episodes + 1):
        obs     = env.reset(episode_id=ep)
        task    = obs['task']
        ctx     = task['context']
        choices = task['choices']
        if not choices: continue

        raw_problem = env._problem
        routed_answer, substrate_used, explanation = router.route(
            features=ctx, problem=raw_problem, choices=choices, episode=ep)

        if routed_answer is not None and str(routed_answer) in [str(c) for c in choices]:
            final_answer = str(routed_answer)
            decision_src = substrate_used
        else:
            chosen, source = agent.choose_action(ctx, choices)
            final_answer   = str(chosen)
            decision_src   = f'bandit({source})'

        action = Action(tier=ActionTier.ASSEMBLE,
                        payload={'result': final_answer, 'primitives': [final_answer]})
        new_obs, reward, done, info = env.step(action)
        correct = info['success']

        router.record_outcome(substrate_used, correct)
        agent.update(condition=ctx, action=final_answer, success=correct, step=ep)

        cls = info['class']
        by_class.setdefault(cls, []).append(correct)

        window.append(correct)
        if len(window) > 10:
            window.pop(0)
        window_accs.append({'ep': ep, 'acc': sum(window)/len(window)})

        if ep in snapshot_at:
            snapshots.append({
                'episode':     ep,
                'class':       cls,
                'surface':     info['surface'],
                'problem':     task['given'],
                'choices':     choices,
                'chosen':      final_answer,
                'correct':     str(info['correct_answer']),
                'right':       correct,
                'substrate':   decision_src,
                'explanation': explanation,
                'ctx':         ctx,
            })

        if ep % 50 == 0 or ep <= 10:
            recent = [r for results in by_class.values() for r in results][-20:]
            acc = sum(recent)/len(recent) if recent else 0
            by_cls_str = '  '.join(
                f"{k[:6]}={sum(v[-10:])/min(10,len(v)):.0%}"
                for k,v in by_class.items()
            )
            print(f"  ep {ep:4d} | overall={acc:.0%} | {by_cls_str}")

    # Final stats
    final_acc = {
        cls: sum(v[-50:])/min(50,len(v))
        for cls, v in by_class.items()
    }

    print(f"\n  Final accuracy:")
    for cls, acc in final_acc.items():
        bar = '█'*int(acc*20)+'░'*(20-int(acc*20))
        print(f"    {cls:<32} {acc:.0%}  [{bar}]")

    return {
        'run_label':   run_label,
        'final_acc':   final_acc,
        'by_class':    {k:[int(x) for x in results] for k,results in by_class.items()},
        'snapshots':   snapshots,
        'window_accs': window_accs,
        'agent':       agent,
        'substrate_report': router.substrate_report(),
    }


def compare(run1: dict, run2: dict):
    """Print side-by-side comparison of cold vs warm."""
    print(f"\n{'='*70}")
    print(f"  COMPARISON: Cold Start vs Warm Start")
    print(f"{'='*70}")
    print(f"  {'Class':<30} {'Cold':>6}  {'Warm':>6}  {'Delta':>6}")
    print(f"  {'-'*56}")

    all_classes = set(run1['final_acc']) | set(run2['final_acc'])
    for cls in sorted(all_classes):
        cold = run1['final_acc'].get(cls, 0)
        warm = run2['final_acc'].get(cls, 0)
        delta = warm - cold
        sign = '+' if delta > 0 else ''
        print(f"  {cls:<30} {cold:>5.0%}  {warm:>5.0%}  {sign}{delta:>5.0%}")

    print(f"\n  EARLY CONVERGENCE (first 20 episodes):")
    print(f"  {'Episode':<10} {'Cold':>6}  {'Warm':>6}")
    for ep in [5, 10, 20]:
        cold_w = next((w['acc'] for w in run1['window_accs'] if w['ep']==ep), None)
        warm_w = next((w['acc'] for w in run2['window_accs'] if w['ep']==ep), None)
        if cold_w is not None and warm_w is not None:
            print(f"  ep {ep:<7} {cold_w:>5.0%}  {warm_w:>5.0%}")


if __name__ == '__main__':
    os.makedirs('memory', exist_ok=True)
    mem = PersistentMemory()
    N   = 200  # episodes per run

    # ── RUN 1: Cold ─────────────────────────────────────────────
    run1 = run_once(n_episodes=N, seed=42, run_label='RUN 1 — Cold Start')

    # Save memory after run 1
    mem.save(
        agent=run1['agent'],
        by_class=run1['by_class'],
        snapshots=run1['snapshots'],
        run_number=1,
    )

    # ── RUN 2: Warm ─────────────────────────────────────────────
    loaded = mem.load()
    run2 = run_once(n_episodes=N, seed=42, run_label='RUN 2 — Warm Start',
                    warm_memory=loaded)

    # ── COMPARE ─────────────────────────────────────────────────
    compare(run1, run2)

    # Save full results for docx
    out = {
        'run1': {k:v for k,v in run1.items() if k != 'agent'},
        'run2': {k:v for k,v in run2.items() if k != 'agent'},
        'memory_path': mem.path,
    }
    with open('/tmp/comparison_data.json', 'w') as f:
        json.dump(out, f, indent=2)

    print(f"\n  Data saved: /tmp/comparison_data.json")
    print(f"  Memory file: {mem.path}")
