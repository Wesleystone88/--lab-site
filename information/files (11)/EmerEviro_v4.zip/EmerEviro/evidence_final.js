const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  AlignmentType, HeadingLevel, BorderStyle, WidthType, ShadingType,
  VerticalAlign, PageNumber, PageBreak, Footer, LevelFormat
} = require('docx');
const fs = require('fs');

const cmp = JSON.parse(fs.readFileSync('/tmp/comparison_data.json', 'utf8'));
const r1  = cmp.run1;
const r2  = cmp.run2;

const C = {
  dark:'0D1B2A', white:'FFFFFF', rule:'D5D8DC',
  green:'1E8449', greenLight:'EAFAF1',
  red:'C0392B',   redLight:'FDEDEC',
  amber:'D68910', amberLight:'FEF9E7',
  grey:'717D7E',  greyLight:'F4F6F7',
  blue:'1B4F72',  teal:'117A65', purple:'6C3483',
};
const SUB_C = {solver:C.teal, memory_probe:C.red, decomposer:C.purple, bandit:C.grey, compute:C.blue};

const brd  = (col=C.rule) => ({style:BorderStyle.SINGLE,size:1,color:col});
const brds = (col=C.rule) => ({top:brd(col),bottom:brd(col),left:brd(col),right:brd(col)});
const mg = {top:100,bottom:100,left:160,right:160};

const cell = (ch, opts={}) => new TableCell({
  borders:brds(opts.bc||C.rule), margins:mg,
  width: opts.w?{size:opts.w,type:WidthType.DXA}:undefined,
  shading: opts.fill?{fill:opts.fill,type:ShadingType.CLEAR}:undefined,
  verticalAlign:VerticalAlign.CENTER,
  children:Array.isArray(ch)?ch:[ch],
});
const t = (text, opts={}) => new TextRun({
  text:String(text), size:opts.sz||20, bold:opts.b||false,
  color:opts.c||C.dark, font:opts.mono?'Courier New':'Arial', italics:opts.i||false,
});
const p = (ch, opts={}) => new Paragraph({
  alignment:opts.ctr?AlignmentType.CENTER:AlignmentType.LEFT,
  spacing:{before:opts.before||0, after:opts.after||80},
  indent:opts.ind?{left:opts.ind}:undefined,
  children:Array.isArray(ch)?ch:[ch],
});
const sp = n => p([t('',{sz:n})],{after:0});
const bar  = (acc,len=16) => '█'.repeat(Math.round(acc*len))+'░'.repeat(len-Math.round(acc*len));
const aCol = acc => acc>=0.95?C.green:acc>=0.7?C.amber:C.red;
const aBg  = acc => acc>=0.95?C.greenLight:acc>=0.7?C.amberLight:C.redLight;
const lbl  = cls => ({
  constraint_satisfaction:'Constraint Satisfaction',rule_inversion:'Rule Inversion',
  structural_analogy:'Structural Analogy',code_pattern_hybrid:'Code Structure',
  cross_sequence:'Cross-Sequence',
}[cls]||cls);

// ── COVER ──────────────────────────────────────────────────────
function cover() {
  // Main comparison table
  const hdr = new TableRow({children:[
    cell(p([t('Pattern Class',{b:true,sz:17,c:C.white})]),{fill:C.dark,w:2600}),
    cell(p([t('Cold Start',{b:true,sz:17,c:C.white})],{ctr:true}),{fill:C.dark,w:1600}),
    cell(p([t('Warm Start',{b:true,sz:17,c:C.white})],{ctr:true}),{fill:C.dark,w:1600}),
    cell(p([t('Delta',{b:true,sz:17,c:C.white})],{ctr:true}),{fill:C.dark,w:900}),
    cell(p([t('Substrate',{b:true,sz:17,c:C.white})],{ctr:true}),{fill:C.dark,w:1900}),
    cell(p([t('What it does',{b:true,sz:17,c:C.white})]),{fill:C.dark,w:2700}),
  ]});

  const SUBS = {
    constraint_satisfaction:'solver',rule_inversion:'memory_probe',
    structural_analogy:'decomposer',code_pattern_hybrid:'bandit',cross_sequence:'compute',
  };
  const WHAT = {
    solver:'Satisfies all constraints globally',memory_probe:'Detects sequence inversion point',
    decomposer:'Decomposes compound transform',bandit:'Thompson Sampling (learns)',compute:'Finds hidden arithmetic op',
  };

  const rows = [hdr];
  Object.keys(r1.final_acc).forEach((cls,i)=>{
    const cold=r1.final_acc[cls], warm=r2.final_acc[cls];
    const delta=warm-cold, sub=SUBS[cls];
    const sc=SUB_C[sub]||C.grey, bg=i%2?C.greyLight:C.white;
    const dBg = delta>0.05?C.greenLight:delta<-0.05?C.redLight:bg;
    rows.push(new TableRow({children:[
      cell(p([t(lbl(cls),{sz:17})]),{fill:bg,w:2600}),
      cell(p([t(`${Math.round(cold*100)}%`,{sz:18,c:aCol(cold)})],{ctr:true}),{fill:aBg(cold),w:1600}),
      cell(p([t(`${Math.round(warm*100)}%`,{b:true,sz:19,c:aCol(warm)})],{ctr:true}),{fill:aBg(warm),w:1600}),
      cell(p([t(`${delta>=0?'+':''}${Math.round(delta*100)}%`,{b:delta>0.05,sz:17,c:delta>0.05?C.green:delta<0?C.red:C.grey})],{ctr:true}),{fill:dBg,w:900}),
      cell(p([t(sub,{b:true,sz:14,c:C.white})],{ctr:true}),{fill:sc,w:1900}),
      cell(p([t(WHAT[sub]||'',{sz:15,i:true})]),{fill:bg,w:2700}),
    ]}));
  });

  return [
    sp(60),
    p([t('EMERVIRO',{sz:54,b:true,c:C.dark})],{ctr:true,after:10}),
    p([t('Routed Cognitive Architecture — Evidence',{sz:26,i:true,c:C.grey})],{ctr:true,after:80}),
    new Table({width:{size:11300,type:WidthType.DXA},columnWidths:[2600,1600,1600,900,1900,2700],rows}),
    sp(50),
    p([t('Five hard IQ pattern classes  ·  SextBioRAG + CognitiveRouter + 4 Substrates',{sz:19,b:true,c:C.dark})],{ctr:true,after:12}),
    p([t('200 episodes cold  →  memory saved as glyphs + cards  →  200 episodes warm',{sz:18,i:true,c:C.grey})],{ctr:true,after:12}),
    p([t('Code structure: +28% on warm start  ·  Substrate classes: unchanged (compute, not learn)',{sz:18,c:C.blue})],{ctr:true}),
    new Paragraph({children:[new PageBreak()]}),
  ];
}

// ── PERSISTENT MEMORY ──────────────────────────────────────────
function memorySection() {
  const glyphsMeta = [
    {id:'g-cross-sequence@1.0.0',    title:'Cross Sequence Rule',         sub:'compute',      acc:'100%', md:'C[n] = A[n] OP B[n]. Operation discovered by testing add/subtract/multiply/parity against known C values.'},
    {id:'g-constraint-sat@1.0.0',    title:'Constraint Satisfaction Rule', sub:'solver',       acc:'100%', md:'One answer satisfies ALL constraints simultaneously. Parse constraints, evaluate every choice globally.'},
    {id:'g-rule-inversion@1.0.0',    title:'Rule Inversion Detection',     sub:'memory_probe', acc:'100%', md:'Sequence follows rule R then inverts. Detect by delta sign change. Post-inversion delta extrapolates answer.'},
    {id:'g-structural-analogy@1.0.0',title:'Structural Analogy Transform', sub:'decomposer',   acc:'98%',  md:'Transform is compound (×m+c, x²+c, -x+c). Decompose from A→B, apply identically to C.'},
    {id:'g-code-pattern@1.0.0',      title:'Code Structure Invariant',     sub:'bandit',       acc:'65%→92%', md:'Structural programming invariants. Stable across surfaces. Bandit learns from binary feedback — benefits from warm start.'},
  ];

  const sections = [
    new Paragraph({heading:HeadingLevel.HEADING_1,children:[t('Persistent Memory',{b:true,sz:30,c:C.dark})]}),
    sp(4),
    p([t('After each run, the agent writes its learned state to disk as Glyphs (structural invariants) and Cards (high-salience episodes). On the next run it reloads — bandit posteriors, hippocampal traces, and all learned action preferences warm-started from prior experience.',{sz:21})],{after:80}),
    new Paragraph({heading:HeadingLevel.HEADING_2,children:[t('Glyphs — What Was Learned',{sz:24,b:true,c:C.dark})]}),
    p([t('One glyph per pattern class. Each encodes the structural invariant discovered through experience.',{sz:20,i:true,c:C.grey})],{after:40}),
  ];

  glyphsMeta.forEach((g,i) => {
    const sc = SUB_C[g.sub]||C.grey;
    sections.push(
      new Table({width:{size:9300,type:WidthType.DXA},columnWidths:[2400,5100,1800],rows:[
        new TableRow({children:[
          cell(p([t(g.id,{sz:13,mono:true,c:C.white})]),{fill:sc,w:2400}),
          cell(p([t(g.title,{b:true,sz:18})]),{fill:i%2?C.greyLight:C.white,w:5100}),
          cell(p([t(`Acc: ${g.acc}`,{b:true,sz:16,c:aCol(parseFloat(g.acc)/100||0.9)})],{ctr:true}),{fill:i%2?C.greyLight:C.white,w:1800}),
        ]}),
        new TableRow({children:[
          cell(p([t(g.sub,{b:true,sz:14,c:C.white})],{ctr:true}),{fill:sc,w:2400}),
          cell([p([t(g.md,{sz:16,i:true})])],{fill:i%2?C.greyLight:C.white,w:7500}),
        ]}),
      ]}),
      sp(16),
    );
  });

  sections.push(
    sp(30),
    new Paragraph({heading:HeadingLevel.HEADING_2,children:[t('What Changed Between Runs',{sz:24,b:true,c:C.dark})]}),
    p([t('The substrate classes (compute, solver, decomposer, memory_probe) show no change between runs because they do not learn — they compute. The Bandit is the only substrate that accumulates experience, so it is the only one that benefits from warm-start memory.',{sz:21})],{after:60}),
    new Table({width:{size:9300,type:WidthType.DXA},columnWidths:[2600,2000,2000,2700],rows:[
      new TableRow({children:[
        cell(p([t('Class',{b:true,sz:17,c:C.white})]),{fill:C.dark,w:2600}),
        cell(p([t('Cold',{b:true,sz:17,c:C.white})],{ctr:true}),{fill:C.dark,w:2000}),
        cell(p([t('Warm',{b:true,sz:17,c:C.white})],{ctr:true}),{fill:C.dark,w:2000}),
        cell(p([t('Why',{b:true,sz:17,c:C.white})]),{fill:C.dark,w:2700}),
      ]}),
      ...Object.keys(r1.final_acc).map((cls,i)=>{
        const cold=r1.final_acc[cls], warm=r2.final_acc[cls], delta=warm-cold;
        const bg = i%2?C.greyLight:C.white;
        const why = delta>0.05 ? 'Bandit posteriors warm-started — learned action preferences transferred' :
                    'Compute substrate — no learning, same result every time';
        return new TableRow({children:[
          cell(p([t(lbl(cls),{sz:16})]),{fill:bg,w:2600}),
          cell(p([t(`${Math.round(cold*100)}%`,{sz:17,c:aCol(cold)})],{ctr:true}),{fill:aBg(cold),w:2000}),
          cell(p([t(`${Math.round(warm*100)}%`,{b:delta>0.05,sz:17,c:aCol(warm)})],{ctr:true}),{fill:aBg(warm),w:2000}),
          cell(p([t(why,{sz:14,i:true})]),{fill:delta>0.05?C.greenLight:bg,w:2700}),
        ]});
      }),
    ]}),
    new Paragraph({children:[new PageBreak()]}),
  );
  return sections;
}

// ── TRACES ─────────────────────────────────────────────────────
function traceSection() {
  const sections = [
    new Paragraph({heading:HeadingLevel.HEADING_1,children:[t('Episode Traces',{b:true,sz:30,c:C.dark})]}),
    p([t('What was given. Which substrate fired. What it computed. The receipt.',{sz:21,i:true,c:C.grey})],{after:60}),
  ];

  const snaps = r1.snapshots.slice(0,5);
  snaps.forEach(snap=>{
    const right=snap.right, mark=right?'✓  CORRECT':'✗  WRONG';
    const col=right?C.green:C.red, bgH=right?C.greenLight:C.redLight;
    const subName = (snap.substrate||'').split('(')[0];
    const sc = SUB_C[subName]||C.grey;

    sections.push(
      new Table({width:{size:9300,type:WidthType.DXA},columnWidths:[1600,3000,2400,2300],rows:[
        new TableRow({children:[
          cell(p([t(`Ep ${snap.episode}`,{b:true,sz:19})]),{fill:C.greyLight,w:1600}),
          cell(p([t(lbl(snap.class),{b:true,sz:18})]),{fill:C.greyLight,w:3000}),
          cell(p([t(subName,{b:true,sz:16,c:C.white})],{ctr:true}),{fill:sc,w:2400}),
          cell(p([t(mark,{b:true,sz:18,c:col})],{ctr:true}),{fill:bgH,w:2300}),
        ]})
      ]}),
    );
    snap.problem.split('\n').forEach(line=>sections.push(p([t(line,{sz:16,mono:true})],{ind:360,after:2})));
    sections.push(p([
      t('Substrate: ',{sz:15,i:true,c:C.grey}),
      t(snap.explanation?.slice(0,90)||'',{sz:15,mono:true}),
    ],{before:10,after:6}));
    snap.choices?.forEach(ch=>{
      const isC=String(ch)===String(snap.chosen), isR=String(ch)===String(snap.correct);
      const bg=isC&&isR?C.greenLight:isC?C.redLight:isR?'E8F8F5':C.white;
      sections.push(new Table({width:{size:9300,type:WidthType.DXA},columnWidths:[9300],rows:[
        new TableRow({children:[cell(p([
          t(isC?' ► ':' ○ ',{b:true,c:isC?(right?C.green:C.red):C.grey,sz:18}),
          t(String(ch),{sz:16,mono:true,b:isC}),
          t(isR?'   ← correct':'',{sz:14,i:true,c:C.green}),
        ]),{fill:bg,w:9300})]})
      ]}));
    });
    sections.push(sp(40));
  });

  return sections;
}

// ── WHAT THIS MEANS ────────────────────────────────────────────
function closing() {
  return [
    new Paragraph({children:[new PageBreak()]}),
    new Paragraph({heading:HeadingLevel.HEADING_1,children:[t('What This Means',{b:true,sz:30,c:C.dark})]}),
    sp(4),
    p([t('The persistent memory result is honest about what kind of system this is. The compute substrates (solver, decomposer, compute, memory_probe) do not improve with warm start because they do not learn — they reason. They will always get cross-sequence problems right from episode 1, regardless of prior runs, because the answer is computed, not recalled.',{sz:21})],{after:80}),
    p([t('The Bandit does improve. +28% on code structure patterns because it accumulated genuine action preferences across 200 episodes and brought them forward. Those posteriors represent real learned experience — which structural contexts map to which correct choices — and they transfer.',{sz:21})],{after:80}),
    p([t('This is the architecture working as designed: ',{sz:21,b:true}),
       t('compute where compute is required, memory where memory is required, learning where learning is possible. Each component honest about its own nature.',{sz:21})],{after:80}),
    p([t('"Compute when compute is required. Memory when memory is required. The rest stays lean and honest."',{sz:22,i:true,c:C.grey})]),
  ];
}

// ── BUILD ──────────────────────────────────────────────────────
const children = [
  ...cover(),
  ...memorySection(),
  ...traceSection(),
  ...closing(),
];

const doc = new Document({
  numbering:{config:[{reference:'bullets',levels:[{level:0,format:LevelFormat.BULLET,text:'•',
    alignment:AlignmentType.LEFT,style:{paragraph:{indent:{left:720,hanging:360}}}}]}]},
  styles:{
    default:{document:{run:{font:'Arial',size:20}}},
    paragraphStyles:[
      {id:'Heading1',name:'Heading 1',basedOn:'Normal',next:'Normal',quickFormat:true,
        run:{size:30,bold:true,font:'Arial',color:C.dark},
        paragraph:{spacing:{before:320,after:160},outlineLevel:0}},
      {id:'Heading2',name:'Heading 2',basedOn:'Normal',next:'Normal',quickFormat:true,
        run:{size:24,bold:true,font:'Arial',color:C.dark},
        paragraph:{spacing:{before:200,after:100},outlineLevel:1}},
    ],
  },
  sections:[{
    properties:{page:{size:{width:12240,height:15840},margin:{top:1080,right:1080,bottom:1080,left:1080}}},
    footers:{default:new Footer({children:[new Paragraph({alignment:AlignmentType.CENTER,children:[
      new TextRun({text:'EmerEviro  ·  Routed Cognitive Architecture  ·  Evidence    ',size:16,color:C.grey}),
      new TextRun({children:[PageNumber.CURRENT],size:16,color:C.grey}),
    ]})]})},
    children,
  }],
});

Packer.toBuffer(doc).then(buf=>{
  fs.writeFileSync('/mnt/user-data/outputs/EmerEviro_Evidence.docx', buf);
  console.log('Done.');
});
