"""
Persistent Memory Layer
=======================
Uses the agent's built-in save_state/load_state for full fidelity persistence.
Also writes human-readable glyphs and cards (JSON) so you can inspect what was learned.

Glyphs: one per pattern class — what the agent discovered
Cards:  high-salience correct episodes — pinned for warm-start narrative
"""

import os, json, pickle, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, 'agents/deployable_biorag_hybrids')

from agents.deployable_biorag_hybrids.glyph_registry import (
    GlyphRegistry, Glyph, GlyphJson, GlyphEditability, Card,
    GlyphType, GlyphAuthority
)

MEMORY_DIR  = os.path.join(os.path.dirname(__file__), 'memory')
STATE_PATH  = os.path.join(MEMORY_DIR, 'agent_state.pkl')
GLYPHS_PATH = os.path.join(MEMORY_DIR, 'agent_glyphs.json')

CLASS_GLYPH_DEFS = {
    'cross_sequence':          ('g-cross-sequence@1.0.0',    'Cross Sequence Rule',          'compute'),
    'constraint_satisfaction': ('g-constraint-sat@1.0.0',    'Constraint Satisfaction Rule',  'solver'),
    'rule_inversion':          ('g-rule-inversion@1.0.0',    'Rule Inversion Detection',      'memory_probe'),
    'structural_analogy':      ('g-structural-analogy@1.0.0','Structural Analogy Transform',  'decomposer'),
    'code_pattern_hybrid':     ('g-code-pattern@1.0.0',      'Code Structure Invariant',      'bandit'),
}
CLASS_MD = {
    'cross_sequence':          'C[n] = A[n] OP B[n]. Find OP from known C values, apply to last pair. Surface changes; operation is stable.',
    'constraint_satisfaction': 'One answer satisfies ALL constraints simultaneously. Evaluate globally, not locally.',
    'rule_inversion':          'Sequence follows rule R then inverts. Inversion point detectable from delta sign change.',
    'structural_analogy':      'Transform is compound (×m+c). Decompose from A→B, apply identically to C.',
    'code_pattern_hybrid':     'Structural programming invariants. Stable across surfaces. Bandit learns from binary feedback.',
}


class PersistentMemory:

    def __init__(self):
        os.makedirs(MEMORY_DIR, exist_ok=True)

    def exists(self) -> bool:
        return os.path.exists(STATE_PATH)

    def save(self, agent, by_class: dict, snapshots: list, run_number: int):
        # Full agent state via built-in
        agent.save_state(STATE_PATH)

        # Glyphs + cards as readable JSON
        class_stats = {
            cls: {
                'accuracy': sum(v[-50:])/min(50,len(v)) if v else 0.0,
                'episodes': len(v),
            }
            for cls, v in by_class.items()
        }

        glyphs = []
        for cls, (gid, title, sub) in CLASS_GLYPH_DEFS.items():
            if cls not in class_stats: continue
            stats = class_stats[cls]
            glyphs.append({
                'id': gid, 'title': title,
                'md': f"{CLASS_MD[cls]}\nLearned: {stats['accuracy']:.0%} over {stats['episodes']} episodes.",
                'substrate': sub,
                'accuracy': stats['accuracy'],
                'episodes': stats['episodes'],
                'tags': [cls, sub, f"acc_{int(stats['accuracy']*100)}pct"],
            })

        cards = [
            {
                'id': f"card-ep{s['episode']}-{s['class'][:8]}",
                'episode': s['episode'],
                'class': s['class'],
                'substrate': s['substrate'],
                'correct': s['right'],
                'explanation': s.get('explanation','')[:100],
                'salience': 0.9 if s['right'] else 0.5,
                'pinned': s['right'],
            }
            for s in snapshots if s.get('right')
        ]

        with open(GLYPHS_PATH, 'w') as f:
            json.dump({'run_number': run_number,
                       'class_stats': class_stats,
                       'glyphs': glyphs,
                       'cards': cards}, f, indent=2)

        print(f"\n  Memory saved → run {run_number}")
        print(f"    Agent state: {STATE_PATH}")
        print(f"    Glyphs: {len(glyphs)}  Cards: {len(cards)}")
        for cls, s in class_stats.items():
            print(f"    {cls:<32} {s['accuracy']:.0%}")

    def load_into(self, agent) -> dict:
        """Load state into agent. Returns glyph metadata."""
        if not self.exists():
            print("  No prior memory found. Starting cold.")
            return {}

        agent.load_state(STATE_PATH)

        meta = {}
        if os.path.exists(GLYPHS_PATH):
            with open(GLYPHS_PATH) as f:
                meta = json.load(f)

        run_num = meta.get('run_number', 0)
        stats   = meta.get('class_stats', {})
        print(f"\n  Memory loaded from run {run_num}:")
        print(f"    Agent state fully restored (bandit posteriors, hippocampal traces)")
        for cls, s in stats.items():
            bar = '█'*int(s['accuracy']*14)+'░'*(14-int(s['accuracy']*14))
        print(f"    Prior class accuracy:")
        for cls, s in stats.items():
            print(f"      {cls:<32} {s['accuracy']:.0%}  ({s['episodes']} ep)")

        return meta
