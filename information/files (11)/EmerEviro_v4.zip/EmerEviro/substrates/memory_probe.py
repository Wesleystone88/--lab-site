"""
Memory Probe Substrate
======================
Handles problems requiring temporal sequence memory.

Primary class: rule_inversion
Rule: sequence follows R for N steps, then inverts. Inversion IS the rule.

The Bandit sees context features and guesses. It cannot hold the sequence
in memory and detect where the rule flips.

This substrate reads the given sequence, detects the inversion point,
identifies the post-inversion delta, and extrapolates forward.

This is memory + arithmetic. The hippocampal trace stores the sequence
as it arrived. The probe reads it back in order and detects structural change.
"""

from __future__ import annotations
from typing import Any


def detect_inversion(sequence: list) -> tuple[int, int, str]:
    """
    Detect where the sequence changes direction and by what delta.

    Returns (inversion_index, post_delta, direction_after)
    """
    if len(sequence) < 3:
        return -1, 0, 'unknown'

    # Compute deltas
    deltas = [sequence[i+1] - sequence[i] for i in range(len(sequence)-1)]

    # Find where sign changes (inversion point)
    inversion_at = -1
    for i in range(1, len(deltas)):
        if deltas[i] != 0 and deltas[i-1] != 0:
            if (deltas[i] > 0) != (deltas[i-1] > 0):
                inversion_at = i
                break

    if inversion_at == -1:
        # No inversion detected — might still be coming
        # Predict based on current trend
        return -1, deltas[-1] if deltas else 0, 'continuing'

    post_delta = deltas[inversion_at]
    direction  = 'up' if post_delta > 0 else 'down'
    return inversion_at, post_delta, direction


def solve_rule_inversion(features: dict, problem: dict, choices: list) -> tuple[Any, str]:
    """
    Read the given sequence, detect the inversion, extrapolate.
    """
    given = problem.get('given', [])
    if not given or len(given) < 2:
        return choices[0] if choices else None, "sequence_too_short"

    inversion_at, post_delta, direction = detect_inversion(given)

    # Next value = last given + post-inversion delta
    predicted = given[-1] + post_delta

    explanation = (f"sequence={given}, inversion_at={inversion_at}, "
                   f"post_delta={post_delta}, predicted={predicted}")

    # Match to choices
    if choices:
        try:
            numeric_choices = [(ch, float(ch)) for ch in choices]
            best = min(numeric_choices, key=lambda x: abs(x[1] - predicted))
            if abs(best[1] - predicted) < 1.5:
                return best[0], explanation
            # If no close match, try with opposite delta (inversion might be next)
            alt_predicted = given[-1] - post_delta
            best_alt = min(numeric_choices, key=lambda x: abs(x[1] - alt_predicted))
            if abs(best_alt[1] - alt_predicted) < 1.5:
                return best_alt[0], explanation + f" [alt_inversion={alt_predicted}]"
            # Return closest overall
            return best[0], explanation + " [closest_match]"
        except (ValueError, TypeError):
            pass

    return str(int(predicted)), explanation


def run(features: dict, problem: dict, choices: list) -> tuple[Any, str]:
    cls = features.get('class', '')
    if cls == 'rule_inversion':
        return solve_rule_inversion(features, problem, choices)
    return None, "not_my_class"
