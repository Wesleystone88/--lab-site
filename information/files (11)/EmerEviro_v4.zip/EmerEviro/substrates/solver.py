"""
Solver Substrate
================
Handles problems requiring global constraint satisfaction.

Primary class: constraint_satisfaction
Rule: find N where ALL constraints hold simultaneously.

The Bandit optimizes locally — it learns which answers tend to win.
But constraint satisfaction has exactly one correct answer per problem,
and the constraints change every episode.
You cannot memorize the answer. You must satisfy the constraints.

This substrate parses the constraint list from the problem,
evaluates each choice against all constraints simultaneously,
and returns the one that satisfies everything.
"""

from __future__ import annotations
import re
from typing import Any


def parse_constraints(constraints: list[str]) -> list[callable]:
    """
    Turn constraint strings into evaluable functions.

    Handles:
        "divisible by N"
        "digit sum = N"
        "even number" / "odd number"
        "in range N to M"
    """
    fns = []
    for c in constraints:
        c_lower = c.lower().strip()

        # divisible by N
        m = re.search(r'divisible by (\d+)', c_lower)
        if m:
            d = int(m.group(1))
            fns.append(lambda x, d=d: x % d == 0)
            continue

        # digit sum = N
        m = re.search(r'digit sum\s*=\s*(\d+)', c_lower)
        if m:
            target = int(m.group(1))
            fns.append(lambda x, t=target: sum(int(d) for d in str(abs(x))) == t)
            continue

        # even/odd
        if 'even' in c_lower:
            fns.append(lambda x: x % 2 == 0)
            continue
        if 'odd' in c_lower:
            fns.append(lambda x: x % 2 != 0)
            continue

        # in range N to M
        m = re.search(r'in range (\d+) to (\d+)', c_lower)
        if m:
            lo, hi = int(m.group(1)), int(m.group(2))
            fns.append(lambda x, lo=lo, hi=hi: lo <= x <= hi)
            continue

    return fns


def solve_constraint_satisfaction(features: dict, problem: dict, choices: list) -> tuple[Any, str]:
    """
    Evaluate each choice against all constraints.
    Return the one that satisfies all of them.
    """
    constraints = problem.get('constraints', [])
    if not constraints or not choices:
        return choices[0] if choices else None, "no_constraints"

    fns = parse_constraints(constraints)
    if not fns:
        return choices[0] if choices else None, "unparseable_constraints"

    results = []
    for ch in choices:
        try:
            val = int(float(ch))
            satisfied = sum(1 for fn in fns if fn(val))
            results.append((ch, val, satisfied))
        except (ValueError, TypeError):
            results.append((ch, None, 0))

    # Find choice satisfying most constraints
    best = max(results, key=lambda x: x[2])
    explanation = (f"choice={best[0]} satisfies {best[2]}/{len(fns)} constraints: "
                   f"{[c for c, fn in zip(constraints, fns) if best[1] is not None and fn(best[1])]}")

    return best[0], explanation


def run(features: dict, problem: dict, choices: list) -> tuple[Any, str]:
    cls = features.get('class', '')
    if cls == 'constraint_satisfaction':
        return solve_constraint_satisfaction(features, problem, choices)
    return None, "not_my_class"
