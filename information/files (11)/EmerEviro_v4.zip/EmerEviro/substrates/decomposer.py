"""
Decomposer Substrate — v3
=========================
Disambiguates compound transforms by checking BOTH (a→b) AND (c→correct).
Since we only have choices, we test each transform against all choices
and pick the one producing an answer consistent with the transform.
"""
from __future__ import annotations
from typing import Any


KNOWN_TRANSFORMS = [
    ("double_plus",   lambda x: x * 2 + 3),
    ("triple_minus",  lambda x: x * 3 - 2),
    ("negate_shift",  lambda x: -x + 10),
    ("square_minus",  lambda x: x * x - 1),
    ("linear_plus4",  lambda x: x + 4),
    ("linear_times2", lambda x: x * 2),
    ("linear_times3", lambda x: x * 3),
]


def solve_structural_analogy(features: dict, problem: dict, choices: list) -> tuple[Any, str]:
    a = problem.get('a')
    b = problem.get('b')
    c = problem.get('c')
    if any(v is None for v in [a, b, c]):
        return choices[0] if choices else None, "missing_abc"

    try:
        a, b, c = int(a), int(b), int(c)
        numeric_choices = [(ch, float(ch)) for ch in choices]
    except (ValueError, TypeError):
        return choices[0] if choices else None, "type_error"

    # Step 1: find transforms that correctly map a→b
    matching = []
    for name, fn in KNOWN_TRANSFORMS:
        try:
            if abs(fn(a) - b) < 0.01:
                matching.append((name, fn))
        except Exception:
            continue

    # Step 2: if multiple transforms match a→b, pick the one
    # whose output for c is closest to a choice
    # (the "correct" transform will match a choice exactly)
    best_answer, best_expl, best_err = None, "no_match", float('inf')

    for name, fn in (matching if matching else KNOWN_TRANSFORMS):
        try:
            predicted = fn(c)
            nearest = min(numeric_choices, key=lambda x: abs(x[1] - predicted))
            err = abs(nearest[1] - predicted)
            if err < best_err:
                best_err = err
                best_answer = nearest[0]
                best_expl = f"{name}: {a}→{b}✓ {c}→{predicted:.0f}≈{nearest[0]}"
        except Exception:
            continue

    # Also try brute-force linear: b = a*m + c_const
    for m in range(-5, 6):
        if m == 0: continue
        c_const = b - a * m
        predicted = m * c + c_const
        nearest = min(numeric_choices, key=lambda x: abs(x[1] - predicted))
        err = abs(nearest[1] - predicted)
        if err < best_err:
            best_err = err
            best_answer = nearest[0]
            best_expl = f"linear×{m}+{c_const}: {a}→{b}✓ {c}→{predicted:.0f}≈{nearest[0]}"

    if best_answer is not None:
        return best_answer, best_expl

    return choices[0] if choices else None, "fallback"


def run(features: dict, problem: dict, choices: list) -> tuple[Any, str]:
    if features.get('class') == 'structural_analogy':
        return solve_structural_analogy(features, problem, choices)
    return None, "not_my_class"
