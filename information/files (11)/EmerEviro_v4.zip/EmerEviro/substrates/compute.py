"""
Compute Substrate
=================
Handles problems that require arithmetic.

Primary class: cross_sequence
Rule: C[n] = A[n] OP B[n] where OP ∈ {add, subtract, multiply, parity}

The Bandit cannot do this. It learns preferences, not operations.
This substrate tries each operation, finds the one consistent
with the given C values, then applies it to produce the answer.

This is pure computation. No learning. No uncertainty.
Either the operation is discoverable from the given values or it isn't.
"""

from __future__ import annotations
from typing import Any


OPERATIONS = {
    'add':      lambda a, b: a + b,
    'subtract': lambda a, b: a - b,
    'multiply': lambda a, b: a * b,
    'parity':   lambda a, b: (a + b) % 2,
}


def solve_cross_sequence(features: dict, problem: dict, choices: list) -> tuple[Any, str]:
    """
    Given A, B, C_given — find the hidden operation and complete C.

    Returns (answer, explanation)
    """
    A       = problem.get('A', [])
    B       = problem.get('B', [])
    C_given = problem.get('C_given', [])

    if not A or not B or not C_given:
        return None, "insufficient_data"

    # Try each operation against the known C values
    for op_name, op_fn in OPERATIONS.items():
        predicted = [op_fn(a, b) for a, b in zip(A, B)]
        # Check if predicted matches all given C values
        if all(abs(predicted[i] - C_given[i]) < 0.001 for i in range(len(C_given))):
            # Operation found — compute the missing value
            answer = op_fn(A[-1], B[-1])
            explanation = f"A[n] {op_name} B[n] → {A[-1]} {op_name} {B[-1]} = {answer}"

            # Return closest match from choices
            if choices:
                try:
                    numeric_choices = [(c, abs(float(c) - answer)) for c in choices]
                    best = min(numeric_choices, key=lambda x: x[1])
                    if best[1] < 0.001:
                        return best[0], explanation
                    # If exact match not in choices, return closest
                    return best[0], explanation + f" (closest in choices)"
                except (ValueError, TypeError):
                    pass

            return str(int(answer)), explanation

    # No clean operation found — fall back to closest choice
    op_hint = features.get('op_hint', 'add')
    op_fn   = OPERATIONS.get(op_hint, OPERATIONS['add'])
    answer  = op_fn(A[-1], B[-1])

    if choices:
        try:
            best = min(choices, key=lambda c: abs(float(c) - answer))
            return best, f"fallback_{op_hint}: {answer}"
        except (ValueError, TypeError):
            pass

    return choices[0] if choices else None, "fallback_no_match"


def run(features: dict, problem: dict, choices: list) -> tuple[Any, str]:
    cls = features.get('class', '')
    if cls == 'cross_sequence':
        return solve_cross_sequence(features, problem, choices)
    return None, "not_my_class"
