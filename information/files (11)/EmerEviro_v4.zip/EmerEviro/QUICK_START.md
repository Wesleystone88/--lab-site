# EmerEviro Quick Start Guide

## Installation & Setup ✅ DONE

```bash
# Environment
cd C:\Users\timmy\OneDrive\Desktop\EmerEviro
python -m venv .venv
.venv\Scripts\Activate.ps1

# Dependencies
pip install sympy

# Test
python run_experiment.py          # Run baseline experiment
python examples/run_with_biorag.py  # Test BioRAG adapters
```

## Project Structure

```
EmerEviro/
├── bus/
│   ├── schemas.py       ← Action, Observation, StepResult
│   ├── bus.py          ← EnvironmentBus, AgentClient base class
│   └── __init__.py
├── environment/
│   ├── math_env.py     ← TaskGenerator, Library, MathEnvironment
│   └── __init__.py
├── agents/
│   ├── null_models.py         ← NullB (no-mint), NullC (episodic)
│   ├── claude_agent.py        ← LLM-powered agent
│   ├── biorag_adapters.py     ← Bridges native BioRAG → EmerEviro
│   └── __init__.py
├── metrics/
│   ├── tracker.py      ← MetricsTracker, BCG, Reuse Rate
│   └── __init__.py
├── deployable_biorag_hybrids/  ← 5/6-pillar agents (native)
│   ├── quint_biorag.py, sext_biorag.py, etc.
│   ├── Bandit_engine/, Time_engine/
│   └── ...
├── run_experiment.py          ← Main harness (100 episodes × 3 agents)
├── examples/
│   ├── run_with_biorag.py    ← Example: BioRAG + EmerEviro
│   └── __init__.py
├── .github/
│   └── copilot-instructions.md  ← AI agent guidance
├── BIORAG_INTEGRATION.md        ← Full integration guide
├── BIORAG_SETUP_COMPLETE.md     ← This setup summary
├── CONFIG.md                    ← Config knobs (EPISODES, CAPACITY, etc.)
└── README.md                    ← Original project README
```

## The Bus Protocol

Everything crosses one boundary — **EnvironmentBus**:

```python
# Agent side: implement select_action()
class MyAgent(AgentClient):
    def select_action(self, obs: Observation) -> Action:
        return Action(tier=ActionTier.ASSEMBLE, payload={...})

# Bus: validates & routes
bus = EnvironmentBus(environment)
obs = bus.reset()
result = bus.act(action)  # → next obs + reward

# Three action tiers (cost-constrained):
# ASSEMBLE (0.05¢)  — combine existing atoms/primitives
# MUTATE (0.30¢)    — edit an existing primitive
# MINT (1.00¢)      — define a new primitive (uses library capacity)
```

## Three Emergence Tests (Null Models)

Emergence is claimed only when **all** are true:

| Metric | Candidate Must Beat | What it Tests |
|---|---|---|
| **Reward** | NullB (no-mint) | Can tasks be solved without abstraction? |
| **Reward** | NullC (episodic) | Does structure help over raw caching? |
| **Reuse Rate** | NullB | Is the agent discovering compositional patterns? |
| **BCG** | NullC | How much does library compress the trace? |

## Running Agents

Agents placed in the `agents/` package are automatically discovered by
`run_experiment.py`. You don't have to edit the harness or import anything –
just drop a Python file defining a subclass of `AgentClient` and run the
script from the workspace root.

### 1. Baseline Candidate
```bash
python run_experiment.py
```
Output:
```
Candidate:         reward=+20.63  reuse=0.52
Null B (no-mint):  reward=-1.00   reuse=0.00
Null C (episodic): reward=-1.00   reuse=0.00
→ Candidate wins! (but only vs these specific nulls)
```

### 2. With BioRAG Adapters (Fallback)
```bash
python examples/run_with_biorag.py
```
Output:
```
Quint-BioRAG:  reward=+39.00  (perfect)
Sext-BioRAG:   reward=+39.00  (perfect)
→ Adapters work! Now wire in real native agents...
```

### 3. With Real BioRAG Agent

By default the experiment harness will wire the adapters to the real
native agents if they can be imported from `deployable_biorag_hybrids`.  So
running `python run_experiment.py` after cloning the hybrid code will already
execute vertical experiments with Quint/Sext out of the box.  The following
snippet shows how you could do it manually if you preferred explicit
control:

```python
from deployable_biorag_hybrids.quint_biorag import QuintBioRAGAgent
from agents.biorag_adapters import QuintBioRAGAdapter

# Step 1: Create native agent
native = QuintBioRAGAgent(seed=42, tfe_tau=3600.0)

# Step 2: Wrap in adapter
bus = EnvironmentBus(MathEnvironment(...))
adapter = QuintBioRAGAdapter(bus, native, seed=42)

# Step 3: Run episode
reward = adapter.run_episode()
print(f"Reward: {reward}")

# Step 4: Inspect pillar decisions
for step in adapter.episode_trace:
    print(f"  {step['step']}: chose {step['chosen_action']} via {step['source']}")
```

## Key Metrics

After each episode:
```python
tracker = MetricsTracker()
tracker.record(episode_record)
summary = tracker.summary()

print(f"Mean Reward: {summary['mean_reward']:.2f}")      # -1 to +2
print(f"Reuse Rate: {summary['reuse_rate']:.2f}")        # 0 to 1
print(f"BCG: {summary['bcg']:.1f}")                      # bits saved
print(f"Time-to-Stability: {summary['time_to_stability']}")  # episodes
```

### What They Mean

- **Reward**: Task performance (2.0 = perfect, 0 = neutral, -1 = invalid action)
- **Reuse Rate**: Fraction of steps invoking library primitives (higher = learning to abstract)
- **BCG**: Behavioral Compression Gain (how much smaller are traces when using library?)
- **Time-to-Stability**: Convergence speed (how fast does agent stop changing behavior?)

## Customization Points

### 1. Add Custom Agent
Simply create a new module under `agents/` with a subclass of
`AgentClient`.  The experiment harness will pick it up automatically – no
edits required.

```python
# agents/my_learning_agent.py
from bus.bus import AgentClient
from bus.schemas import Action, ActionTier, Observation

class MyLearningAgent(AgentClient):
    def select_action(self, obs: Observation) -> Action:
        # Your logic here
        # obs has: task, library, capacity_used, budget_remaining
        return Action(tier=ActionTier.ASSEMBLE, payload={...})
```

### 2. Tune Task Difficulty
```python
# In CONFIG.md or math_env.py
CAPACITY_TOTAL = 50        # library size limit
EPISODE_BUDGET = 5.0       # max reward per episode
COST_MINT = 1.0           # cost to define new primitive
```

### 3. Enrich Adapter Mapping
```python
# In biorag_adapters.py, override:
def _observation_to_condition(self, obs: Observation) -> Dict[str, str]:
    return {
        "library_size": str(len(obs.library)),
        "budget_left": f"{obs.budget_remaining:.2f}",
        # Add more context for BioRAG pillars to exploit
    }
```

## Troubleshooting

| Issue | Fix |
|---|---|
| `ImportError: No module named 'sympy'` | `pip install sympy` |
| `UnicodeEncodeError` on Windows | Use ASCII symbols (done in run_experiment.py) |
| BioRAG agent fails silently | Check `adapter.episode_trace` for error logs |
| Rewards stay at -1 | Check `obs.available_atoms` and task format |

## What's Next

1. **Integrate Real BioRAG**: Load QuintBioRAGAgent or SextBioRAGAgent and compare emergence metrics
2. **Longer Runs**: Try 1000+ episodes to see if agent discovers hidden invariants (distributivity, factoring)
3. **Multi-Generator Probe**: Swap task generator mid-run to test if agent learned deep patterns vs. surface shortcuts
4. **Scaling**: Extend to symbolic logic, compression, or other domains (currently math only)

## Files to Read

- **Guidance**: [.github/copilot-instructions.md](.github/copilot-instructions.md)
- **Integration**: [BIORAG_INTEGRATION.md](BIORAG_INTEGRATION.md)
- **Protocol**: [bus/schemas.py](bus/schemas.py)
- **Example**: [examples/run_with_biorag.py](examples/run_with_biorag.py)

---

**Status**: ✅ EmerEviro + BioRAG Adapters **ready to run**. Choose your agent, tune the config, and measure emergence.
