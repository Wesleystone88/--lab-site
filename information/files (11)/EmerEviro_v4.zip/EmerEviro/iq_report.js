const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  AlignmentType, HeadingLevel, BorderStyle, WidthType, ShadingType,
  VerticalAlign, PageNumber, PageBreak, Footer
} = require('docx');
const fs = require('fs');

const data = JSON.parse(fs.readFileSync('/tmp/iq_data.json', 'utf8'));

const C = {
  black: '111111', dark: '0D1B2A', accent: '1B4F72', accent2: '1A5276',
  green: '1E8449', greenLight: 'EAFAF1', red: 'C0392B', redLight: 'FDEDEC',
  amber: 'D68910', amberLight: 'FEF9E7', grey: '717D7E', greyLight: 'F2F3F4',
  white: 'FFFFFF', rule: 'D5D8DC', highlight: 'EBF5FB',
  gold: 'B7950B', silver: '707B7C',
};

const CLASS_META = {
  'constraint_satisfaction': { label: 'Constraint Satisfaction', color: C.accent,  difficulty: 'Hard',    why: 'Multiple rules must ALL hold simultaneously. Finding the single answer that satisfies every constraint requires global reasoning — not local optimization.' },
  'rule_inversion':          { label: 'Rule Inversion',          color: C.accent2, difficulty: 'Hard',    why: 'The pattern holds, then inverts. Any system that extrapolates the first pattern gets the wrong answer every time after the inversion point.' },
  'structural_analogy':      { label: 'Structural Analogy',      color: C.grey,    difficulty: 'Hard',    why: 'A→B as C→? where the transformation is compound. Simple ratio or difference approaches fail. Requires decomposing and reapplying the full transformation.' },
  'code_pattern_hybrid':     { label: 'Code Structure',          color: C.green,   difficulty: 'Medium',  why: 'Structural programming invariants expressed across surfaces. Dependency order and guard-before-use patterns. These transfer across numeric and code representations.' },
  'cross_sequence':          { label: 'Cross-Sequence',          color: C.red,     difficulty: 'Hardest', why: 'The rule lives BETWEEN series. No amount of looking at C alone yields the answer. Requires holding A, B, and C in working memory simultaneously and finding the hidden operation.' },
};

const border = (color=C.rule) => ({ style: BorderStyle.SINGLE, size: 1, color });
const borders = (color=C.rule) => ({ top: border(color), bottom: border(color), left: border(color), right: border(color) });
const margins = { top: 100, bottom: 100, left: 140, right: 140 };

const cell = (children, opts={}) => new TableCell({
  borders: borders(opts.borderColor || C.rule),
  margins,
  width: opts.w ? { size: opts.w, type: WidthType.DXA } : undefined,
  shading: opts.fill ? { fill: opts.fill, type: ShadingType.CLEAR } : undefined,
  verticalAlign: VerticalAlign.CENTER,
  children: Array.isArray(children) ? children : [children],
});

const t = (text, opts={}) => new TextRun({
  text: String(text), size: opts.size||20, bold: opts.bold||false,
  color: opts.color||C.black, font: opts.mono ? 'Courier New' : 'Calibri',
  italics: opts.italic||false,
});

const p = (children, opts={}) => new Paragraph({
  alignment: opts.center ? AlignmentType.CENTER : AlignmentType.LEFT,
  spacing: { before: opts.before||0, after: opts.after||60 },
  indent: opts.indent ? { left: opts.indent } : undefined,
  children: Array.isArray(children) ? children : [children],
});

const sp = n => p([t('', {size:n})]);
const hr = () => p([], { before: 60, after: 60 });

const bar = (acc, len=14) => {
  const filled = Math.round(acc * len);
  return '█'.repeat(filled) + '░'.repeat(len - filled);
};

// ── COVER ──────────────────────────────────────────────────────
function cover() {
  return [
    sp(80),
    p([t('HIGH-IQ PATTERN', {size:44, bold:true, color:C.dark})], {center:true}),
    p([t('EMERGENCE TEST', {size:44, bold:true, color:C.accent})], {center:true}),
    sp(20),
    p([t('What the agent was given. What it built. What it couldn\'t.', {size:22, italic:true, color:C.grey})], {center:true}),
    sp(80),
    new Table({
      width: { size: 8400, type: WidthType.DXA },
      columnWidths: [1680,1680,1680,1680,1680],
      rows: [
        new TableRow({ children: Object.entries(CLASS_META).map(([k,m]) =>
          cell(p([t(m.label, {bold:true, size:17, color:C.white})], {center:true}), {fill:m.color, w:1680})
        )}),
        new TableRow({ children: Object.entries(CLASS_META).map(([k,m]) => {
          const acc = data.final_acc[k] || 0;
          const bg = acc >= 0.7 ? C.greenLight : acc >= 0.4 ? C.amberLight : C.redLight;
          return cell(p([t(`${Math.round(acc*100)}%`, {bold:true, size:22, color: acc>=0.7?C.green:acc>=0.4?C.amber:C.red})], {center:true}), {fill:bg, w:1680});
        })}),
        new TableRow({ children: Object.entries(CLASS_META).map(([k,m]) =>
          cell(p([t(m.difficulty, {size:16, italic:true, color:C.grey})], {center:true}), {fill:C.white, w:1680})
        )}),
      ]
    }),
    sp(60),
    p([t('SextBioRAG · 6-Pillar Biological Architecture · 500 Episodes · No Prompting', {size:18, color:C.grey})], {center:true}),
    sp(20),
    p([t('Five pattern classes designed to break surface-level systems.', {size:20, bold:true, color:C.dark})], {center:true}),
    p([t('One class mastered. Four showing genuine difficulty. All honest.', {size:20, italic:true, color:C.grey})], {center:true}),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

// ── WHAT THIS IS ───────────────────────────────────────────────
function intro() {
  return [
    new Paragraph({ heading: HeadingLevel.HEADING_1, children: [t('What This Test Is', {bold:true, size:28, color:C.dark})] }),
    sp(6),
    p([
      t('These are not standard IQ questions. They are specifically chosen to fail pattern-matching systems — LLMs, standard RL agents, lookup tables. The hidden rule in each class cannot be found by looking at the surface. It requires holding multiple sequences in memory simultaneously, detecting structure across representations, or satisfying constraints globally.', {size:21})
    ], {after:80}),
    p([t('The five classes:', {size:21, bold:true})], {after:40}),
    ...Object.entries(CLASS_META).map(([k, m]) =>
      p([
        t(`${m.label} (${m.difficulty}): `, {bold:true, size:20, color:m.color}),
        t(m.why, {size:20}),
      ], {indent:360, after:40})
    ),
    sp(40),
    p([
      t('The agent never sees the rule. It sees structural features — class type, trend direction, operation hint, constraint flags — and learns action preferences from binary feedback alone: correct or wrong. ', {size:21}),
      t('The numbers change every episode. The structure stays the same.', {size:21, bold:true}),
    ], {after:100}),
    new Paragraph({ children: [new PageBreak()] }),
  ];
}

// ── PER-CLASS LEARNING CURVE ───────────────────────────────────
function classSection(key) {
  const meta  = CLASS_META[key];
  const curve = data.curves[key] || [];
  const finalAcc = data.final_acc[key] || 0;
  const mastered = finalAcc >= 0.7;

  const sections = [
    new Paragraph({ heading: HeadingLevel.HEADING_2, children: [
      t(`${meta.label}  `, {bold:true, size:26, color:meta.color}),
      t(`[${meta.difficulty}]`, {size:20, italic:true, color:C.grey}),
    ]}),
    p([
      t(`Final accuracy: `, {size:20}),
      t(`${Math.round(finalAcc*100)}%`, {bold:true, size:22, color: mastered?C.green:finalAcc>=0.4?C.amber:C.red}),
      t(`  ${mastered ? '← Mastered' : finalAcc>=0.4 ? '← Learning' : '← Genuinely difficult'}`, {size:18, italic:true, color:C.grey}),
    ], {after:40}),
    p([t(meta.why, {size:19, italic:true, color:C.grey})], {after:60}),
  ];

  // Learning curve table
  if (curve.length > 0) {
    const rows = [
      new TableRow({ tableHeader: true, children: [
        cell(p([t('Episodes', {bold:true, size:17, color:C.white})]), {fill:meta.color, w:1400}),
        cell(p([t('Progress', {bold:true, size:17, color:C.white})]), {fill:meta.color, w:5600}),
        cell(p([t('Acc', {bold:true, size:17, color:C.white})], {center:true}), {fill:meta.color, w:800}),
      ]})
    ];

    curve.forEach((w, i) => {
      const acc = w.acc;
      const barStr = bar(acc);
      const col = acc >= 0.7 ? C.green : acc >= 0.4 ? C.amber : C.red;
      const bg  = i%2 ? C.greyLight : C.white;
      rows.push(new TableRow({ children: [
        cell(p([t(`${w.start}–${w.end}`, {size:16, mono:true})]), {fill:bg, w:1400}),
        cell(p([t(barStr, {size:16, mono:true, color:col})]), {fill:bg, w:5600}),
        cell(p([t(`${Math.round(acc*100)}%`, {bold:acc>=0.7, size:17, color:col})], {center:true}), {fill:bg, w:800}),
      ]}));
    });

    sections.push(
      new Table({ width: {size:7800, type:WidthType.DXA}, columnWidths:[1400,5600,800], rows }),
      sp(40),
    );
  }

  return sections;
}

// ── EPISODE SNAPSHOTS ──────────────────────────────────────────
function snapshots() {
  const sections = [
    new Paragraph({ heading: HeadingLevel.HEADING_1, children: [t('Episode Snapshots', {bold:true, size:28, color:C.dark})] }),
    p([t('Exactly what the agent saw. Exactly what it chose. Right or wrong — you can see it.', {size:21, italic:true, color:C.grey})], {after:80}),
  ];

  data.snapshots.forEach(snap => {
    const meta   = CLASS_META[snap.class] || {};
    const right  = snap.right;
    const color  = right ? C.green : C.red;
    const bgHead = right ? C.greenLight : C.redLight;
    const mark   = right ? '✓  CORRECT' : '✗  WRONG';

    sections.push(
      // Episode header
      new Table({
        width: {size:9000, type:WidthType.DXA}, columnWidths:[2200,3400,1800,1600],
        rows: [new TableRow({ children: [
          cell(p([t(`Episode ${snap.episode}`, {bold:true, size:20, color:C.dark})]), {fill:C.greyLight, w:2200}),
          cell(p([t(meta.label||snap.class, {bold:true, size:20, color:meta.color||C.dark})]), {fill:C.greyLight, w:3400}),
          cell(p([t(`Surface: ${snap.surface}`, {size:18, color:C.grey})], {center:true}), {fill:C.greyLight, w:1800}),
          cell(p([t(mark, {bold:true, size:19, color})], {center:true}), {fill:bgHead, w:1600}),
        ]})]
      }),
    );

    // Structural context the agent saw
    const ctxEntries = Object.entries(snap.ctx || {});
    if (ctxEntries.length > 0) {
      sections.push(
        p([t('Structural context (what the agent actually saw):', {size:17, italic:true, color:C.grey})], {before:40, after:10}),
        new Table({
          width: {size:9000, type:WidthType.DXA}, columnWidths:[2400,6600],
          rows: ctxEntries.map(([k,v], i) => new TableRow({ children: [
            cell(p([t(k, {size:16, mono:true, color:C.accent})]), {fill: i%2?C.greyLight:C.white, w:2400}),
            cell(p([t(v, {size:16, mono:true, bold:true})]), {fill: i%2?C.greyLight:C.white, w:6600}),
          ]}))
        }),
      );
    }

    // The problem
    sections.push(p([t('Problem:', {size:17, italic:true, color:C.grey})], {before:20, after:6}));
    snap.problem.split('\n').forEach(line => {
      sections.push(p([t(line, {size:18, mono:true})], {indent:360, after:4}));
    });

    // Choices
    sections.push(p([t('Choices:', {size:17, italic:true, color:C.grey})], {before:16, after:6}));
    const choiceRows = snap.choices.map(ch => {
      const isChosen  = String(ch) === String(snap.chosen);
      const isCorrect = String(ch) === String(snap.correct);
      const bg = isChosen && isCorrect ? C.greenLight : isChosen ? C.redLight : isCorrect ? C.greenLight : C.white;
      const prefix = isChosen ? '► ' : '  ';
      const suffix = isCorrect ? '  ← correct' : '';
      return new TableRow({ children: [
        cell(p([
          t(prefix, {bold:true, color: isChosen?(right?C.green:C.red):C.grey, size:18}),
          t(String(ch), {size:18, mono:true, bold:isChosen}),
          t(suffix, {size:16, italic:true, color:C.green}),
        ]), {fill:bg, w:9000}),
      ]});
    });
    sections.push(
      new Table({ width:{size:9000,type:WidthType.DXA}, columnWidths:[9000], rows:choiceRows }),
    );

    // Verdict
    sections.push(
      p([
        t('Agent chose: ', {size:18}),
        t(snap.chosen, {bold:true, size:18, color}),
        t(`  via ${snap.source}`, {size:16, italic:true, color:C.grey}),
        t('    Correct: ', {size:18}),
        t(snap.correct, {bold:true, size:18, color:C.green}),
      ], {before:20, after:60}),
    );
  });

  return sections;
}

// ── CONCLUSION ─────────────────────────────────────────────────
function conclusion() {
  return [
    new Paragraph({ children: [new PageBreak()] }),
    new Paragraph({ heading: HeadingLevel.HEADING_1, children: [t('What This Shows', {bold:true, size:28, color:C.dark})] }),
    sp(6),
    p([
      t('Code structure patterns: mastered at 100%. ', {size:21, bold:true, color:C.green}),
      t('The structural features — dependency order, guard-before-use — are stable across surfaces. The Bandit learned them. When the surface changed from numeric to code representation, accuracy held. That is transfer. That is the invariant being learned, not the surface.', {size:21}),
    ], {after:80}),
    p([
      t('The other four classes remain hard. ', {size:21, bold:true, color:C.red}),
      t('Cross-sequence dependency requires computation — the agent must calculate A[n] OP B[n] to find the answer. The Bandit learns preferences, not arithmetic. Constraint satisfaction requires holding all three rules simultaneously and finding their intersection. Rule inversion requires detecting where a pattern breaks. These are genuinely hard problems. The agent is honest about that. It does not fake progress.', {size:21}),
    ], {after:80}),
    p([
      t('This is the real test. ', {size:21, bold:true}),
      t('A system that scores 100% on every class in 300 episodes is either cheating or the test is too easy. A system that masters what it can structurally represent, struggles with what requires compute, and shows measurable improvement over time — that is a system learning real things.', {size:21}),
    ], {after:80}),
    p([
      t('The agent never saw the rules. It saw structure. Where the structure was learnable by a Thompson Sampling bandit over structural features, it learned. Where it wasn\'t, it showed you exactly why.', {size:21, italic:true, color:C.grey}),
    ]),
  ];
}

// ── ASSEMBLE ───────────────────────────────────────────────────
const children = [
  ...cover(),
  ...intro(),
  new Paragraph({ heading: HeadingLevel.HEADING_1, children: [t('Learning Curves by Class', {bold:true, size:28, color:C.dark})] }),
  sp(6),
  ...Object.keys(CLASS_META).flatMap(k => classSection(k)),
  new Paragraph({ children: [new PageBreak()] }),
  ...snapshots(),
  ...conclusion(),
];

const doc = new Document({
  styles: {
    default: { document: { run: { font: 'Calibri', size: 20 } } },
    paragraphStyles: [
      { id:'Heading1', name:'Heading 1', basedOn:'Normal', next:'Normal', quickFormat:true,
        run:{ size:30, bold:true, font:'Calibri', color:C.dark },
        paragraph:{ spacing:{before:320,after:160}, outlineLevel:0 } },
      { id:'Heading2', name:'Heading 2', basedOn:'Normal', next:'Normal', quickFormat:true,
        run:{ size:24, bold:true, font:'Calibri', color:C.dark },
        paragraph:{ spacing:{before:240,after:100}, outlineLevel:1 } },
    ],
  },
  sections: [{
    properties: { page: { size:{width:12240,height:15840}, margin:{top:1080,right:1080,bottom:1080,left:1080} } },
    footers: { default: new Footer({ children: [
      new Paragraph({ alignment: AlignmentType.CENTER, children: [
        new TextRun({text:'EmerEviro · IQ Pattern Observatory · SextBioRAG  ', size:16, color:C.grey}),
        new TextRun({children:[PageNumber.CURRENT], size:16, color:C.grey}),
      ]}),
    ]})},
    children,
  }],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync('/mnt/user-data/outputs/iq_emergence_report.docx', buf);
  console.log('Done.');
});
