"""Environment module — math task generation and dynamics."""
