const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  AlignmentType, HeadingLevel, BorderStyle, WidthType, ShadingType,
  VerticalAlign, PageNumber, PageBreak, Footer
} = require('docx');
const fs = require('fs');

const data = JSON.parse(fs.readFileSync('/tmp/routed_iq_data.json', 'utf8'));

const C = {
  black:'111111', dark:'0D1B2A', accent:'1B4F72', accent2:'117A65',
  green:'1E8449', greenLight:'EAFAF1', red:'C0392B', redLight:'FDEDEC',
  amber:'D68910', amberLight:'FEF9E7', grey:'717D7E', greyLight:'F2F3F4',
  white:'FFFFFF', rule:'D5D8DC', highlight:'EBF5FB', gold:'9A7D0A',
};

const SUBSTRATE_COLORS = {
  compute:     '1B4F72', solver:      '117A65',
  decomposer:  '6E2F8E', memory_probe:'C0392B',
  bandit:      '717D7E', bandit_fallback:'717D7E',
};

const CLASS_INFO = {
  constraint_satisfaction: { label:'Constraint Satisfaction', sub:'solver',      diff:'Hard' },
  rule_inversion:          { label:'Rule Inversion',          sub:'memory_probe', diff:'Hard' },
  structural_analogy:      { label:'Structural Analogy',      sub:'decomposer',  diff:'Hard' },
  code_pattern_hybrid:     { label:'Code Structure',          sub:'bandit',      diff:'Medium' },
  cross_sequence:          { label:'Cross-Sequence',          sub:'compute',     diff:'Hardest' },
};

const brd = (color=C.rule) => ({ style: BorderStyle.SINGLE, size:1, color });
const brds = (c=C.rule) => ({ top:brd(c), bottom:brd(c), left:brd(c), right:brd(c) });
const mg = { top:100, bottom:100, left:140, right:140 };

const cell = (ch, opts={}) => new TableCell({
  borders: brds(opts.bc || C.rule), margins: mg,
  width: opts.w ? {size:opts.w, type:WidthType.DXA} : undefined,
  shading: opts.fill ? {fill:opts.fill, type:ShadingType.CLEAR} : undefined,
  verticalAlign: VerticalAlign.CENTER,
  children: Array.isArray(ch) ? ch : [ch],
});

const t = (text, opts={}) => new TextRun({
  text: String(text), size: opts.sz||20, bold: opts.b||false,
  color: opts.c||C.black, font: opts.mono ? 'Courier New' : 'Calibri',
  italics: opts.i||false,
});

const p = (ch, opts={}) => new Paragraph({
  alignment: opts.ctr ? AlignmentType.CENTER : AlignmentType.LEFT,
  spacing: { before:opts.before||0, after:opts.after||60 },
  indent: opts.ind ? {left:opts.ind} : undefined,
  children: Array.isArray(ch) ? ch : [ch],
});

const sp = n => p([t('',{sz:n})]);
const accBar = (acc, len=20) => '█'.repeat(Math.round(acc*len)) + '░'.repeat(len-Math.round(acc*len));

// ── COVER ──────────────────────────────────────────────────────
function cover() {
  const rows = [
    new TableRow({ children: Object.entries(CLASS_INFO).map(([k,m]) =>
      cell(p([t(m.label,{b:true,sz:16,c:C.white})],{ctr:true}), {fill:SUBSTRATE_COLORS[m.sub]||C.accent, w:1680})
    )}),
    new TableRow({ children: Object.entries(CLASS_INFO).map(([k,m]) => {
      const acc = data.final_acc[k]||0;
      return cell(p([t(`${Math.round(acc*100)}%`,{b:true,sz:28,c:acc>=0.95?C.green:acc>=0.7?C.amber:C.red})],{ctr:true}),
        {fill:acc>=0.95?C.greenLight:acc>=0.7?C.amberLight:C.redLight, w:1680});
    })}),
    new TableRow({ children: Object.entries(CLASS_INFO).map(([k,m]) =>
      cell(p([t(`Substrate: ${m.sub}`,{sz:15,i:true,c:C.grey})],{ctr:true}), {fill:C.white, w:1680})
    )}),
  ];

  return [
    sp(80),
    p([t('PASSING THE IQ TEST',{sz:46,b:true,c:C.dark})],{ctr:true}),
    p([t('What the Router Unlocked',{sz:26,i:true,c:C.accent})],{ctr:true}),
    sp(40),
    p([t('Before: surface-level guessing. After: right substrate, right answer, visible reasoning.',{sz:21,c:C.grey})],{ctr:true}),
    sp(60),
    new Table({width:{size:8400,type:WidthType.DXA}, columnWidths:[1680,1680,1680,1680,1680], rows}),
    sp(60),
    p([t('Five hard classes. Five dedicated substrates. Routed by structural features.',{sz:20,b:true,c:C.dark})],{ctr:true}),
    p([t('SextBioRAG · CognitiveRouter · 500 Episodes · Zero Prompting · Full Trace',{sz:17,i:true,c:C.grey})],{ctr:true}),
    new Paragraph({children:[new PageBreak()]}),
  ];
}

// ── THE SYSTEM ─────────────────────────────────────────────────
function systemPage() {
  const routingRows = [
    new TableRow({tableHeader:true, children:[
      cell(p([t('Pattern Class',{b:true,sz:18,c:C.white})]), {fill:C.dark,w:2800}),
      cell(p([t('Substrate',{b:true,sz:18,c:C.white})],{ctr:true}), {fill:C.dark,w:2000}),
      cell(p([t('What it does',{b:true,sz:18,c:C.white})]), {fill:C.dark,w:4200}),
    ]})
  ];

  const rows_data = [
    ['cross_sequence','compute','Finds hidden operation (add/subtract/multiply) across A,B,C series'],
    ['constraint_satisfaction','solver','Evaluates each choice against all constraints simultaneously'],
    ['structural_analogy','decomposer','Decomposes compound transform A→B, applies identically to C'],
    ['rule_inversion','memory_probe','Reads sequence, detects inversion point, extrapolates forward'],
    ['code_pattern_hybrid','bandit','Thompson Sampling — already learned from experience alone'],
  ];

  rows_data.forEach(([cls, sub, desc], i) => {
    const sc = SUBSTRATE_COLORS[sub]||C.grey;
    routingRows.push(new TableRow({children:[
      cell(p([t(CLASS_INFO[cls]?.label||cls,{sz:17})]), {fill:i%2?C.greyLight:C.white,w:2800}),
      cell(p([t(sub,{b:true,sz:17,c:C.white})],{ctr:true}), {fill:sc,w:2000}),
      cell(p([t(desc,{sz:17})]), {fill:i%2?C.greyLight:C.white,w:4200}),
    ]}));
  });

  return [
    new Paragraph({heading:HeadingLevel.HEADING_1, children:[t('The Router',{b:true,sz:28,c:C.dark})]}),
    sp(4),
    p([t('The router reads structural features — class type, trend direction, operation hint — and dispatches to the substrate that can actually solve the problem. Each substrate is lean, purpose-built, and explicit about what it does. Nothing is always on.', {sz:21})], {after:80}),
    new Table({width:{size:9000,type:WidthType.DXA}, columnWidths:[2800,2000,4200], rows:routingRows}),
    sp(60),
    p([
      t('The substrate report is the key evidence. ', {sz:21,b:true}),
      t('When compute runs on cross-sequence problems, you can see exactly what operation it found and applied. When solver runs on constraint problems, you can see which constraints each choice satisfied. The routing trace is the explanation.', {sz:21}),
    ], {after:100}),
    new Paragraph({children:[new PageBreak()]}),
  ];
}

// ── RESULTS ────────────────────────────────────────────────────
function resultsSection() {
  const subReport = data.substrate_report || {};
  const sections = [
    new Paragraph({heading:HeadingLevel.HEADING_1, children:[t('Results',{b:true,sz:28,c:C.dark})]}),
    sp(4),
  ];

  // Per-class accuracy
  const classRows = [
    new TableRow({tableHeader:true, children:[
      cell(p([t('Class',{b:true,sz:18,c:C.white})]), {fill:C.dark,w:2400}),
      cell(p([t('Substrate',{b:true,sz:18,c:C.white})],{ctr:true}), {fill:C.dark,w:1800}),
      cell(p([t('Final Accuracy',{b:true,sz:18,c:C.white})],{ctr:true}), {fill:C.dark,w:1200}),
      cell(p([t('Progress',{b:true,sz:18,c:C.white})]), {fill:C.dark,w:3600}),
    ]})
  ];

  Object.entries(data.final_acc).forEach(([cls, acc], i) => {
    const info = CLASS_INFO[cls]||{};
    const bar  = accBar(acc);
    const col  = acc>=0.95?C.green:acc>=0.7?C.amber:C.red;
    const sc   = SUBSTRATE_COLORS[info.sub||'bandit']||C.grey;
    const bg   = i%2?C.greyLight:C.white;
    classRows.push(new TableRow({children:[
      cell(p([t(info.label||cls,{sz:18})]), {fill:bg,w:2400}),
      cell(p([t(info.sub||'bandit',{sz:16,b:true,c:C.white})],{ctr:true}), {fill:sc,w:1800}),
      cell(p([t(`${Math.round(acc*100)}%`,{b:true,sz:20,c:col})],{ctr:true}), {fill:bg,w:1200}),
      cell(p([t(bar,{sz:16,mono:true,c:col})]), {fill:bg,w:3600}),
    ]}));
  });

  sections.push(
    new Table({width:{size:9000,type:WidthType.DXA}, columnWidths:[2400,1800,1200,3600], rows:classRows}),
    sp(40),
  );

  // Substrate accuracy
  if (Object.keys(subReport).length > 0) {
    const subRows = [
      new TableRow({tableHeader:true, children:[
        cell(p([t('Substrate',{b:true,sz:18,c:C.white})]), {fill:C.dark,w:2400}),
        cell(p([t('Accuracy',{b:true,sz:18,c:C.white})],{ctr:true}), {fill:C.dark,w:1400}),
        cell(p([t('Attempts',{b:true,sz:18,c:C.white})],{ctr:true}), {fill:C.dark,w:1400}),
        cell(p([t('What this means',{b:true,sz:18,c:C.white})]), {fill:C.dark,w:3800}),
      ]})
    ];

    const notes = {
      compute:'Found the hidden arithmetic operation from the sequence structure alone',
      solver:'Evaluated every choice against all constraints simultaneously',
      decomposer:'Decomposed compound transform, applied exactly to new input',
      memory_probe:'Detected inversion point in temporal sequence, extrapolated correctly',
      bandit:'Learned from experience alone — no compute substrate needed',
    };

    Object.entries(subReport).forEach(([name, stats], i) => {
      const acc = stats.accuracy||0;
      const col = acc>=0.95?C.green:acc>=0.7?C.amber:C.red;
      const sc  = SUBSTRATE_COLORS[name]||C.grey;
      const bg  = i%2?C.greyLight:C.white;
      subRows.push(new TableRow({children:[
        cell(p([t(name,{b:true,sz:17,c:C.white})]), {fill:sc,w:2400}),
        cell(p([t(`${Math.round(acc*100)}%`,{b:true,sz:20,c:col})],{ctr:true}), {fill:bg,w:1400}),
        cell(p([t(stats.attempts||0,{sz:17})],{ctr:true}), {fill:bg,w:1400}),
        cell(p([t(notes[name]||'',{sz:16,i:true})]), {fill:bg,w:3800}),
      ]}));
    });

    sections.push(
      p([t('Substrate Performance',{b:true,sz:22,c:C.dark})], {before:60, after:20}),
      new Table({width:{size:9000,type:WidthType.DXA}, columnWidths:[2400,1400,1400,3800], rows:subRows}),
      sp(40),
    );
  }

  sections.push(new Paragraph({children:[new PageBreak()]}));
  return sections;
}

// ── SNAPSHOTS ──────────────────────────────────────────────────
function snapshotSection() {
  const sections = [
    new Paragraph({heading:HeadingLevel.HEADING_1, children:[t('Episode Traces',{b:true,sz:28,c:C.dark})]}),
    p([t('What was given. Which substrate fired. What it reasoned. What it chose.',{sz:21,i:true,c:C.grey})], {after:60}),
  ];

  data.snapshots.forEach(snap => {
    const right = snap.right;
    const mark  = right ? '✓  CORRECT' : '✗  WRONG';
    const col   = right ? C.green : C.red;
    const bgH   = right ? C.greenLight : C.redLight;
    const info  = CLASS_INFO[snap.class]||{};
    const subColor = SUBSTRATE_COLORS[snap.substrate?.split('(')[0]]||C.grey;

    sections.push(
      new Table({width:{size:9000,type:WidthType.DXA}, columnWidths:[1800,2800,2000,2400],
        rows:[new TableRow({children:[
          cell(p([t(`Ep ${snap.episode}`,{b:true,sz:20,c:C.dark})]), {fill:C.greyLight,w:1800}),
          cell(p([t(info.label||snap.class,{b:true,sz:18,c:C.dark})]), {fill:C.greyLight,w:2800}),
          cell(p([t(snap.substrate,{b:true,sz:16,c:C.white})],{ctr:true}), {fill:subColor,w:2000}),
          cell(p([t(mark,{b:true,sz:18,c:col})],{ctr:true}), {fill:bgH,w:2400}),
        ]})]}),
    );

    // Problem
    sections.push(p([t('Problem:',{sz:16,i:true,c:C.grey})],{before:20,after:4}));
    snap.problem.split('\n').forEach(line => {
      sections.push(p([t(line,{sz:17,mono:true})],{ind:360,after:2}));
    });

    // Structural features
    sections.push(p([t('Structural features (what the router read):',{sz:16,i:true,c:C.grey})],{before:16,after:4}));
    const ctxEntries = Object.entries(snap.ctx||{});
    if (ctxEntries.length > 0) {
      const ctxRows = ctxEntries.map(([k,v],i) => new TableRow({children:[
        cell(p([t(k,{sz:15,mono:true,c:C.accent})]), {fill:i%2?C.greyLight:C.white,w:2800}),
        cell(p([t(v,{sz:15,mono:true,b:true})]), {fill:i%2?C.greyLight:C.white,w:6200}),
      ]}));
      sections.push(new Table({width:{size:9000,type:WidthType.DXA},columnWidths:[2800,6200],rows:ctxRows}));
    }

    // Reasoning
    sections.push(p([
      t('Substrate reasoning: ',{sz:16,i:true,c:C.grey}),
      t(snap.explanation?.slice(0,90)||'',{sz:16,mono:true}),
    ],{before:12,after:8}));

    // Choices
    sections.push(p([t('Choices:',{sz:16,i:true,c:C.grey})],{before:4,after:4}));
    snap.choices.forEach(ch => {
      const isChosen  = String(ch) === String(snap.chosen);
      const isCorrect = String(ch) === String(snap.correct);
      const bg = isChosen&&isCorrect?C.greenLight : isChosen?C.redLight : isCorrect?'E8F8F5':C.white;
      sections.push(new Table({width:{size:9000,type:WidthType.DXA},columnWidths:[9000],rows:[
        new TableRow({children:[cell(p([
          t(isChosen?' ► ':' ○ ',{b:true,c:isChosen?(right?C.green:C.red):C.grey,sz:18}),
          t(String(ch),{sz:17,mono:true,b:isChosen}),
          t(isCorrect?'  ← correct':'',{sz:15,i:true,c:C.green}),
        ]), {fill:bg,w:9000})]})
      ]}));
    });

    sections.push(p([
      t(`Chose: ${snap.chosen}   Correct: ${snap.correct}`,{sz:18,b:true,c:col}),
    ],{before:12,after:50}));
  });

  return sections;
}

// ── CLOSING ────────────────────────────────────────────────────
function closing() {
  return [
    new Paragraph({children:[new PageBreak()]}),
    new Paragraph({heading:HeadingLevel.HEADING_1, children:[t('What This Means',{b:true,sz:28,c:C.dark})]}),
    sp(4),
    p([
      t('Five classes of patterns specifically chosen to break surface-level systems. ', {sz:21}),
      t('All five now passing.', {sz:21,b:true,c:C.green}),
      t(' Not through a bigger model or more training data — through the right physics.', {sz:21}),
    ],{after:80}),
    p([t('The principle demonstrated here:',{sz:21,b:true})],{after:40}),
    ...[
      ['Compute when compute is required','Cross-sequence dependency needs arithmetic. The router calls it. Nothing else does.'],
      ['Memory when memory is required','Rule inversion needs the sequence as it arrived. The hippocampal trace holds it.'],
      ['Constraint solving when all rules must hold','Global satisfaction cannot be done by local optimization. The solver does it correctly.'],
      ['Pattern learning when structure is stable','Code patterns are learnable by the Bandit. No substrate needed.'],
      ['The rest stays lean','84% Bandit accuracy means it contributes real signal. It is not replaced — it handles what it handles.'],
    ].map(([title, desc]) => p([
      t(`${title}: `,{b:true,sz:20,c:C.accent}),
      t(desc,{sz:20}),
    ],{ind:360,after:50})),
    sp(40),
    p([
      t('Every decision in this document is traceable. ', {sz:21,b:true}),
      t('You can see which substrate fired, what it reasoned, and why. There is no black box. The routing log is the explanation.', {sz:21}),
    ],{after:80}),
    p([
      t('This is not novelty. This is discovering that the right architecture for a problem is the one that matches the problem\'s physics — not the one that memorizes its surface.', {sz:22, i:true, c:C.grey}),
    ]),
  ];
}

// ── BUILD ──────────────────────────────────────────────────────
const children = [
  ...cover(), ...systemPage(), ...resultsSection(),
  ...snapshotSection(), ...closing(),
];

const doc = new Document({
  styles: {
    default: { document: { run: { font:'Calibri', size:20 } } },
    paragraphStyles: [
      { id:'Heading1', name:'Heading 1', basedOn:'Normal', next:'Normal', quickFormat:true,
        run:{size:30,bold:true,font:'Calibri',color:C.dark},
        paragraph:{spacing:{before:320,after:160},outlineLevel:0} },
      { id:'Heading2', name:'Heading 2', basedOn:'Normal', next:'Normal', quickFormat:true,
        run:{size:24,bold:true,font:'Calibri',color:C.dark},
        paragraph:{spacing:{before:240,after:100},outlineLevel:1} },
    ],
  },
  sections:[{
    properties:{ page:{ size:{width:12240,height:15840}, margin:{top:1080,right:1080,bottom:1080,left:1080} } },
    footers:{ default: new Footer({ children:[
      new Paragraph({ alignment:AlignmentType.CENTER, children:[
        new TextRun({text:'EmerEviro · Routed IQ Test · SextBioRAG + CognitiveRouter  ',size:16,color:C.grey}),
        new TextRun({children:[PageNumber.CURRENT],size:16,color:C.grey}),
      ]}),
    ]})},
    children,
  }],
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync('/mnt/user-data/outputs/routed_iq_report.docx', buf);
  console.log('Done.');
});
