"""
Experiment harness.

Wires together: environment → bus → agent → metrics → probes

Usage:
    python run_experiment.py

This is the MVP run. It demonstrates the full pipeline with null models.
Plug in a real agent by subclassing AgentClient and passing it in.
"""

import sys
sys.path.insert(0, '.')

# make sure the BiORAG hybrid packages can be imported when running
# from the workspace root; the native agents rely on Time_engine,
# Bandit_engine, halcyon_research_demo, etc.
import os
_hybrids_root = os.path.abspath(os.path.join(os.path.dirname(__file__), 'agents', 'deployable_biorag_hybrids'))
if _hybrids_root not in sys.path:
    sys.path.insert(0, _hybrids_root)

from environment.math_env import MathEnvironment, TaskGenerator
from bus.bus import EnvironmentBus, AgentClient
from bus.schemas import Action, ActionTier, Observation
from agents.null_models import NullB_NoMinting, NullC_EpisodicMemory
from metrics.tracker import MetricsTracker, EpisodeRecord

# utilities for automatic agent discovery
import pkgutil
import importlib
import inspect


def discover_agent_classes() -> dict[str, type[AgentClient]]:
    """Scan the ``agents`` package and return all concrete subclasses of
    ``AgentClient``.

    Modules that fail to import are skipped with a warning; the returned
    dictionary maps the class __name__ to the class object.  This lets users
    drop new agents in ``agents/`` without touching this file.
    """
    found: dict[str, type[AgentClient]] = {}
    try:
        # ``agents.__path__`` is defined when the package is imported
        import agents as agents_pkg  # noqa: F401
    except ImportError:
        return found

    for finder, modname, ispkg in pkgutil.walk_packages(agents_pkg.__path__, prefix="agents."):
        # Skip the deployable_biorag_hybrids sub-package — those are
        # agent dependencies, not AgentClient implementations.
        if "deployable_biorag_hybrids" in modname:
            continue
        try:
            module = importlib.import_module(modname)
        except Exception as exc:  # keep running even if one module misbehaves
            print(f"warning: failed to import agent module {modname}: {exc}")
            continue
        for attr in dir(module):
            obj = getattr(module, attr)
            if (
                inspect.isclass(obj)
                and issubclass(obj, AgentClient)
                and obj is not AgentClient
            ):
                found[obj.__name__] = obj
    return found

PROBE_INTERVAL = 10    # run diagnostic suite every N episodes
N_EPISODES     = 1000   # total episodes per agent


# ---------------------------------------------------------------------------
# Simple candidate agent (placeholder — swap in your real agent here)
# ---------------------------------------------------------------------------

class CandidateAgent(AgentClient):
    """
    MVP candidate: tries to mint a primitive after seeing the same pattern twice,
    then reuses it. Demonstrates the pipeline, not intelligence.
    """
    import random as _random

    def __init__(self, bus: EnvironmentBus):
        super().__init__(bus)
        self._seen_inputs: dict[str, int] = {}
        self._rng = __import__('random').Random(42)

    def select_action(self, obs: Observation) -> Action:
        task_input = obs.task.get("input", "")
        self._seen_inputs[task_input] = self._seen_inputs.get(task_input, 0) + 1

        # If we've seen this pattern before and have budget, try minting
        if (self._seen_inputs[task_input] >= 2
                and obs.capacity_used < obs.capacity_total - 5
                and obs.step == 0):
            return Action(
                tier=ActionTier.MINT,
                payload={"definition": task_input, "name": "cached_pattern"}
            )

        # Otherwise assemble from library or atoms
        if obs.library and self._rng.random() > 0.5:
            pid = self._rng.choice([p.id for p in obs.library])
            return Action(
                tier=ActionTier.ASSEMBLE,
                payload={
                    "op": "combine",
                    "primitives": [pid],
                    "primitive_id": pid,
                    "used_library_primitive": True,
                    "result": obs.library[0].canonical_form,
                }
            )

        atoms = obs.available_atoms or ["x", "y"]
        chosen = self._rng.sample(atoms, min(2, len(atoms)))
        target = obs.task.get("target", "")
        return Action(
            tier=ActionTier.ASSEMBLE,
            payload={"op": "combine", "primitives": chosen, "result": target}
        )


# ---------------------------------------------------------------------------
# Run one agent for N episodes, return metrics summary
# ---------------------------------------------------------------------------

def run_agent(agent_class, agent_name: str, n_episodes: int = N_EPISODES) -> dict:
    env = MathEnvironment(TaskGenerator(seed=42))
    bus = EnvironmentBus(env)

    # special case: if the agent is a BioRAGAdapterBase subclass, try to
    # instantiate it with a real native agent from the deployable package.
    agent_args = [bus]
    agent_kwargs: dict = {}

    try:
        # import lazily to avoid hard dependency when the package isn't present
        from agents.biorag_adapters import BioRAGAdapterBase
    except ImportError:
        BioRAGAdapterBase = None  # type: ignore

    if BioRAGAdapterBase and issubclass(agent_class, BioRAGAdapterBase):
        # determine which native agent to load based on adapter class name
        native = None
        if agent_class.__name__.startswith("Quint"):
            try:
                from quint_biorag import QuintBioRAGAgent
                native = QuintBioRAGAgent(seed=42)
            except Exception as e:
                print(f"Failed to load QuintBioRAGAgent: {e}")
                native = None
        elif agent_class.__name__.startswith("Sext"):
            try:
                from sext_biorag import SextBioRAGAgent
                native = SextBioRAGAgent(seed=42)
            except Exception as e:
                print(f"Failed to load SextBioRAGAgent: {e}")
                native = None
        if native is not None:
            agent_kwargs["biorag_agent"] = native
        # adapters accept seed as third argument
        agent_kwargs["seed"] = 42

    agent = agent_class(*agent_args, **agent_kwargs)
    tracker = MetricsTracker()

    print(f"\n{'='*50}")
    print(f"Running: {agent_name}")
    print(f"{'='*50}")

    for ep in range(n_episodes):
        obs = bus.reset()
        total_reward = 0.0
        trace = []

        while True:
            action = agent.select_action(obs)
            result = bus.act(action)

            trace.append({
                "tier": action.tier.name,
                "payload": str(action.payload),
                "reward": result.reward,
                "used_library_primitive": action.payload.get("used_library_primitive", False),
                "primitive_id": action.payload.get("primitive_id", None),
            })

            total_reward += result.reward
            obs = result.observation
            if result.done:
                break

        tracker.record(EpisodeRecord(
            episode_id=ep,
            total_reward=total_reward,
            trace=trace,
            library_snapshot=obs.library,
            library_used_ids={
                s.get("primitive_id") for s in trace
                if s.get("used_library_primitive")
            },
        ))

        # Online probe
        if (ep + 1) % PROBE_INTERVAL == 0:
            probe = bus.probe()
            print(f"  [Probe ep {ep+1}] flags={probe.flags or 'none'} "
                  f"DeltaTransfer={probe.delta_transfer:.3f}")

        if (ep + 1) % 20 == 0:
            s = tracker.summary()
            print(f"  ep {ep+1:3d} | reward={s['mean_reward']:+.3f} | "
                  f"reuse={s['reuse_rate']:.2f} | bcg={s['bcg']:.1f}")

    return {agent_name: tracker.summary()}


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    results = {}

    # discover any agents placed under the ``agents`` package
    agents = discover_agent_classes()
    if not agents:
        print("warning: no AgentClient implementations were discovered")
    else:
        print(f"discovered agents: {', '.join(agents.keys())}")

    # always keep the in‑file Candidate for demonstration unless another
    # class with the same name was found
    if "CandidateAgent" not in agents:
        agents["Candidate"] = CandidateAgent

    # run every discovered agent once
    for name, cls in agents.items():
        results.update(run_agent(cls, name))

    # final summary
    print(f"\n{'='*50}")
    print("RESULTS SUMMARY")
    print(f"{'='*50}")
    for name, summary in results.items():
        print(f"\n{name}:")
        for k, v in summary.items():
            if isinstance(v, float):
                print(f"  {k}: {v:.4f}")
            else:
                print(f"  {k}: {v}")

    # simple emergence check assumes the candidate class still ran
    candidate = results.get("Candidate", {})
    null_b    = results.get("NullB_NoMinting", {})
    null_c    = results.get("NullC_EpisodicMemory", {})

    candidate_wins = (
        candidate.get("mean_reward", 0) > null_b.get("mean_reward", 0) and
        candidate.get("mean_reward", 0) > null_c.get("mean_reward", 0) and
        candidate.get("reuse_rate",  0) > null_b.get("reuse_rate",  0) and
        candidate.get("bcg",         0) > null_c.get("bcg",         0)
    )

    print(f"  Candidate beats all nulls: {candidate_wins}")
    if not candidate_wins:
        print("  → No emergence demonstrated yet. That's fine — this is the MVP.")
        print("  → Drop in your own agent under agents/ and rerun.")
