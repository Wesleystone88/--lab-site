import sys
import os

_hybrids_root = os.path.abspath(os.path.join(os.path.dirname(__file__), 'agents', 'deployable_biorag_hybrids'))
if _hybrids_root not in sys.path:
    sys.path.insert(0, _hybrids_root)

print("Testing QuintBioRAGAgent import...")
try:
    from quint_biorag import QuintBioRAGAgent
    native = QuintBioRAGAgent(seed=42)
    print("QuintBioRAGAgent loaded SUCCESS!")
except Exception as e:
    import traceback
    print("QuintBioRAGAgent failed to load:")
    traceback.print_exc()

print("\nTesting SextBioRAGAgent import...")
try:
    from sext_biorag import SextBioRAGAgent
    native = SextBioRAGAgent(seed=42)
    print("SextBioRAGAgent loaded SUCCESS!")
except Exception as e:
    import traceback
    print("SextBioRAGAgent failed to load:")
    traceback.print_exc()

print("\nTesting SeptBioRAGAgent import...")
try:
    from sept_biorag import SeptBioRAGAgent
    native = SeptBioRAGAgent(seed=42)
    print("SeptBioRAGAgent loaded SUCCESS!")
except Exception as e:
    import traceback
    print("SeptBioRAGAgent failed to load:")
    traceback.print_exc()
