"""Bus module — protocol boundary between agent and environment."""
