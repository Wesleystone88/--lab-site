"""
Cognitive Router
================
The dispatch layer between structural features and compute substrates.

This is the new piece. Small, clean, explicit.

Design:
    1. Read structural features from the problem context
    2. Determine which substrate can solve this class
    3. Call that substrate with the full problem
    4. If substrate returns a confident answer — use it
    5. If not — fall back to the Bandit (learned preferences)

The router is NOT a black box. Every decision is logged:
    - which class was detected
    - which substrate was called
    - what the substrate returned
    - whether it was used or overridden

This is the explainability layer. You can always trace why
the agent gave any specific answer.

Substrate registry:
    cross_sequence      → compute    (arithmetic: find A OP B)
    constraint_sat      → solver     (search: satisfy all constraints)
    structural_analogy  → decomposer (algebra: decompose T, apply to C)
    rule_inversion      → memory     (trace: detect inversion point)
    code_pattern        → bandit     (passthrough: already learned)
"""

from __future__ import annotations
import sys, os
from typing import Any

# Make substrates importable
_root = os.path.dirname(os.path.abspath(__file__))
if _root not in sys.path:
    sys.path.insert(0, _root)

from substrates import compute, solver, decomposer, memory_probe


# ── CLASS → SUBSTRATE MAP ─────────────────────────────────────
SUBSTRATE_MAP = {
    'cross_sequence':          'compute',
    'constraint_satisfaction': 'solver',
    'structural_analogy':      'decomposer',
    'rule_inversion':          'memory_probe',
    'code_pattern_hybrid':     'bandit',   # passthrough
}

SUBSTRATES = {
    'compute':      compute,
    'solver':       solver,
    'decomposer':   decomposer,
    'memory_probe': memory_probe,
}


class CognitiveRouter:
    """
    Routes each problem to the substrate that can solve it.
    Logs every routing decision for full traceability.
    """

    def __init__(self):
        self.routing_log  = []      # full trace of every decision
        self.substrate_accuracy = {k: [] for k in SUBSTRATE_MAP.values()}

    def route(
        self,
        features: dict,
        problem:  dict,
        choices:  list,
        episode:  int = 0,
    ) -> tuple[Any, str, str]:
        """
        Main entry point.

        Args:
            features: structural features from the environment
            problem:  raw problem dict (numbers, sequences, constraints)
            choices:  available answer choices
            episode:  current episode number (for logging)

        Returns:
            (answer, substrate_used, explanation)
        """
        cls = features.get('class', 'unknown')
        substrate_name = SUBSTRATE_MAP.get(cls, 'bandit')

        answer      = None
        explanation = 'no_substrate'

        # Try the mapped substrate
        if substrate_name != 'bandit' and substrate_name in SUBSTRATES:
            substrate = SUBSTRATES[substrate_name]
            try:
                answer, explanation = substrate.run(features, problem, choices)
            except Exception as e:
                explanation = f"substrate_error: {e}"
                answer = None

        # If substrate failed or returned nothing — note it, let Bandit handle
        routed_to = substrate_name
        if answer is None:
            routed_to   = 'bandit_fallback'
            explanation = f"substrate={substrate_name} returned None, fallback to Bandit"

        # Log the routing decision
        entry = {
            'episode':    episode,
            'class':      cls,
            'substrate':  routed_to,
            'answer':     str(answer) if answer is not None else None,
            'explanation': explanation,
            'choices':    [str(c) for c in choices],
        }
        self.routing_log.append(entry)

        return answer, routed_to, explanation

    def record_outcome(self, substrate: str, correct: bool):
        """Record whether the substrate's answer was correct."""
        key = substrate.replace('_fallback', '')
        if key in self.substrate_accuracy:
            self.substrate_accuracy[key].append(correct)

    def substrate_report(self) -> dict:
        """Accuracy per substrate — how well each one is working."""
        return {
            name: {
                'attempts': len(results),
                'accuracy': sum(results) / len(results) if results else 0.0,
            }
            for name, results in self.substrate_accuracy.items()
            if results
        }

    def last_routing(self) -> dict:
        """Return the most recent routing decision."""
        return self.routing_log[-1] if self.routing_log else {}
