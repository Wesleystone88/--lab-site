"""
Example: Running BioRAG agents with EmerEviro

This demonstrates how to wire a native Quint-BioRAG agent through
the adapter and measure emergence.

Usage:
    python examples/run_with_biorag.py
"""

# ensure we can import the deployable_biorag_hybrids package
import os, sys
_hybrids_root = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'deployable_biorag_hybrids'))
if _hybrids_root not in sys.path:
    sys.path.insert(0, _hybrids_root)

import sys
sys.path.insert(0, '.')

from environment.math_env import MathEnvironment, TaskGenerator
from bus.bus import EnvironmentBus
from agents.biorag_adapters import QuintBioRAGAdapter, SextBioRAGAdapter
from agents.null_models import NullB_NoMinting, NullC_EpisodicMemory
from metrics.tracker import MetricsTracker, EpisodeRecord

# If you want to use the actual native BioRAG agents:
# from deployable_biorag_hybrids.quint_biorag import QuintBioRAGAgent
# from deployable_biorag_hybrids.sext_biorag import SextBioRAGAgent

N_EPISODES = 50  # Small for testing; increase for full runs


def run_biorag_agent(adapter_class, agent_name: str, n_episodes: int = N_EPISODES) -> dict:
    """Run a BioRAG adapter agent through EmerEviro."""
    env = MathEnvironment(TaskGenerator(seed=42))
    bus = EnvironmentBus(env)
    
    # Create adapter (without native agent for now — use for testing)
    # To use a real native agent:
    #   native = QuintBioRAGAgent(seed=42)
    #   adapter = adapter_class(bus, native, seed=42)
    adapter = adapter_class(bus, None, seed=42)
    
    tracker = MetricsTracker()
    
    print(f"\n{'='*50}")
    print(f"Running: {agent_name}")
    print(f"{'='*50}")
    
    for ep in range(n_episodes):
        obs = bus.reset()
        total_reward = 0.0
        trace = []
        
        while True:
            action = adapter.select_action(obs)
            result = bus.act(action)
            
            trace.append({
                "tier": action.tier.name,
                "payload": str(action.payload),
                "reward": result.reward,
                "used_library_primitive": action.payload.get("used_library_primitive", False),
                "primitive_id": action.payload.get("primitive_id", None),
                "source": "",  # would be populated from biorag_agent if available
            })
            
            total_reward += result.reward
            obs = result.observation
            if result.done:
                break
        
        tracker.record(EpisodeRecord(
            episode_id=ep,
            total_reward=total_reward,
            trace=trace,
            library_snapshot=obs.library,
            library_used_ids={
                s.get("primitive_id") for s in trace
                if s.get("used_library_primitive")
            },
        ))
        
        if (ep + 1) % 10 == 0:
            s = tracker.summary()
            print(f"  ep {ep+1:3d} | reward={s['mean_reward']:+.3f} | "
                  f"reuse={s['reuse_rate']:.2f} | bcg={s['bcg']:.1f}")
    
    return {agent_name: tracker.summary()}


if __name__ == "__main__":
    results = {}
    
    # BioRAG adapters
    print("\n" + "="*60)
    print("TESTING BIORAG ADAPTERS")
    print("="*60)
    
    results.update(run_biorag_agent(QuintBioRAGAdapter, "Quint-BioRAG (fallback)"))
    results.update(run_biorag_agent(SextBioRAGAdapter, "Sext-BioRAG (fallback)"))
    
    # Null models for comparison
    print("\n" + "="*60)
    print("NULL MODELS (for comparison)")
    print("="*60)
    
    env = MathEnvironment(TaskGenerator(seed=42))
    bus = EnvironmentBus(env)
    agent = NullB_NoMinting(bus)
    tracker = MetricsTracker()
    
    print(f"\n{'='*50}")
    print("Running: Null B (no minting)")
    print(f"{'='*50}")
    
    for ep in range(N_EPISODES):
        obs = bus.reset()
        total_reward = 0.0
        trace = []
        
        while True:
            action = agent.select_action(obs)
            result = bus.act(action)
            
            trace.append({
                "tier": action.tier.name,
                "payload": str(action.payload),
                "reward": result.reward,
                "used_library_primitive": False,
            })
            
            total_reward += result.reward
            obs = result.observation
            if result.done:
                break
        
        tracker.record(EpisodeRecord(
            episode_id=ep,
            total_reward=total_reward,
            trace=trace,
            library_snapshot=obs.library,
        ))
        
        if (ep + 1) % 10 == 0:
            s = tracker.summary()
            print(f"  ep {ep+1:3d} | reward={s['mean_reward']:+.3f}")
    
    results["Null B (no minting)"] = tracker.summary()
    
    # Summary
    print(f"\n{'='*60}")
    print("RESULTS SUMMARY")
    print(f"{'='*60}")
    for name, summary in results.items():
        print(f"\n{name}:")
        for k, v in summary.items():
            if isinstance(v, float):
                print(f"  {k}: {v:.4f}")
            else:
                print(f"  {k}: {v}")
    
    print("\n" + "="*60)
    print("NEXT STEPS:")
    print("="*60)
    print("""
1. Load a native BioRAG agent:
   from deployable_biorag_hybrids.quint_biorag import QuintBioRAGAgent
   native = QuintBioRAGAgent(seed=42)
   
2. Wire it into the adapter:
   adapter = QuintBioRAGAdapter(bus, native, seed=42)
   
3. Run and compare emergence metrics against nulls.
""")
