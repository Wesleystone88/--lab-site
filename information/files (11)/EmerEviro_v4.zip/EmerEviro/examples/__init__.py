"""Examples directory — demonstration scripts for EmerEviro."""
