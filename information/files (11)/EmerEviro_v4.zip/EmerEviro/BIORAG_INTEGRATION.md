# BioRAG Agents in EmerEviro

## Overview

> **Import note:** the native BioRAG code relies on modules under
> `deployable_biorag_hybrids` (e.g. `Time_engine`, `Bandit_engine`,
> `halcyon_research_demo`). When running from the workspace root the
> adapter automatically adds this directory to `sys.path`. If you
> encounter `ImportError` messages, ensure you launch Python from the
> project root or manually insert the path before importing the agents:
>
> ```python
> import os, sys
> sys.path.insert(0, os.path.abspath("deployable_biorag_hybrids"))
> ```
>

The `deployable_biorag_hybrids/` folder contains sophisticated 5- and 6-pillar cognitive agents:
- **Quint-BioRAG**: 5 pillars (CME, Bandit, TFE, PEE, BioRAG)
- **Sext-BioRAG**: 6 pillars (adds PFC for impulse control)

These agents are **outside EmerEviro's bus boundary**. The adapters in `agents/biorag_adapters.py` bridge them in.

## Architecture Mapping

### Native BioRAG Interface
```python
agent.choose_action(condition: Dict[str, str], actions: List[str]) -> Tuple[str, str]
agent.update(condition: Dict[str, str], action: str, success: bool, step: int) -> None
```

### EmerEviro Bus Interface
```python
agent.select_action(obs: Observation) -> Action
```

### The Adapter
```
Observation (from EmerEviro)
    ↓
    [Convert to condition dict + available actions]
    ↓
agent.choose_action(condition, actions)  [native BioRAG]
    ↓
    [Convert selected action to Action with tier + payload]
    ↓
Action (sent back to EmerEviro bus)
```

## Integration Steps

### Step 1: Load a Native BioRAG Agent

```python
from deployable_biorag_hybrids.quint_biorag import QuintBioRAGAgent
from agents.biorag_adapters import QuintBioRAGAdapter

# Create native agent (with its own configuration)
native_agent = QuintBioRAGAgent(
    seed=42,
    tfe_tau=3600.0,
    pee_kwargs={"surprise_scale": 0.1},
)

# Wrap in adapter for EmerEviro
bus = EnvironmentBus(environment)
adapter = QuintBioRAGAdapter(bus, native_agent, seed=42)
```

### Step 2: Run as Normal EmerEviro Agent

```python
# The adapter is now an AgentClient — works with run_experiment.py
reward = adapter.run_episode()
```

### Step 3: Monitor Pillar Decisions

The adapter logs each step including the native agent's decision source (which pillar drove the decision):

```python
for trace_entry in adapter.episode_trace:
    print(f"Step {trace_entry['step']}: chose {trace_entry['chosen_action']} via {trace_entry['source']}")
```

## Configuration

### Available Actions in EmerEviro

The adapter maps BioRAG's discrete actions to EmerEviro tiers:

| BioRAG Action | EmerEviro Tier | Cost | Condition |
|---|---|---|---|
| ASSEMBLE | ASSEMBLE | 0.05 | Always available |
| MINT | MINT | 1.00 | Budget ≥ 1.0 + Capacity available |
| MUTATE | MUTATE | 0.30 | Library non-empty + Budget ≥ 0.3 |

The adapter decides which actions are **available** each step based on resource constraints.

### Customizing the Mapping

In `biorag_adapters.py`, override these methods:

```python
class MyBioRAGAdapter(BioRAGAdapterBase):
    def _get_available_actions(self, obs: Observation) -> List[str]:
        # Custom action filtering logic
        return ["ASSEMBLE", "MINT"]
    
    def _action_name_to_tier_payload(self, action_name: str, obs: Observation) -> Tuple[ActionTier, dict]:
        # Custom payload generation
        return (ActionTier.ASSEMBLE, {"op": "combine", ...})
```

## Emergence Measurement

The standard EmerEviro metrics still apply:
- **Reuse Rate**: Fraction of ASSEMBLE steps using library primitives
- **BCG**: Behavioral Compression Gain (size of traces without vs. with library)
- **Time-to-Stability**: Episodes until reward variance drops

The adapter flags library use in the Action payload so metrics can track it:
```python
payload["used_library_primitive"] = True/False
payload["primitive_id"] = "p0" or None
```

## Running with BioRAG in Experiments

To swap agents in `run_experiment.py`:

```python
# Add to imports
from agents.biorag_adapters import QuintBioRAGAdapter
from deployable_biorag_hybrids.quint_biorag import QuintBioRAGAgent

# In the agent selection block
native_quint = QuintBioRAGAgent(seed=42)
quint_adapter = QuintBioRAGAdapter(bus, native_quint, seed=42)

results.update(run_agent(QuintBioRAGAdapter, "Quint-BioRAG"))
```

## Known Limitations & TODOs

1. **Fallback behavior**: If native BioRAG fails, adapter defaults to ASSEMBLE
2. **Episode boundary semantics**: BioRAG's `update()` is called post-episode; may not align perfectly with EmerEviro's per-step reward structure
3. **Condition richness**: The adapter converts Observation → minimal condition dict; richer context could improve pillar decisions
4. **Decision diagnostics**: The adapter logs pillar decisions, but full trace access requires reading `adapter.episode_trace`

## Files

- `agents/biorag_adapters.py`: Adapter classes (BioRAGAdapterBase, QuintBioRAGAdapter, SextBioRAGAdapter)
- `deployable_biorag_hybrids/`: Native agent implementations (do not modify for EmerEviro integration)
- `.github/copilot-instructions.md`: Updated with BioRAG integration notes
