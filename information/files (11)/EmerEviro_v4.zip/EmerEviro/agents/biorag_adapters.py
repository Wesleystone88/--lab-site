"""
BioRAG Agent Adapters for EmerEviro

Bridges the sophisticated 5/6-pillar BioRAG agents (Quint/Sext) into the
EmerEviro emergence framework. These agents use a different interface 
(choose_action with condition/actions dict) than EmerEviro (select_action with Observation).

This module provides adapter classes that:
1. Convert Observation (from bus) → condition dict + available actions
2. Call the native BioRAG agent's choose_action() method
3. Convert selected action → EmerEviro Action with proper payloads
4. Track decision traces and emergence metrics
"""

# make sure the `deployable_biorag_hybrids` package is importable when
# EmerEviro is run from the workspace root; the native agents rely on
# modules (Time_engine, Bandit_engine, halcyon_research_demo, etc.) that
# live under that directory.
import os, sys
_hybrids_root = os.path.abspath(os.path.join(os.path.dirname(__file__), 'deployable_biorag_hybrids'))
if _hybrids_root not in sys.path:
    sys.path.insert(0, _hybrids_root)

import random
from typing import Dict, List, Tuple, Optional
from bus.bus import AgentClient, EnvironmentBus
from bus.schemas import Action, ActionTier, Observation


class BioRAGAdapterBase(AgentClient):
    """
    Base adapter for all BioRAG agents.
    
    Defines the mapping:
      Observation → (condition_dict, available_actions)
      Action selection → ASSEMBLE/MINT/MUTATE choice
      Feedback loop → update() call
    """
    
    def __init__(self, bus: EnvironmentBus, biorag_agent=None, seed: int = 42):
        super().__init__(bus)
        self.biorag_agent = biorag_agent  # native agent instance (Quint/Sext)
        self.rng = random.Random(seed)
        self.episode_trace = []
        self.episode_num = 0
    
    def _observation_to_condition(self, obs: Observation) -> Dict[str, str]:
        """Convert Observation to condition dict for BioRAG agent."""
        task = obs.task or {}
        return {
            "input": str(task.get("input", "?")),
            "target": str(task.get("target", "?")),
            "variables": ",".join(task.get("variables", [])),
            "step": str(obs.step),
            "budget_remaining": f"{obs.budget_remaining:.2f}",
            "capacity_used": f"{obs.capacity_used}/{obs.capacity_total}",
        }
    
    def _get_available_actions(self, obs: Observation) -> List[str]:
        """
        Get action options based on current library state and budget.
        
        BioRAG agents expect discrete action choices. In EmerEviro, we map:
          - ASSEMBLE: combine existing atoms/primitives
          - MINT: create new primitive (if budget/capacity allow)
          - MUTATE: edit existing primitive (if library exists)
        """
        actions = ["ASSEMBLE"]
        
        # Can mint if we have capacity and budget for it
        if (obs.capacity_used < obs.capacity_total - 5 and 
            obs.budget_remaining > 1.0):
            actions.append("MINT")
        
        # Can mutate if library has entries and we have budget
        if obs.library and obs.budget_remaining > 0.3:
            actions.append("MUTATE")
        
        return actions
    
    def _action_name_to_tier_payload(
        self, 
        action_name: str, 
        obs: Observation
    ) -> Tuple[ActionTier, dict]:
        """
        Convert BioRAG action name to EmerEviro (tier, payload).
        """
        if action_name == "MINT":
            # Mint a new primitive from the task input
            task = obs.task or {}
            return (
                ActionTier.MINT,
                {
                    "definition": task.get("input", ""),
                    "name": f"learned_{self.episode_num}_{len(self.episode_trace)}",
                }
            )
        elif action_name == "MUTATE":
            # Mutate an existing library entry
            if not obs.library:
                # Fallback to ASSEMBLE
                return self._action_name_to_tier_payload("ASSEMBLE", obs)
            
            pid = self.rng.choice([p.id for p in obs.library])
            return (
                ActionTier.MUTATE,
                {
                    "op": "mutate",
                    "primitive_id": pid,
                    "edits": ["add_term"],  # simplified
                    "result": obs.library[0].canonical_form,
                }
            )
        else:  # ASSEMBLE (default)
            atoms = obs.available_atoms or ["x", "y"]
            chosen = self.rng.sample(atoms, min(2, len(atoms)))
            task = obs.task or {}
            
            # Check if we're using library primitives
            used_lib = False
            prim_id = None
            if obs.library and self.rng.random() > 0.5:
                # Sometimes reuse a library entry
                lib_choice = self.rng.choice(obs.library)
                chosen = [lib_choice.id]
                used_lib = True
                prim_id = lib_choice.id
            
            return (
                ActionTier.ASSEMBLE,
                {
                    "op": "combine",
                    "primitives": chosen,
                    "result": task.get("target", ""),
                    "used_library_primitive": used_lib,
                    "primitive_id": prim_id,
                }
            )
    
    def select_action(self, obs: Observation) -> Action:
        """
        Main decision method. Called by the EmerEviro bus.
        
        Flow:
          1. Convert Observation → condition + available_actions
          2. Call biorag_agent.choose_action(condition, actions)
          3. Convert action → EmerEviro Action tier + payload
          4. Return Action
        """
        condition = self._observation_to_condition(obs)
        available_actions = self._get_available_actions(obs)
        
        # Call the native BioRAG agent
        if self.biorag_agent:
            try:
                chosen_action, source = self.biorag_agent.choose_action(
                    condition, available_actions
                )
            except Exception as e:
                # Fallback to random if BioRAG fails
                print(f"BioRAG error: {e}, falling back to ASSEMBLE")
                chosen_action = "ASSEMBLE"
                source = "fallback"
        else:
            # No agent loaded, default to ASSEMBLE
            chosen_action = "ASSEMBLE"
            source = "default"
        
        # Convert to EmerEviro Action
        tier, payload = self._action_name_to_tier_payload(chosen_action, obs)
        action = Action(tier=tier, payload=payload)
        
        # Log this step for emergence analysis
        self.episode_trace.append({
            "step": obs.step,
            "condition": condition,
            "chosen_action": chosen_action,
            "source": source,
            "tier": tier.name,
            "payload": str(payload),
        })
        
        return action
    
    def run_episode(self) -> float:
        """Override to track episode boundaries."""
        self.episode_num += 1
        self.episode_trace = []
        reward = super().run_episode()
        
        # Optional: call update on the native BioRAG agent with episode summary
        if self.biorag_agent and hasattr(self.biorag_agent, 'update'):
            # Simplified: mark episode as successful if reward > 0
            success = reward > 0
            condition = self._observation_to_condition(
                self.bus._env._observe() if hasattr(self.bus._env, '_observe') else None
            )
            if condition:
                try:
                    self.biorag_agent.update(condition, "episode_end", success, self.episode_num)
                except:
                    pass  # Non-critical
        
        return reward


class QuintBioRAGAdapter(BioRAGAdapterBase):
    """
    Adapter for Quint-BioRAG agents (5-pillar).
    
    Quint agents use native choose_action(condition, actions) -> (action, source).
    This adapter calls them directly.
    """
    pass


class SextBioRAGAdapter(BioRAGAdapterBase):
    """
    Adapter for Sext-BioRAG agents (6-pillar with PFC).
    
    Sext extends Quint with impulse control. Same interface.
    """
    pass


# Convenience factory for creating an adapter with a native BioRAG agent
def create_biorag_adapter(
    bus: EnvironmentBus,
    agent_type: str = "quint",
    seed: int = 42,
) -> AgentClient:
    """
    Factory to create a BioRAG adapter.
    
    Args:
        bus: EnvironmentBus instance
        agent_type: "quint" or "sext"
        seed: random seed
    
    Returns:
        BioRAGAdapterBase instance (not yet wired to a native agent)
    
    Note: To use a real native agent, import it and pass to the adapter directly.
    """
    if agent_type == "sext":
        adapter = SextBioRAGAdapter(bus, None, seed)
    else:
        adapter = QuintBioRAGAdapter(bus, None, seed)
    
    return adapter
