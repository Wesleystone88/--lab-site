"""Agents module — candidate and baseline agents."""
