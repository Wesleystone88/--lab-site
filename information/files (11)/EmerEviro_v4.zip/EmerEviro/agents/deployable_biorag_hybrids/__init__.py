"""Package entry for the BioRAG hybrid implementations.

Adding this file ensures the directory is treated as a regular package rather than
an implicit namespace.  This avoids import issues when scripts or tools attempt to
load classes from the folder.

We also re-export the most commonly used classes so callers can write, e.g.:

    from deployable_biorag_hybrids import QuintBioRAGAgent

instead of

    from deployable_biorag_hybrids.quint_biorag import QuintBioRAGAgent

"""

from .quint_biorag import QuintBioRAGAgent
from .sext_biorag import SextBioRAGAgent
from .tri_hybrid_v3 import TriHybridAgentV3

__all__ = [
    "QuintBioRAGAgent",
    "SextBioRAGAgent",
    "TriHybridAgentV3",
]
