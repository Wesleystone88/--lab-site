# System Architecture Diagram

## High-Level Data Flow

```
┌────────────────────────────────────────────────────────────────────┐
│                        EmerEviro Emergence Framework               │
│                                                                     │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │                    AGENT (Select Action)                     │ │
│  │  ┌────────────────────────────────────────────────────────┐  │ │
│  │  │  Option A: Simple Baseline (CandidateAgent)           │  │ │
│  │  │  - Reactive: mint after seeing pattern twice          │  │ │
│  │  │  - Tests framework correctness                        │  │ │
│  │  └────────────────────────────────────────────────────────┘  │ │
│  │                                                                │ │
│  │  ┌────────────────────────────────────────────────────────┐  │ │
│  │  │  Option B: LLM Agent (ClaudeAgent)                    │  │ │
│  │  │  - Calls Anthropic API with observation context       │  │ │
│  │  │  - Returns structured Action (JSON)                   │  │ │
│  │  └────────────────────────────────────────────────────────┘  │ │
│  │                                                                │ │
│  │  ┌────────────────────────────────────────────────────────┐  │ │
│  │  │  Option C: BioRAG Agent (via Adapter)            [NEW] │  │ │
│  │  │  ┌──────────────────────────────────────────────────┐  │  │ │
│  │  │  │   BioRAGAdapterBase                            │  │  │ │
│  │  │  │   • Converts Observation → condition dict       │  │  │ │
│  │  │  │   • Calls native agent.choose_action()         │  │  │ │
│  │  │  │   • Returns Action(tier, payload)              │  │  │ │
│  │  │  │   • Logs pillar decisions                       │  │  │ │
│  │  │  └───────────┬──────────────────────────────────────┘  │  │ │
│  │  │              │                                          │  │ │
│  │  │              ↓ calls native agent                       │  │ │
│  │  │  ┌──────────────────────────────────────────────────┐  │  │ │
│  │  │  │  Native BioRAG Agent (QuintBioRAGAgent)         │  │  │ │
│  │  │  │  • 5 Cognitive Pillars:                         │  │  │ │
│  │  │  │    1. CME (Constrained Memory)                  │  │  │ │
│  │  │  │    2. Bandit (Thompson Sampling)                │  │  │ │
│  │  │  │    3. TFE (Temporal Field Engine)               │  │  │ │
│  │  │  │    4. PEE (Prediction Error Engine)             │  │  │ │
│  │  │  │    5. BioRAG (Biological RAG)                   │  │  │ │
│  │  │  │  • Returns (action, source) tuple               │  │  │ │
│  │  │  └──────────────────────────────────────────────────┘  │  │ │
│  │  └────────────────────────────────────────────────────────┘  │ │
│  └──────────────┬───────────────────────────────────────────────┘ │
│                 │                                                 │
│                 ↓                                                 │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │              EnvironmentBus (Protocol Boundary)               │ │
│  │                                                               │ │
│  │  Validate Action:                                            │ │
│  │  - tier ∈ {ASSEMBLE, MUTATE, MINT}                          │ │
│  │  - payload is dict                                           │ │
│  │                                                               │ │
│  │  Input:  Action(tier, payload)                              │ │
│  │  Output: StepResult(next_obs, reward, done)                │ │
│  └──────────────┬───────────────────────────────────────────────┘ │
│                 │                                                 │
│                 ↓                                                 │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │              Environment (Step Dynamics)                      │ │
│  │  ┌────────────────────────────────────────────────────────┐  │ │
│  │  │  MathEnvironment:                                     │  │ │
│  │  │  • Task: algebraic expression simplification          │  │ │
│  │  │  • Handler: _handle_assemble, _handle_mint, etc.     │  │ │
│  │  │  • Scorer: reward = 2.0 if result matches target    │  │ │
│  │  │  • Library: persistent, capacity-limited (50 nodes)  │  │ │
│  │  │  • Budget: episodic (~5.0¢), decrements per action  │  │ │
│  │  └────────────────────────────────────────────────────────┘  │ │
│  │                                                               │ │
│  │  Actions Tier → Costs:                                       │ │
│  │  • ASSEMBLE: 0.05¢  (combine atoms/primitives)              │ │
│  │  • MUTATE:   0.30¢  (edit existing primitive)               │ │
│  │  • MINT:     1.00¢  (define new primitive)                  │ │
│  │                                                               │ │
│  └──────────────┬───────────────────────────────────────────────┘ │
│                 │                                                 │
│                 ↓                                                 │
│  ┌──────────────────────────────────────────────────────────────┐ │
│  │              Observation (Feed Back to Agent)                 │ │
│  │  • task:             {input, target, variables, atoms}        │ │
│  │  • library:          [LibraryEntry(id, form, size, use_count)]│ │
│  │  • capacity_used:    Σ node counts of all primitives         │ │
│  │  • capacity_total:   50 (hard limit)                         │ │
│  │  • budget_remaining: how much reward budget left this episode│ │
│  └────────────────────────────────────────────────────────────────┘ │
│                                                                     │
└────────────────────────────────────────────────────────────────────┘
                              ↓ (next step)
                         (loop until done)
```

## Episode Loop

```
┌─────────────────────────────────────────────────────────────┐
│  for episode in range(N_EPISODES):                          │
├─────────────────────────────────────────────────────────────┤
│  obs = bus.reset()                                          │
│  total_reward = 0                                           │
│  trace = []                                                 │
│                                                              │
│  while not done:                                            │
│    ┌─────────────────────────────────────────────────────┐  │
│    │ action = agent.select_action(obs)                  │  │
│    │                                                      │  │
│    │ (BioRAG path: Observation → condition →            │  │
│    │  choose_action(condition, actions) →               │  │
│    │  map back to Action tier + payload)                │  │
│    └─────────────────────────────────────────────────────┘  │
│                                                              │
│    ┌─────────────────────────────────────────────────────┐  │
│    │ result = bus.act(action)                           │  │
│    │ # → env.step(action) → MathEnvironment processes  │  │
│    │ # → returns StepResult(obs, reward, done)          │  │
│    └─────────────────────────────────────────────────────┘  │
│                                                              │
│    trace.append(action.tier, action.payload, result.reward)│
│    total_reward += result.reward                            │
│    obs = result.observation                                │
│                                                              │
│  # End episode                                              │
│  tracker.record(EpisodeRecord(...))                         │
│  # Compute: reuse_rate, BCG, time_to_stability             │
│                                                              │
└─────────────────────────────────────────────────────────────┘
         ↓
┌─────────────────────────────────────────────────────────────┐
│  # After N episodes:                                        │
│  summary = tracker.summary()                                │
│  {                                                           │
│    "mean_reward": 20.6325,                                  │
│    "reuse_rate": 0.5175,   # % of steps using library      │
│    "bcg": 0.0,             # compression bits saved         │
│    "time_to_stability": -1 # episodes to convergence        │
│  }                                                           │
│                                                              │
│  # Compare agents:                                          │
│  if candidate.mean_reward > null_b.mean_reward AND          │
│     candidate.mean_reward > null_c.mean_reward AND          │
│     candidate.reuse_rate > null_b.reuse_rate AND            │
│     candidate.bcg > null_c.bcg:                             │
│    → EMERGENCE DEMONSTRATED ✓                              │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

## Adapter: How BioRAG Bridges In

```
┌─────────────────────────────────────────────────────────────┐
│  BioRAGAdapterBase (in agents/biorag_adapters.py)           │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Input: Observation                                         │
│    obs = {                                                   │
│      episode_id: 1,                                         │
│      step: 3,                                               │
│      task: {input: "x**2 + 2*x*y + y**2", ...},            │
│      available_atoms: ["x", "y", "+", "*", ...],           │
│      library: [LibraryEntry(id="p0", ...), ...],           │
│      capacity_used: 15,                                     │
│      capacity_total: 50,                                    │
│      budget_remaining: 3.50,                                │
│    }                                                         │
│                                                              │
│  Step 1: Observation → Condition                            │
│    condition = _observation_to_condition(obs)               │
│    → {                                                       │
│        "input": "x**2 + 2*x*y + y**2",                     │
│        "target": "(x + y)**2",                              │
│        "variables": "x,y",                                  │
│        "budget_remaining": "3.50",                          │
│        "capacity_used": "15/50",                            │
│      }                                                       │
│                                                              │
│  Step 2: Determine Available Actions                        │
│    actions = _get_available_actions(obs)                    │
│    → ["ASSEMBLE"]  (budget too low for MINT, library empty)│
│    or ["ASSEMBLE", "MINT", "MUTATE"] (if resources allow) │
│                                                              │
│  Step 3: Call Native BioRAG Agent                           │
│    chosen_action, source = biorag_agent.choose_action(      │
│      condition,              # dict with task context        │
│      actions                 # available options             │
│    )                                                         │
│    → action = "ASSEMBLE"                                    │
│    → source = "Bandit"  (which pillar decided?)             │
│                                                              │
│  Step 4: Action → EmerEviro Tier + Payload                  │
│    tier, payload = _action_name_to_tier_payload(            │
│      chosen_action, obs                                     │
│    )                                                         │
│    → tier = ActionTier.ASSEMBLE                             │
│    → payload = {                                             │
│        "op": "combine",                                      │
│        "primitives": ["x", "y"],                            │
│        "result": "(x + y)**2",                              │
│        "used_library_primitive": False,                      │
│        "primitive_id": None,                                 │
│      }                                                       │
│                                                              │
│  Step 5: Log Trace & Return Action                          │
│    episode_trace.append({                                   │
│      "step": 3,                                             │
│      "chosen_action": "ASSEMBLE",                           │
│      "source": "Bandit",  # pillar attribution              │
│      ...                                                     │
│    })                                                        │
│    return Action(tier=ActionTier.ASSEMBLE, payload=...)    │
│                                                              │
│  Output: Action (ready for bus.act())                       │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

## Emergence Detection: The Three Tests

```
┌─────────────────────────────────────────────────────────────┐
│  Run 3 parallel experiments (100 episodes each)              │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  1. CANDIDATE AGENT                                         │
│     (CandidateAgent or BioRAG adapter)                      │
│     → Can MINT primitives? YES                              │
│     → Can learn to REUSE? YES                               │
│     → Result: mean_reward = +20.6                           │
│                reuse_rate = 0.52                            │
│                bcg = 0.0 (approximate)                      │
│                                                              │
│  2. NULL B: NO MINTING                                      │
│     (Assembly-only, no new primitives)                      │
│     → Can MINT primitives? NO                               │
│     → Forced to use only initial atoms                      │
│     → Result: mean_reward = -1.0                            │
│                reuse_rate = 0.0                             │
│                bcg = 0.0                                    │
│                                                              │
│  3. NULL C: EPISODIC MEMORY ONLY                            │
│     (Persistent cache, no compositional library)            │
│     → Can MINT primitives? NO                               │
│     → Can build composite structures? NO                    │
│     → Only raw storage (episode repetition = "luck")        │
│     → Result: mean_reward = -1.0                            │
│                reuse_rate = 0.0                             │
│                bcg = 0.0                                    │
│                                                              │
├─────────────────────────────────────────────────────────────┤
│  EMERGENCE CLAIM:                                            │
│                                                              │
│  if (candidate.reward > null_b.reward) AND                  │
│     (candidate.reward > null_c.reward) AND                  │
│     (candidate.reuse > null_b.reuse) AND                    │
│     (candidate.bcg > null_c.bcg):                           │
│    → EMERGENCE DEMONSTRATED!                               │
│    → Agent learned STRUCTURE, not just tricks               │
│                                                              │
│  Current Results:                                            │
│  candidate (+20.6) > null_b (-1) ✓                          │
│  candidate (+20.6) > null_c (-1) ✓                          │
│  candidate (0.52) > null_b (0.0) ✓                          │
│  candidate (0.0) > null_c (0.0) ?  (needs improvement)      │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

## Library Dynamics

```
┌─────────────────────────────────────────────────────────────┐
│  Episode 1                Episode 2                          │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  Library: empty          Library: [p0: x+y]                 │
│  Available atoms:        Available atoms:                    │
│  [x, y, +, *, ...]       [x, y, +, *, ...]                 │
│  Capacity: 0/50          Capacity: 3/50  (p0 costs 3 nodes)│
│                                                              │
│  Agent tries:            Agent tries:                        │
│  MINT (x+y) → p0                                            │
│  cost: 1.00¢             ASSEMBLE [p0, x] → (x+y)*x         │
│  ← New primitive added   cost: 0.05¢                        │
│                          ← Reuses p0 (cheaper!)            │
│                                                              │
│  Reuse Rate: 0.0         Reuse Rate: 0.5  (half steps reuse)│
│  ↑                       ↑                                  │
│  No library primitives   p0 is useful!                      │
│  yet to reuse                                               │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

---

**Key Insight**: Agent learns to **invest upfront** (mint primitives) 
to get **long-term savings** (reuse). This is **structural learning**, 
not luck. Emergence is real when it beats all three nulls.
