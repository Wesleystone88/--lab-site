"""
Minimal test agent.
Demonstrates the interface every agent must implement.
Passes decontamination. Random choices — not a good agent.
"""
import random

class RandomAgent:
    """
    The simplest possible valid agent.
    Clears decontamination. Will be INSUFFICIENT in most chambers.
    Use as a baseline and a template.
    """
    name = 'RandomAgent-v1'

    def __init__(self, seed=42):
        self.rng = random.Random(seed)

    def choose_action(self, context: dict, choices: list):
        """Required. Returns (action, source)."""
        if not choices:
            return 'none', 'random'
        return self.rng.choice(choices), 'random'

    def update(self, condition: dict, action: str, success: bool, step: int):
        """Required. Random agent ignores feedback."""
        pass
