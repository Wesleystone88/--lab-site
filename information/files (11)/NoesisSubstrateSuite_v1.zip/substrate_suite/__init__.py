"""
Noesis Substrate Suite
======================
A standalone, agent-agnostic reasoning environment suite.

Any agent that clears decontamination can be introduced into any chamber.

Quick start:
    from substrate_suite import run, run_suite, substrate_registry

    # List available chambers
    for c in substrate_registry.list_chambers():
        print(c)

    # Run one agent through one chamber
    from substrate_suite.chambers.causal_inference import CausalInferenceChamber
    report = run(my_agent, CausalInferenceChamber(), n_episodes=200)

    # Run one agent through all chambers
    results = run_suite(my_agent)

    # See leaderboard
    from substrate_suite.metrics.viability_metrics import benchmark_registry
    benchmark_registry.print_leaderboard()
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from substrate_suite.core.substrate_contract import (
    SubstrateBase, ChamberSpec, substrate_registry
)
from substrate_suite.core.decontamination import (
    decontaminate, DecontaminationVestibule, ClearanceLevel
)
from substrate_suite.metrics.viability_metrics import (
    ViabilityMeter, ViabilityProfile, EpisodeRecord, benchmark_registry
)
from substrate_suite.suite_runner import run, run_suite

# Auto-register all chambers by importing them
from substrate_suite.chambers import causal_inference   # noqa — registers on import
from substrate_suite.chambers import unified_chamber    # noqa — registers on import

# Legacy chamber (requires EmerEviro on path)
try:
    from substrate_suite.chambers.legacy import iq_legacy  # noqa
except ImportError:
    pass  # Legacy chamber optional — EmerEviro path not set

__all__ = [
    'SubstrateBase', 'ChamberSpec', 'substrate_registry',
    'decontaminate', 'ClearanceLevel',
    'ViabilityMeter', 'ViabilityProfile', 'EpisodeRecord', 'benchmark_registry',
    'run', 'run_suite',
]
