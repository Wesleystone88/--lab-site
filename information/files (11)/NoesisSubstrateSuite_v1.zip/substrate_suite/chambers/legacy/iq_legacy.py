"""
Noesis Substrate Suite
======================
chambers/legacy/iq_legacy.py

CHAMBER 01 — IQ PATTERN LEGACY
--------------------------------
The original five pattern classes. Proven at 96-100% accuracy.
Wrapped in the substrate contract. Interior untouched.

This is the baseline chamber. Every new agent should run here first.
Clearance here does not guarantee viability elsewhere.
Failure here means the agent cannot reason structurally at all.

PROBLEM CLASSES
---------------
cross_sequence          Arithmetic dependency between three series
constraint_satisfaction Simultaneous multi-rule satisfaction
rule_inversion          Temporal pattern that inverts
structural_analogy      Compound transformation: A→B as C→?
code_pattern_hybrid     Structural invariant across surfaces

STRUCTURAL PRINCIPLE
--------------------
Modelled on: invariant detection under surface noise
The hidden rule is structural. The surface rotates. The rule does not.
An agent that memorised the surface fails when the surface changes.
"""

from __future__ import annotations
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', '..'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'EmerEviro3', 'EmerEviro'))
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', 'EmerEviro3', 'EmerEviro', 'agents', 'deployable_biorag_hybrids'))

from substrate_suite.core.substrate_contract import SubstrateBase, ChamberSpec, substrate_registry


@substrate_registry.register('iq_legacy')
class IQLegacyChamber(SubstrateBase):
    """
    Legacy IQ pattern environment wrapped in the substrate contract.

    The original environment is instantiated internally.
    All external interactions go through the substrate interface.
    The interior is untouched — this is a pure wrapper.
    """

    def __init__(self, seed: int = 42):
        self.seed  = seed
        self._env  = None
        self._episode = 0
        self._outcomes: list = []
        self._snapshots: list = []
        self._last_info: dict = {}
        self._class_outcomes: dict = {}
        self._surface_outcomes: dict = {}
        self._load_env()

    def _load_env(self):
        """Load the legacy environment. Fails gracefully if not available."""
        try:
            from environments import iq_patterns as iq_mod
            from environments.iq_patterns import IQPatternEnv

            # Patch observe to match substrate observation schema
            def _patched_observe(env_self):
                p = env_self._problem
                choices_str = [str(c) for c in p.get('choices', [])]
                structural  = env_self._extract_structural_features(p)
                return {
                    'episode_id': env_self._episode,
                    'step': 0,
                    'chamber_id': 'iq_legacy',
                    'task': {
                        'display': str(p.get('display', {}).get('given', '')),
                        'context': structural,
                        'choices': choices_str,
                        'input':   p.get('display', {}),
                    },
                    'viability': {
                        'episodes_completed': self._episode,
                        'current_accuracy':   self._current_accuracy(),
                        'convergence_signal': self._convergence_signal(),
                    }
                }

            iq_mod.IQPatternEnv._observe = _patched_observe
            self._env = IQPatternEnv(seed=self.seed)
            self._available = True
        except ImportError:
            self._available = False
            self._env = None

    @property
    def spec(self) -> ChamberSpec:
        return ChamberSpec(
            chamber_id='iq_legacy',
            display_name='IQ Pattern Legacy',
            version='1.0.0',
            domain='mathematics',
            description=(
                'Five hard pattern classes designed to expose architectural '
                'limitations. Surface representation rotates every episode. '
                'Hidden rule is constant. An agent that memorised the surface fails.'
            ),
            structural_principle=(
                'Invariant detection under surface noise. '
                'Models: signal extraction from noisy observation, '
                'structural homology across representations.'
            ),
            difficulty=3,
            problem_classes=[
                'cross_sequence',
                'constraint_satisfaction',
                'rule_inversion',
                'structural_analogy',
                'code_pattern_hybrid',
            ],
            tags=['legacy', 'pattern', 'invariant', 'mathematics', 'baseline'],
            added='2026-02-27',
        )

    def reset(self, episode_id: int = 0) -> dict:
        self._episode = episode_id
        if not self._available:
            return self._unavailable_obs(episode_id)

        obs = self._env.reset(episode_id=episode_id)
        return obs

    def step(self, action: dict) -> tuple[dict, float, bool, dict]:
        if not self._available:
            return (
                self._unavailable_obs(self._episode),
                0.0, True,
                self._make_info(False, '', '', '', {}),
            )

        # Normalise action — accept dict or direct string
        if isinstance(action, dict):
            answer = action.get('answer', '')
        else:
            # Accept Action objects from original engine
            answer = action

        new_obs, reward, done, raw_info = self._env.step(answer)

        success = raw_info.get('success', False)
        cls     = raw_info.get('class', '')
        surface = raw_info.get('surface', '')
        correct = str(raw_info.get('correct_answer', ''))

        # Track for metrics
        self._outcomes.append(success)
        self._class_outcomes.setdefault(cls, []).append(success)
        self._surface_outcomes.setdefault((cls, surface), []).append(success)

        # Upgrade obs to substrate schema
        if isinstance(new_obs, dict) and 'viability' not in new_obs:
            new_obs['viability'] = {
                'episodes_completed': self._episode,
                'current_accuracy':   self._current_accuracy(),
                'convergence_signal': self._convergence_signal(),
            }

        info = self._make_info(
            success=success,
            correct_answer=correct,
            problem_class=cls,
            surface=surface,
            structural_features=raw_info.get('structural_features',
                new_obs.get('task', {}).get('context', {})),
        )
        self._last_info = info
        return new_obs, reward, done, info

    def run_probes(self, episode: int) -> dict:
        """Diagnostic suite — surface invariance, class breakdown, convergence."""
        outcomes = self._outcomes
        n = len(outcomes)

        if n < 10:
            return {
                'structural_recognition_rate': 0.0,
                'surface_invariance': 0.0,
                'convergence_episode': -1,
                'probe_flags': ['insufficient_data'],
            }

        # Overall accuracy
        srr = sum(outcomes) / n

        # Surface invariance per class
        class_surface_accs = {}
        for (cls, surface), results in self._surface_outcomes.items():
            if cls not in class_surface_accs:
                class_surface_accs[cls] = []
            class_surface_accs[cls].append(sum(results)/len(results))

        surface_inv = 0.0
        if class_surface_accs:
            invs = []
            for cls, accs in class_surface_accs.items():
                if len(accs) > 1:
                    mean = sum(accs)/len(accs)
                    var  = sum((a-mean)**2 for a in accs)/len(accs)
                    invs.append(max(0.0, 1.0 - (var**0.5) * 2))
                else:
                    invs.append(1.0)
            surface_inv = sum(invs)/len(invs)

        # Convergence
        window = 10
        conv_ep = -1
        for i in range(n - window + 1):
            if sum(outcomes[i:i+window]) / window >= 0.80:
                conv_ep = i + 1
                break

        return {
            'structural_recognition_rate': round(srr, 4),
            'surface_invariance':          round(surface_inv, 4),
            'convergence_episode':         conv_ep,
            'accuracy_by_class':           {
                cls: round(sum(v)/len(v), 4)
                for cls, v in self._class_outcomes.items()
            },
            'probe_flags': [],
        }

    def info(self) -> dict:
        return {
            'episodes_run':      self._episode,
            'current_accuracy':  self._current_accuracy(),
            'available':         self._available,
            'class_breakdown':   {
                cls: round(sum(v)/len(v), 4)
                for cls, v in self._class_outcomes.items()
            },
        }

    # ── Helpers ──────────────────────────────────────────────────────────────

    def _current_accuracy(self) -> float:
        if not self._outcomes:
            return 0.0
        recent = self._outcomes[-20:]
        return sum(recent) / len(recent)

    def _convergence_signal(self) -> float:
        if len(self._outcomes) < 10:
            return 0.0
        recent = self._outcomes[-10:]
        acc = sum(recent) / 10
        return min(1.0, acc * 1.2)  # signal rises faster than accuracy

    def _unavailable_obs(self, episode_id: int) -> dict:
        return self._make_observation(
            episode_id=episode_id, step=0,
            display='[Legacy environment not available — check import paths]',
            context={'class': 'unavailable', 'surface': 'none'},
            choices=['A', 'B', 'C', 'D'],
        )
