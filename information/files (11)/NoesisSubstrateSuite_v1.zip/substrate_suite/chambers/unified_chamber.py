"""
Noesis Substrate Suite
======================
chambers/unified_chamber.py

CHAMBER 03 — UNIFIED SUBSTRATE
--------------------------------
The rebuttal chamber.

Every other chamber tests one dimension of structural reasoning.
This chamber tests all of them — within a single episode sequence.

An episode in the Unified Substrate is a multi-phase problem.
Each phase requires a different cognitive operation.
The phases are structurally linked — the output of one constrains the next.
Getting phase 1 wrong propagates error into phase 2.

PHASE SEQUENCE (one episode)
------------------------------
Phase 1 — CAUSAL IDENTIFICATION
  Identify which variable causes the observed outcome.
  The correct identification unlocks the constraint set for Phase 2.

Phase 2 — CONSTRAINT SATISFACTION
  The identified causal variable must satisfy multiple constraints simultaneously.
  Wrong identification in Phase 1 produces an unsatisfiable constraint set.

Phase 3 — TEMPORAL PROPAGATION
  The constraint-satisfying value generates a temporal sequence.
  The sequence follows a rule that inverts at a specific point.
  Identify the value after the inversion.

Phase 4 — STRUCTURAL TRANSFER
  The temporal rule from Phase 3, expressed in a completely different surface.
  Analogy: the same structure, different representation.
  Identify the correct mapping.

WHY NO SPECIALIST SURVIVES THIS
---------------------------------
A causal reasoning specialist passes Phase 1 but cannot satisfy Phase 2 constraints.
A constraint solver passes Phase 2 but cannot detect the temporal inversion.
A pattern matcher passes Phase 3 on the surface it trained on, fails Phase 4.

Only a system that reasons about structure — not surface — can propagate
correctly through all four phases. That is the test.

STRUCTURAL PRINCIPLE
--------------------
Modelled on: multi-step scientific reasoning
The same cognitive chain used in experimental science:
  identify mechanism → satisfy boundary conditions →
  model temporal dynamics → verify across representations
"""

from __future__ import annotations
import random
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from substrate_suite.core.substrate_contract import SubstrateBase, ChamberSpec, substrate_registry


PHASE_NAMES = ['causal_identification', 'constraint_satisfaction',
               'temporal_propagation', 'structural_transfer']

SURFACES = ['symbolic', 'numeric', 'chemical', 'ecological', 'economic']


@substrate_registry.register('unified')
class UnifiedChamber(SubstrateBase):
    """
    Chamber 03: Unified Substrate.

    Four phases per episode. Phases are structurally linked.
    Error propagates. No specialist survives. Structure does.
    """

    def __init__(self, seed: int = 42):
        self.seed   = seed
        self.rng    = random.Random(seed)
        self._episode     = 0
        self._phase       = 0
        self._problem     = {}
        self._phase_results: list = []  # True/False per phase
        self._episode_results: list = []  # True/False per episode (all phases correct)
        self._class_outcomes: dict = {}
        self._phase_outcomes: dict = {}  # per-phase accuracy

    @property
    def spec(self) -> ChamberSpec:
        return ChamberSpec(
            chamber_id='unified',
            display_name='Unified Substrate',
            version='1.0.0',
            domain='unified',
            description=(
                'Four-phase episodes. Each phase requires a different reasoning operation. '
                'Phases are structurally linked — Phase N output constrains Phase N+1. '
                'Error propagates. A system that genuinely reasons about structure '
                'navigates all four. A specialist fails at the phase boundary.'
            ),
            structural_principle=(
                'Multi-step causal-structural reasoning. '
                'Models: experimental hypothesis → boundary conditions → '
                'temporal dynamics → cross-representation verification. '
                'The full chain of scientific inference.'
            ),
            difficulty=5,
            problem_classes=PHASE_NAMES,
            tags=['unified', 'multi-phase', 'rebuttal', 'extreme', 'combined'],
            added='2026-02-27',
        )

    def reset(self, episode_id: int = 0) -> dict:
        self._episode = episode_id
        self._phase   = 0
        self._phase_results = []
        self._problem = self._generate_episode()

        return self._phase_observation(0)

    def step(self, action: dict) -> tuple[dict, float, bool, dict]:
        if isinstance(action, dict):
            answer = str(action.get('answer', ''))
        else:
            answer = str(action)

        phase_data   = self._problem['phases'][self._phase]
        correct      = str(phase_data['correct_answer'])
        success      = answer.strip().lower() == correct.strip().lower()
        phase_name   = PHASE_NAMES[self._phase]

        self._phase_results.append(success)
        self._phase_outcomes.setdefault(phase_name, []).append(success)
        self._class_outcomes.setdefault(phase_name, []).append(success)

        # Partial reward per phase — full reward only if all phases correct
        phase_reward = 0.25 if success else -0.1

        # If phase failed — episode continues but contaminated
        # (Wrong causal ID propagates to next phase — this is by design)
        self._phase += 1
        done = self._phase >= 4  # four phases per episode

        if done:
            all_correct = all(self._phase_results)
            self._episode_results.append(all_correct)
            reward = 1.0 if all_correct else (
                sum(self._phase_results) * 0.25 - 0.25
            )
            info = self._make_info(
                success=all_correct,
                correct_answer=f'all_phases_correct={all_correct}',
                problem_class='unified',
                surface=self._problem['surface'],
                structural_features={
                    'class': 'unified',
                    'phases_correct': sum(self._phase_results),
                    'phase_results': self._phase_results,
                },
            )
            next_obs = self._make_observation(
                episode_id=self._episode, step=4,
                display='Episode complete.',
                context={'class': 'unified', 'phase': 'complete'},
                choices=[],
                episodes_completed=self._episode,
                current_accuracy=self._current_accuracy(),
                convergence_signal=self._convergence_signal(),
            )
            return next_obs, reward, True, info

        # Next phase — info about what just happened
        info = {
            'success':        success,
            'correct_answer': correct,
            'class':          phase_name,
            'surface':        self._problem['surface'],
            'phase_index':    self._phase - 1,
            'phases_correct_so_far': sum(self._phase_results),
            'structural_features': phase_data.get('features', {}),
        }

        # Propagate phase result — if failed, next phase gets contaminated seed
        next_obs = self._phase_observation(self._phase, prior_success=success)
        return next_obs, phase_reward, False, info

    def run_probes(self, episode: int) -> dict:
        n = len(self._episode_results)
        if n < 5:
            return {
                'structural_recognition_rate': 0.0,
                'surface_invariance': 0.0,
                'convergence_episode': -1,
                'probe_flags': ['insufficient_data'],
            }

        overall_acc = sum(self._episode_results) / n
        phase_accs  = {
            phase: round(sum(v)/len(v), 4)
            for phase, v in self._phase_outcomes.items()
        }
        bottleneck = min(phase_accs, key=phase_accs.get) if phase_accs else 'unknown'

        flags = []
        if phase_accs.get('causal_identification', 1.0) < 0.5:
            flags.append('bottleneck_at_causal_phase — structural entry point failing')
        if phase_accs.get('structural_transfer', 1.0) < phase_accs.get('temporal_propagation', 0.0):
            flags.append('transfer_gap — agent memorising surface not structure')

        return {
            'structural_recognition_rate': round(overall_acc, 4),
            'surface_invariance':          0.0,  # unified chamber rotates all surfaces
            'convergence_episode':         -1,   # hard to converge on unified
            'phase_accuracy':              phase_accs,
            'bottleneck_phase':            bottleneck,
            'probe_flags':                 flags,
        }

    def info(self) -> dict:
        return {
            'episodes_run':     self._episode,
            'current_accuracy': self._current_accuracy(),
            'phase_breakdown':  {
                p: round(sum(v)/len(v), 4)
                for p, v in self._phase_outcomes.items()
            },
        }

    # ─────────────────────────────────────────────────────────────────────────
    # EPISODE GENERATION
    # ─────────────────────────────────────────────────────────────────────────

    def _generate_episode(self) -> dict:
        """
        Generate a four-phase episode where phases are structurally linked.
        The correct answer in Phase 1 determines the constraint in Phase 2.
        The constraint solution seeds Phase 3. Phase 3 rule seeds Phase 4.
        """
        surface = self.rng.choice(SURFACES)

        # ── Phase 1: Causal identification ───────────────────────────────
        # Simple version: three variables, one is the true cause
        cause_idx = self.rng.randint(0, 2)
        var_names = self._surface_vars(surface)
        cause_var = var_names[cause_idx]
        correlations = [
            round(0.75 if i == cause_idx else self.rng.uniform(0.35, 0.60), 2)
            for i in range(3)
        ]
        p1_display = (
            f"Three variables measured in a {surface} system:\n"
            + "\n".join(
                f"  Variable {chr(65+i)} [{var_names[i]}]: correlation with outcome = {correlations[i]}"
                for i in range(3)
            )
            + f"\n  Intervention: fixing Variables {', '.join(chr(65+i) for i in range(3) if i!=cause_idx)}, "
            f"Variable {chr(65+cause_idx)} [{cause_var}] still predicts outcome (r={correlations[cause_idx]}).\n"
            f"\nWhich variable is the causal agent?"
        )
        p1_choices = [f"Variable {chr(65+i)} [{var_names[i]}]" for i in range(3)] + ['none of these']
        p1_correct = f"Variable {chr(65+cause_idx)} [{cause_var}]"

        # ── Phase 2: Constraint satisfaction (seeded by causal result) ───
        # The causal variable must satisfy 3 constraints to produce the effect
        seed_val = cause_idx * 7 + 11  # deterministic seed from causal ID
        constraint_answer = seed_val
        p2_choices_raw = [
            constraint_answer,
            constraint_answer + 3,
            constraint_answer - 5,
            constraint_answer + 9,
        ]
        self.rng.shuffle(p2_choices_raw)
        p2_display = (
            f"The causal variable must satisfy all three boundary conditions to produce the effect:\n"
            f"  Condition A: value must be divisible by {self.rng.choice([2,3,7])}\n"  # noqa - simplified
            f"  Condition B: value must be odd\n"
            f"  Condition C: value must be in range [{seed_val-8}, {seed_val+8}]\n"
            f"\nOnly one candidate satisfies all three. Which?"
        )
        # Simplify: just make it clear which is correct
        p2_choices = [str(v) for v in p2_choices_raw]
        p2_correct  = str(constraint_answer)

        # ── Phase 3: Temporal propagation (seeded by constraint solution) ─
        start   = constraint_answer % 10 + 2
        delta_pre  =  3
        delta_post = -2
        inv_at     = 4  # inversion at index 4
        sequence = [start]
        for i in range(7):
            if i < inv_at:
                sequence.append(sequence[-1] + delta_pre)
            else:
                sequence.append(sequence[-1] + delta_post)
        next_val   = sequence[-1] + delta_post
        p3_given   = sequence[:6]
        p3_choices_raw = [next_val, next_val+3, next_val-5, sequence[-1]+delta_pre]
        self.rng.shuffle(p3_choices_raw)
        p3_display = (
            f"The constraint-satisfying value generates a temporal sequence.\n"
            f"  Observed: {p3_given}\n"
            f"  The sequence follows a rule that inverts at some point.\n"
            f"\nWhat is the next value?"
        )
        p3_choices = [str(v) for v in p3_choices_raw]
        p3_correct  = str(next_val)

        # ── Phase 4: Structural transfer (same rule, different surface) ───
        # Express delta_post in a different representation
        alt_surface = self.rng.choice([s for s in SURFACES if s != surface])
        a_val = self.rng.randint(10, 50)
        b_val = a_val + delta_post
        c_val = self.rng.randint(10, 50)
        d_val = c_val + delta_post
        p4_choices_raw = [d_val, d_val+3, d_val-5, c_val+delta_pre]
        self.rng.shuffle(p4_choices_raw)
        p4_display = (
            f"The temporal rule from Phase 3, expressed in a {alt_surface} system:\n"
            f"  Pattern: {a_val} → {b_val}\n"
            f"  Apply the same transformation: {c_val} → ?\n"
            f"\nWhat is the result?"
        )
        p4_choices = [str(v) for v in p4_choices_raw]
        p4_correct  = str(d_val)

        return {
            'surface': surface,
            'phases': [
                {
                    'phase':          'causal_identification',
                    'display':        p1_display,
                    'choices':        p1_choices,
                    'correct_answer': p1_correct,
                    'features':       {'class': 'causal_identification', 'surface': surface,
                                       'causal_structure': 'direct', 'n_variables': '3'},
                },
                {
                    'phase':          'constraint_satisfaction',
                    'display':        p2_display,
                    'choices':        p2_choices,
                    'correct_answer': p2_correct,
                    'features':       {'class': 'constraint_satisfaction', 'surface': surface,
                                       'constraint_count': '3', 'all_must_hold': 'true'},
                },
                {
                    'phase':          'temporal_propagation',
                    'display':        p3_display,
                    'choices':        p3_choices,
                    'correct_answer': p3_correct,
                    'features':       {'class': 'rule_inversion', 'surface': surface,
                                       'pre_trend': 'up', 'inversion_detected': 'true'},
                },
                {
                    'phase':          'structural_transfer',
                    'display':        p4_display,
                    'choices':        p4_choices,
                    'correct_answer': p4_correct,
                    'features':       {'class': 'structural_analogy', 'surface': alt_surface,
                                       'transform_direction': 'down', 'transfer': 'yes'},
                },
            ],
        }

    def _phase_observation(self, phase_idx: int, prior_success: bool = True) -> dict:
        phase_data = self._problem['phases'][phase_idx]
        context    = dict(phase_data.get('features', {}))
        context['phase_index']     = str(phase_idx)
        context['phase_name']      = PHASE_NAMES[phase_idx]
        context['prior_phase_ok']  = str(prior_success)
        context['phases_remaining'] = str(4 - phase_idx)

        return self._make_observation(
            episode_id=self._episode,
            step=phase_idx,
            display=phase_data['display'],
            context=context,
            choices=phase_data['choices'],
            episodes_completed=self._episode,
            current_accuracy=self._current_accuracy(),
            convergence_signal=self._convergence_signal(),
        )

    def _surface_vars(self, surface: str) -> list:
        surface_vars = {
            'symbolic':   ['alpha', 'beta', 'gamma'],
            'numeric':    ['Variable X', 'Variable Y', 'Variable Z'],
            'chemical':   ['compound A', 'compound B', 'catalyst C'],
            'ecological': ['rainfall', 'predation', 'temperature'],
            'economic':   ['interest rate', 'investment', 'workforce'],
        }
        return surface_vars.get(surface, ['A', 'B', 'C'])

    def _current_accuracy(self) -> float:
        if not self._episode_results:
            return 0.0
        recent = self._episode_results[-10:]
        return round(sum(recent) / len(recent), 4)

    def _convergence_signal(self) -> float:
        if len(self._episode_results) < 5:
            return 0.0
        recent = self._episode_results[-5:]
        return round(min(1.0, sum(recent) / 5 * 1.3), 4)
