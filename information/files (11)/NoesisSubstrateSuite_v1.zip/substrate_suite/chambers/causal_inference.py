"""
Noesis Substrate Suite
======================
chambers/causal_inference.py

CHAMBER 02 — CAUSAL INFERENCE UNDER NOISE
-------------------------------------------
The rule is not in what you can observe.
It is in the generative process that produced what you can observe.

This chamber presents an agent with a set of variables and outcomes.
Some variables cause the outcome. Some correlate with it accidentally.
Some are red herrings with no relationship at all.
The surface rotates — variable names change, magnitudes change, domain changes.
The causal structure does not.

WHY THIS IS UNDENIABLE
-----------------------
Pattern matching fails here by design.
A system that finds correlations will latch onto the noise.
A system that reasons about structure — what generates what —
will find the causal mechanism regardless of surface.

This is the test that separates systems that learned the pattern
from systems that understood the mechanism.

STRUCTURAL PRINCIPLE
--------------------
Modelled on: causal discovery in experimental science
The same principle used to identify drug mechanisms,
isolate physical causes from confounders,
and distinguish signal from noise in biological systems.

Four causal structures:
  DIRECT_CAUSE         X directly produces Y. Z correlates but does not cause.
  MEDIATED_CAUSE       X causes Y through M. Direct XY correlation is partial.
  COMMON_CAUSE         Both X and Y result from hidden C. XY correlation is spurious.
  INTERACTIVE_CAUSE    X causes Y only when Z is also present. Neither alone suffices.

Surfaces: medical / physical / ecological / economic
"""

from __future__ import annotations
import random
import sys, os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..'))

from substrate_suite.core.substrate_contract import SubstrateBase, ChamberSpec, substrate_registry


# ─────────────────────────────────────────────────────────────────────────────
# CAUSAL STRUCTURES
# ─────────────────────────────────────────────────────────────────────────────

CAUSAL_CLASSES = {
    'direct_cause':       'X directly produces Y. Z is a correlated noise variable.',
    'mediated_cause':     'X causes Y through intermediate M. Partial direct correlation.',
    'common_cause':       'Hidden C produces both X and Y. X→Y correlation is spurious.',
    'interactive_cause':  'X causes Y only when Z is present. Neither alone causes Y.',
}

SURFACES = {
    'medical': {
        'cause_var':    ['drug dosage', 'treatment intensity', 'enzyme level', 'exposure dose'],
        'effect_var':   ['recovery rate', 'symptom reduction', 'marker decrease', 'cell viability'],
        'noise_var':    ['patient age', 'baseline score', 'body mass', 'prior episodes'],
        'mediator_var': ['immune response', 'receptor activation', 'protein expression'],
        'domain_label': 'clinical trial',
    },
    'physical': {
        'cause_var':    ['applied force', 'temperature', 'voltage', 'field strength'],
        'effect_var':   ['displacement', 'reaction rate', 'current', 'particle velocity'],
        'noise_var':    ['ambient humidity', 'surface texture', 'container shape', 'time of day'],
        'mediator_var': ['pressure', 'electron density', 'momentum', 'internal energy'],
        'domain_label': 'physical experiment',
    },
    'ecological': {
        'cause_var':    ['rainfall', 'nutrient level', 'predator density', 'temperature'],
        'effect_var':   ['plant biomass', 'population size', 'species diversity', 'growth rate'],
        'noise_var':    ['altitude', 'soil colour', 'latitude', 'plot size'],
        'mediator_var': ['soil moisture', 'prey availability', 'light penetration'],
        'domain_label': 'field study',
    },
    'economic': {
        'cause_var':    ['interest rate', 'investment level', 'workforce size', 'tariff rate'],
        'effect_var':   ['output growth', 'employment rate', 'productivity', 'export volume'],
        'noise_var':    ['season', 'index colour', 'report number', 'region code'],
        'mediator_var': ['credit availability', 'consumer confidence', 'capacity utilisation'],
        'domain_label': 'economic dataset',
    },
}

CAUSAL_CLASS_FEATURES = {
    'direct_cause':      {'causal_structure': 'direct', 'mediation': 'none',    'confounding': 'low',  'interaction': 'no'},
    'mediated_cause':    {'causal_structure': 'chain',  'mediation': 'present', 'confounding': 'low',  'interaction': 'no'},
    'common_cause':      {'causal_structure': 'fork',   'mediation': 'none',    'confounding': 'high', 'interaction': 'no'},
    'interactive_cause': {'causal_structure': 'gate',   'mediation': 'none',    'confounding': 'low',  'interaction': 'yes'},
}


@substrate_registry.register('causal_inference')
class CausalInferenceChamber(SubstrateBase):
    """
    Chamber 02: Causal Inference Under Noise.

    The agent observes a dataset summary: variable names, correlations,
    and an intervention result. It must identify which variable is the
    true cause of the observed outcome.

    The causal structure is constant within a session.
    The surface (domain, variable names, magnitudes) rotates every episode.
    """

    def __init__(self, seed: int = 42):
        self.seed   = seed
        self.rng    = random.Random(seed)
        self._episode    = 0
        self._outcomes:  list = []
        self._problem:   dict = {}
        self._class_outcomes:   dict = {}
        self._surface_outcomes: dict = {}

    @property
    def spec(self) -> ChamberSpec:
        return ChamberSpec(
            chamber_id='causal_inference',
            display_name='Causal Inference Under Noise',
            version='1.0.0',
            domain='science',
            description=(
                'The rule is generative, not correlational. '
                'Pattern matching finds spurious correlations. '
                'Structural reasoning finds the causal mechanism. '
                'Surface rotates — domain, variable names, magnitudes change. '
                'Causal structure does not.'
            ),
            structural_principle=(
                'Causal discovery under confounding. '
                'Models: experimental design, mechanism identification, '
                'signal/noise separation in biological and physical systems.'
            ),
            difficulty=4,
            problem_classes=list(CAUSAL_CLASSES.keys()),
            tags=['causal', 'noise', 'science', 'mechanism', 'confounding'],
            added='2026-02-27',
        )

    def reset(self, episode_id: int = 0) -> dict:
        self._episode = episode_id
        problem = self._generate_problem()
        self._problem = problem
        return self._make_observation(
            episode_id=episode_id,
            step=0,
            display=problem['display'],
            context=problem['features'],
            choices=problem['choices'],
            raw_input=problem,
            episodes_completed=episode_id,
            current_accuracy=self._current_accuracy(),
            convergence_signal=self._convergence_signal(),
        )

    def step(self, action: dict) -> tuple[dict, float, bool, dict]:
        if isinstance(action, dict):
            answer = str(action.get('answer', ''))
        else:
            answer = str(action)

        correct  = str(self._problem['correct_answer'])
        success  = answer.strip().lower() == correct.strip().lower()
        reward   = 1.0 if success else -0.5

        cls     = self._problem['causal_class']
        surface = self._problem['surface']

        self._outcomes.append(success)
        self._class_outcomes.setdefault(cls, []).append(success)
        self._surface_outcomes.setdefault((cls, surface), []).append(success)

        info = self._make_info(
            success=success,
            correct_answer=correct,
            problem_class=cls,
            surface=surface,
            structural_features=self._problem['features'],
        )

        # Generate next observation (episode done — one step per episode)
        next_obs = self._make_observation(
            episode_id=self._episode,
            step=1,
            display='Episode complete.',
            context={},
            choices=[],
            episodes_completed=self._episode,
            current_accuracy=self._current_accuracy(),
            convergence_signal=self._convergence_signal(),
        )

        return next_obs, reward, True, info

    def run_probes(self, episode: int) -> dict:
        n = len(self._outcomes)
        if n < 10:
            return {
                'structural_recognition_rate': 0.0,
                'surface_invariance': 0.0,
                'convergence_episode': -1,
                'probe_flags': ['insufficient_data'],
            }

        srr = sum(self._outcomes) / n
        window, conv_ep = 10, -1
        for i in range(n - window + 1):
            if sum(self._outcomes[i:i+window]) / window >= 0.75:
                conv_ep = i + 1
                break

        # Surface invariance
        class_accs: dict = {}
        for (cls, surface), results in self._surface_outcomes.items():
            class_accs.setdefault(cls, []).append(sum(results)/len(results))
        inv_scores = []
        for cls, accs in class_accs.items():
            if len(accs) > 1:
                mean = sum(accs)/len(accs)
                var  = sum((a-mean)**2 for a in accs)/len(accs)
                inv_scores.append(max(0.0, 1.0 - (var**0.5)*2))
            else:
                inv_scores.append(1.0)
        surface_inv = sum(inv_scores)/len(inv_scores) if inv_scores else 1.0

        flags = []
        if srr < 0.4:
            flags.append('below_chance_threshold — agent may be anti-correlating')

        return {
            'structural_recognition_rate': round(srr, 4),
            'surface_invariance':          round(surface_inv, 4),
            'convergence_episode':         conv_ep,
            'accuracy_by_class': {
                cls: round(sum(v)/len(v), 4)
                for cls, v in self._class_outcomes.items()
            },
            'probe_flags': flags,
        }

    def info(self) -> dict:
        return {
            'episodes_run':     self._episode,
            'current_accuracy': self._current_accuracy(),
            'class_breakdown':  {
                cls: round(sum(v)/len(v), 4)
                for cls, v in self._class_outcomes.items()
            },
        }

    # ─────────────────────────────────────────────────────────────────────────
    # PROBLEM GENERATION
    # ─────────────────────────────────────────────────────────────────────────

    def _generate_problem(self) -> dict:
        causal_class = self.rng.choice(list(CAUSAL_CLASSES.keys()))
        surface_name = self.rng.choice(list(SURFACES.keys()))
        surface      = SURFACES[surface_name]

        cause    = self.rng.choice(surface['cause_var'])
        effect   = self.rng.choice(surface['effect_var'])
        noise    = self.rng.choice(surface['noise_var'])
        mediator = self.rng.choice(surface['mediator_var'])
        domain   = surface['domain_label']

        # Generate correlation magnitudes
        true_r   = round(self.rng.uniform(0.65, 0.92), 2)
        noise_r  = round(self.rng.uniform(0.40, 0.68), 2)  # high enough to tempt
        med_r    = round(self.rng.uniform(0.55, 0.80), 2)

        # Build problem text and choices based on causal class
        if causal_class == 'direct_cause':
            display = (
                f"In a {domain}, three variables were measured:\n"
                f"  [{cause}] correlates with [{effect}]: r = {true_r}\n"
                f"  [{noise}] correlates with [{effect}]: r = {noise_r}\n"
                f"  Intervention: holding [{noise}] constant, [{cause}]→[{effect}] correlation "
                f"remained at {true_r}.\n"
                f"  Intervention: holding [{cause}] constant, [{noise}]→[{effect}] correlation "
                f"dropped to {round(noise_r*0.1, 2)}.\n\n"
                f"Which variable is the direct cause of [{effect}]?"
            )
            correct = cause
            distractors = [noise, mediator, 'neither variable']

        elif causal_class == 'mediated_cause':
            display = (
                f"In a {domain}, three variables were measured:\n"
                f"  [{cause}] correlates with [{effect}]: r = {round(true_r*0.6,2)} (partial)\n"
                f"  [{cause}] correlates with [{mediator}]: r = {true_r}\n"
                f"  [{mediator}] correlates with [{effect}]: r = {med_r}\n"
                f"  Intervention: blocking [{mediator}] reduced [{cause}]→[{effect}] to "
                f"r = {round(true_r*0.08,2)}.\n\n"
                f"Through which variable does [{cause}] produce [{effect}]?"
            )
            correct = mediator
            distractors = [cause, noise, effect]

        elif causal_class == 'common_cause':
            display = (
                f"In a {domain}, two variables appear related:\n"
                f"  [{cause}] correlates with [{effect}]: r = {noise_r}\n"
                f"  [{noise}] correlates with both [{cause}] and [{effect}]: "
                f"r = {true_r} and r = {med_r}\n"
                f"  Intervention: controlling for [{noise}], [{cause}]→[{effect}] dropped "
                f"to r = {round(noise_r*0.05,2)}.\n\n"
                f"The apparent [{cause}]→[{effect}] relationship is produced by which variable?"
            )
            correct = noise
            distractors = [cause, effect, mediator]

        else:  # interactive_cause
            display = (
                f"In a {domain}, variables were tested alone and in combination:\n"
                f"  [{cause}] alone → [{effect}]: r = {round(true_r*0.12,2)}\n"
                f"  [{noise}] alone → [{effect}]: r = {round(noise_r*0.10,2)}\n"
                f"  [{cause}] + [{noise}] together → [{effect}]: r = {true_r}\n"
                f"  Removing either eliminates the effect on [{effect}].\n\n"
                f"What type of causal relationship produces [{effect}]?"
            )
            correct = 'interactive — both required'
            distractors = [cause, noise, 'neither — no causal relationship']

        # Build choices list — correct + distractors shuffled
        choices = [correct] + [d for d in distractors if d != correct]
        choices = list(dict.fromkeys(choices))  # deduplicate
        self.rng.shuffle(choices)

        features = {
            **CAUSAL_CLASS_FEATURES[causal_class],
            'surface':       surface_name,
            'class':         causal_class,
            'n_variables':   '3',
            'domain':        surface_name,
            'intervention_available': 'yes',
        }

        return {
            'causal_class':   causal_class,
            'surface':        surface_name,
            'correct_answer': correct,
            'choices':        choices,
            'display':        display,
            'features':       features,
        }

    def _current_accuracy(self) -> float:
        if not self._outcomes:
            return 0.0
        recent = self._outcomes[-20:]
        return round(sum(recent) / len(recent), 4)

    def _convergence_signal(self) -> float:
        if len(self._outcomes) < 10:
            return 0.0
        recent = self._outcomes[-10:]
        return round(min(1.0, sum(recent) / 10 * 1.2), 4)
