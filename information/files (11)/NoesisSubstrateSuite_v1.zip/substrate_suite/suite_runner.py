"""
Noesis Substrate Suite
======================
suite_runner.py

THE RUNNER
----------
Introduces an agent into a chamber and runs it for N episodes.
Handles decontamination, metric collection, and result output.

Any agent. Any chamber. Same runner.

Usage:
    from substrate_suite.suite_runner import run
    from substrate_suite.chambers.causal_inference import CausalInferenceChamber

    report = run(my_agent, CausalInferenceChamber(seed=42), n_episodes=200)
    print(report.profile.summary())
"""

from __future__ import annotations
import time
import sys, os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from substrate_suite.core.substrate_contract import SubstrateBase, substrate_registry
from substrate_suite.core.decontamination import decontaminate, ClearanceLevel
from substrate_suite.metrics.viability_metrics import (
    ViabilityMeter, EpisodeRecord, ViabilityProfile, benchmark_registry
)
from dataclasses import dataclass, field


@dataclass
class RunReport:
    """Everything a run produces."""
    agent_name:  str
    chamber_id:  str
    n_episodes:  int
    clearance:   str
    profile:     ViabilityProfile = None
    duration_s:  float = 0.0
    probe_log:   list  = field(default_factory=list)
    error:       str   = ''

    def summary(self) -> str:
        lines = [
            f'\n{"="*62}',
            f'  RUN COMPLETE',
            f'  Agent:    {self.agent_name}',
            f'  Chamber:  {self.chamber_id}',
            f'  Episodes: {self.n_episodes}  |  Duration: {self.duration_s:.1f}s',
            f'  Clearance: {self.clearance}',
        ]
        if self.error:
            lines.append(f'  Error: {self.error}')
        if self.profile:
            lines.append(self.profile.summary())
        return '\n'.join(lines)


def run(agent,
        chamber: SubstrateBase,
        n_episodes: int = 200,
        probe_every: int = 50,
        verbose: bool = True,
        submit_to_benchmark: bool = True) -> RunReport:
    """
    Run an agent through a chamber.

    1. Decontamination
    2. Episode loop with metric collection
    3. Final probe
    4. Viability profile computation
    5. Benchmark submission (optional)

    agent:   any object implementing choose_action() and update()
    chamber: SubstrateBase instance
    """
    agent_name = _agent_name(agent)
    chamber_id = chamber.spec.chamber_id
    t_start    = time.time()

    report = RunReport(
        agent_name=agent_name,
        chamber_id=chamber_id,
        n_episodes=n_episodes,
        clearance='PENDING',
    )

    # ── DECONTAMINATION ───────────────────────────────────────────────────────
    decon = decontaminate(agent, chamber, verbose=verbose)
    report.clearance = decon.clearance.value

    if decon.clearance == ClearanceLevel.REJECTED:
        report.error = 'Agent rejected at decontamination vestibule.'
        if verbose:
            print(f'\n  ✗ Agent rejected. Cannot introduce to chamber.')
        return report

    if verbose and decon.clearance == ClearanceLevel.CONDITIONAL:
        print(f'\n  ⚠ Conditional clearance. Results will be flagged.')

    # ── EPISODE LOOP ──────────────────────────────────────────────────────────
    meter = ViabilityMeter(chamber_id=chamber_id, agent_name=agent_name)

    for ep in range(1, n_episodes + 1):
        obs = chamber.reset(episode_id=ep)

        # Multi-phase support: keep stepping until done
        done = False
        step = 0
        while not done:
            task     = obs.get('task', {})
            context  = task.get('context', {})
            choices  = task.get('choices', [])

            if not choices:
                break

            # Agent decision
            try:
                result = agent.choose_action(context, choices)
                action_str = result[0] if isinstance(result, tuple) else result
                source_str = result[1] if isinstance(result, tuple) else 'unknown'
            except Exception as e:
                action_str = choices[0]
                source_str = f'error:{e}'

            # Step
            action = {'answer': str(action_str), 'source': source_str}
            obs, reward, done, info = chamber.step(action)

            # Update agent
            success = info.get('success', False)
            try:
                agent.update(
                    condition=context,
                    action=str(action_str),
                    success=success,
                    step=ep,
                )
            except Exception:
                pass  # agent update failure doesn't kill the run

            step += 1

        # Record final episode outcome
        meter.record(EpisodeRecord(
            episode=ep,
            problem_class=info.get('class', 'unknown'),
            surface=info.get('surface', 'unknown'),
            structural_features=info.get('structural_features', context),
            chosen=str(action_str),
            correct_answer=str(info.get('correct_answer', '')),
            success=info.get('success', False),
            substrate_used=source_str,
            convergence_signal=obs.get('viability', {}).get('convergence_signal', 0.0),
        ))

        # Progress report
        if verbose and (ep % 50 == 0 or ep <= 5):
            acc = obs.get('viability', {}).get('current_accuracy', 0.0)
            class_info = info.get('class', '')
            print(f'  ep {ep:4d} | acc={acc:.0%} | class={class_info}')

        # Probes
        if ep % probe_every == 0:
            probe_result = chamber.run_probes(ep)
            probe_result['episode'] = ep
            report.probe_log.append(probe_result)

    # ── FINAL PROBE AND PROFILE ───────────────────────────────────────────────
    final_probe = chamber.run_probes(n_episodes)
    report.probe_log.append(final_probe)

    profile = meter.compute()
    report.profile = profile
    report.duration_s = round(time.time() - t_start, 2)

    if submit_to_benchmark:
        benchmark_registry.submit(profile)

    if verbose:
        print(report.summary())

    return report


def run_suite(agent,
              chamber_ids: list = None,
              n_episodes: int = 200,
              verbose: bool = True) -> dict:
    """
    Run an agent through multiple chambers.
    Returns dict of chamber_id -> RunReport.

    If chamber_ids is None, runs all registered chambers in difficulty order.
    """
    if chamber_ids is None:
        chambers_info = substrate_registry.list_chambers()
        chamber_ids = [c['chamber_id'] for c in chambers_info]

    results = {}
    for cid in chamber_ids:
        if verbose:
            print(f'\n{"="*62}')
            print(f'  INTRODUCING AGENT TO CHAMBER: {cid}')
            print(f'{"="*62}')
        try:
            chamber = substrate_registry.get(cid, seed=42)
            report  = run(agent, chamber, n_episodes=n_episodes, verbose=verbose)
            results[cid] = report
        except Exception as e:
            if verbose:
                print(f'  ✗ Failed to run chamber {cid}: {e}')
            results[cid] = RunReport(
                agent_name=_agent_name(agent),
                chamber_id=cid,
                n_episodes=0,
                clearance='ERROR',
                error=str(e),
            )

    # Compute transfer coefficients if unified chamber ran
    if 'unified' in results and len(results) > 1:
        for cid in results:
            if cid != 'unified':
                benchmark_registry.compute_transfer_coefficients(cid, 'unified')

    if verbose:
        benchmark_registry.print_leaderboard()

    return results


# ── HELPERS ───────────────────────────────────────────────────────────────────

def _agent_name(agent) -> str:
    if hasattr(agent, 'name'):
        return str(agent.name)
    return agent.__class__.__name__
