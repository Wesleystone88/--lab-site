"""
Noesis Substrate Suite
======================
decontamination.py — The Gate

PURPOSE
-------
Nothing enters a chamber without clearing decontamination.
The vestibule validates agent compatibility, certifies the interface,
and issues a clearance signature before introduction.

This is not a capability test.
An agent is not rejected because it is weak.
It is rejected because it speaks the wrong protocol.

WHAT GETS CHECKED
-----------------
1. Interface compliance   — does the agent implement required methods?
2. Signature validation   — do the method signatures accept the right arguments?
3. Smoke test             — can the agent complete one synthetic episode?
4. Chamber compatibility  — does the agent meet this chamber's specific requirements?

CLEARANCE LEVELS
----------------
CLEARED       Agent passed all checks. Introduce to chamber.
CONDITIONAL   Agent passed interface checks, failed smoke test. May attempt chamber
              but results flagged. Common for untested or partially implemented agents.
REJECTED      Agent failed interface compliance. Cannot enter. Report issued.
"""

from __future__ import annotations
import inspect
import traceback
from dataclasses import dataclass, field
from typing import Any, Optional
from enum import Enum


class ClearanceLevel(str, Enum):
    CLEARED     = 'CLEARED'
    CONDITIONAL = 'CONDITIONAL'
    REJECTED    = 'REJECTED'


@dataclass
class DecontaminationReport:
    """
    Full record of what the vestibule found.
    Issued to every agent, cleared or not.
    Rejected agents receive this with corrective guidance.
    """
    agent_name:      str
    chamber_id:      str
    clearance:       ClearanceLevel
    timestamp:       float = field(default_factory=__import__('time').time)

    # Check results
    interface_passed:   bool = False
    signature_passed:   bool = False
    smoke_test_passed:  bool = False
    chamber_compat:     bool = False

    # Detail
    failures:        list = field(default_factory=list)
    warnings:        list = field(default_factory=list)
    corrective_guidance: list = field(default_factory=list)

    # Clearance signature (only set if CLEARED or CONDITIONAL)
    signature:       str  = ''

    def passed(self) -> bool:
        return self.clearance in (ClearanceLevel.CLEARED, ClearanceLevel.CONDITIONAL)

    def summary(self) -> str:
        lines = [
            f'  ╔══ DECONTAMINATION REPORT ══════════════════════════════',
            f'  ║  Agent:    {self.agent_name}',
            f'  ║  Chamber:  {self.chamber_id}',
            f'  ║  Verdict:  {self.clearance.value}',
            f'  ╠──────────────────────────────────────────────────────────',
            f'  ║  Interface compliance:  {"✓" if self.interface_passed else "✗"}',
            f'  ║  Signature validation:  {"✓" if self.signature_passed else "✗"}',
            f'  ║  Smoke test:           {"✓" if self.smoke_test_passed else "✗ / skipped"}',
            f'  ║  Chamber compatibility: {"✓" if self.chamber_compat else "✗"}',
        ]
        if self.failures:
            lines.append(f'  ╠── FAILURES:')
            for f in self.failures:
                lines.append(f'  ║    ✗ {f}')
        if self.warnings:
            lines.append(f'  ╠── WARNINGS:')
            for w in self.warnings:
                lines.append(f'  ║    ⚠ {w}')
        if self.corrective_guidance:
            lines.append(f'  ╠── CORRECTIVE GUIDANCE:')
            for g in self.corrective_guidance:
                lines.append(f'  ║    → {g}')
        if self.signature:
            lines.append(f'  ╠──────────────────────────────────────────────────────────')
            lines.append(f'  ║  Clearance signature: {self.signature}')
        lines.append(f'  ╚══════════════════════════════════════════════════════════')
        return '\n'.join(lines)


class DecontaminationVestibule:
    """
    The gate.

    Usage:
        vestibule = DecontaminationVestibule()
        report = vestibule.process(agent, chamber)
        if report.passed():
            # introduce agent to chamber
        else:
            print(report.summary())
    """

    # Minimum interface every agent must expose
    REQUIRED_METHODS = ['choose_action', 'update']

    # Smoke test problem — synthetic, safe, minimal
    SMOKE_CONTEXT = {
        'class':   'smoke_test',
        'surface': 'synthetic',
        'trend':   'flat',
    }
    SMOKE_CHOICES = ['A', 'B', 'C', 'D']
    SMOKE_CORRECT = 'A'

    def process(self,
                agent: Any,
                chamber,
                verbose: bool = True) -> DecontaminationReport:
        """
        Run full decontamination protocol on agent for this chamber.

        agent:   any object — no assumptions about type
        chamber: SubstrateBase instance
        """
        agent_name  = _get_agent_name(agent)
        chamber_id  = chamber.spec.chamber_id
        report      = DecontaminationReport(
            agent_name=agent_name,
            chamber_id=chamber_id,
            clearance=ClearanceLevel.REJECTED,  # default; upgraded if checks pass
        )

        # ── CHECK 1: Interface compliance ────────────────────────────────
        missing = []
        for method in self.REQUIRED_METHODS:
            if not callable(getattr(agent, method, None)):
                missing.append(method)

        if missing:
            report.interface_passed = False
            for m in missing:
                report.failures.append(f"Missing required method: {m}()")
                report.corrective_guidance.append(
                    f"Implement {m}() on your agent class. "
                    f"See substrate_contract.py AGENT INTERFACE section."
                )
        else:
            report.interface_passed = True

        # ── CHECK 2: Signature validation ────────────────────────────────
        if report.interface_passed:
            sig_failures = []

            # choose_action(context:dict, choices:list) -> str
            try:
                sig = inspect.signature(agent.choose_action)
                params = list(sig.parameters.keys())
                # Accept self + 2 positional, or 2 positional (no self if bound)
                if len(params) < 2:
                    sig_failures.append(
                        "choose_action must accept at least (context, choices)"
                    )
            except Exception as e:
                sig_failures.append(f"choose_action signature error: {e}")

            # update(context, action, success, step)
            try:
                sig = inspect.signature(agent.update)
                params = list(sig.parameters.keys())
                if len(params) < 4:
                    sig_failures.append(
                        "update must accept at least (context, action, success, step)"
                    )
            except Exception as e:
                sig_failures.append(f"update signature error: {e}")

            if sig_failures:
                report.signature_passed = False
                report.failures.extend(sig_failures)
            else:
                report.signature_passed = True
        else:
            report.signature_passed = False

        # ── CHECK 3: Smoke test ──────────────────────────────────────────
        if report.interface_passed and report.signature_passed:
            try:
                # Agent picks from synthetic choices
                result = agent.choose_action(
                    self.SMOKE_CONTEXT,
                    self.SMOKE_CHOICES,
                )
                # Result can be tuple (action, source) or just str
                action = result[0] if isinstance(result, tuple) else result

                if str(action) not in [str(c) for c in self.SMOKE_CHOICES]:
                    report.warnings.append(
                        f"Smoke test: agent returned '{action}' which is not in "
                        f"choices {self.SMOKE_CHOICES}. Agent may not respect choice constraints."
                    )

                # Update call
                agent.update(
                    condition=self.SMOKE_CONTEXT,
                    action=str(action),
                    success=(str(action) == self.SMOKE_CORRECT),
                    step=0,
                )
                report.smoke_test_passed = True

            except Exception as e:
                report.smoke_test_passed = False
                report.warnings.append(
                    f"Smoke test raised exception: {type(e).__name__}: {e}. "
                    f"Agent may still function in chamber — clearance set to CONDITIONAL."
                )
                report.corrective_guidance.append(
                    "Review choose_action() and update() for exceptions with minimal inputs."
                )
        else:
            report.smoke_test_passed = False  # Skipped — can't reach this

        # ── CHECK 4: Chamber-specific compatibility ───────────────────────
        chamber_reqs = chamber.spec.agent_interface_requirements
        missing_chamber = []
        for req in chamber_reqs:
            if req not in self.REQUIRED_METHODS:
                # Additional requirement beyond the base
                if not callable(getattr(agent, req, None)):
                    missing_chamber.append(req)

        if missing_chamber:
            report.chamber_compat = False
            for m in missing_chamber:
                report.failures.append(
                    f"Chamber '{chamber_id}' requires additional method: {m}()"
                )
        else:
            report.chamber_compat = True

        # ── VERDICT ──────────────────────────────────────────────────────
        if report.interface_passed and report.signature_passed and report.chamber_compat:
            if report.smoke_test_passed:
                report.clearance = ClearanceLevel.CLEARED
            else:
                report.clearance = ClearanceLevel.CONDITIONAL
            report.signature = _generate_signature(agent_name, chamber_id)
        else:
            report.clearance = ClearanceLevel.REJECTED

        if verbose:
            print(report.summary())

        return report


# ─────────────────────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _get_agent_name(agent: Any) -> str:
    if hasattr(agent, 'name'):
        return str(agent.name)
    if hasattr(agent, '__class__'):
        return agent.__class__.__name__
    return str(type(agent))


def _generate_signature(agent_name: str, chamber_id: str) -> str:
    import hashlib, time
    raw = f"{agent_name}:{chamber_id}:{time.time()}"
    return 'NSS-' + hashlib.sha256(raw.encode()).hexdigest()[:16].upper()


# ─────────────────────────────────────────────────────────────────────────────
# CONVENIENCE FUNCTION
# ─────────────────────────────────────────────────────────────────────────────

def decontaminate(agent: Any,
                  chamber,
                  verbose: bool = True) -> DecontaminationReport:
    """
    Shorthand. Most callers only need this.

    report = decontaminate(my_agent, my_chamber)
    if report.passed():
        run_in_chamber(my_agent, my_chamber)
    """
    return DecontaminationVestibule().process(agent, chamber, verbose=verbose)
