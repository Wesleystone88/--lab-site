"""
Noesis Substrate Suite
======================
substrate_contract.py

THE CONTRACT
------------
Every chamber in the Noesis Substrate Suite implements SubstrateBase.
That is the only requirement. Any agent that clears decontamination
can be introduced into any chamber that exists or will ever exist.

The chamber does not know what the agent is built on.
The agent does not know what the chamber is made of.
The contract connects them.

ADDING A NEW CHAMBER
--------------------
1. Create chambers/your_chamber.py
2. Subclass SubstrateBase
3. Implement five methods: reset, step, run_probes, info, spec (property)
4. Decorate: @substrate_registry.register('your_chamber_id')
5. Done. Decontamination, metrics, registry — all automatic.

OBSERVATION SCHEMA (what reset() and step() must return)
---------------------------------------------------------
{
    'episode_id':   int,
    'step':         int,
    'chamber_id':   str,          # which chamber this is
    'task': {
        'display':  str,          # human-readable problem statement
        'context':  dict,         # structural features (agent reads these)
        'choices':  list[str],    # valid actions the agent may submit
        'input':    Any,          # raw problem data (agent may ignore)
    },
    'viability': {
        'episodes_completed': int,
        'current_accuracy':   float,
        'convergence_signal': float,  # 0.0-1.0, rises as agent stabilises
    }
}

ACTION SCHEMA (what step() receives)
--------------------------------------
{
    'answer':   str,    # must be one of task.choices
    'source':   str,    # optional: what drove the decision (for attribution)
}

INFO SCHEMA (what step() returns in info dict)
----------------------------------------------
{
    'success':         bool,
    'correct_answer':  str,
    'class':           str,    # problem class within this chamber
    'surface':         str,    # surface presentation variant
    'structural_features': dict,  # same as task.context — redundant for convenience
}
"""

from __future__ import annotations
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Optional
import time


# ─────────────────────────────────────────────────────────────────────────────
# CHAMBER SPEC — what every chamber declares about itself
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ChamberSpec:
    """
    The identity card every chamber carries.

    Required fields tell the suite what this chamber is.
    Optional fields describe what an agent needs to survive it.
    The gate reads agent_interface_requirements during decontamination.
    """
    # Identity
    chamber_id:      str                        # unique slug: 'iq_legacy', 'causal_inference'
    display_name:    str                        # 'Causal Inference Under Noise'
    version:         str        = '1.0.0'
    domain:          str        = 'general'     # physics / biology / mathematics / unified

    # Description
    description:     str        = ''
    structural_principle: str   = ''           # the real-world principle this models

    # Difficulty
    difficulty:      int        = 3            # 1 (accessible) to 5 (extreme)
    problem_classes: list       = field(default_factory=list)  # what this chamber tests

    # Gate requirements — what an agent must support to enter
    agent_interface_requirements: list = field(default_factory=lambda: [
        'choose_action',   # callable(context:dict, choices:list) -> str
        'update',          # callable(context:dict, action:str, success:bool, step:int)
    ])

    # Metadata
    tags:            list       = field(default_factory=list)
    added:           str        = ''           # date added to suite


# ─────────────────────────────────────────────────────────────────────────────
# SUBSTRATE BASE — the contract every chamber signs
# ─────────────────────────────────────────────────────────────────────────────

class SubstrateBase(ABC):
    """
    The entire interface.

    Five methods. Four abstract (must implement). One optional.
    Everything else — decontamination, metrics, registry — is automatic.

    Design principle:
        The chamber is a pressure environment.
        It does not scaffold. It does not teach.
        It presents structure and measures what survives.
    """

    # ── Required: identity ───────────────────────────────────────────────────

    @property
    @abstractmethod
    def spec(self) -> ChamberSpec:
        """Return this chamber's identity card. Called once at registration."""
        ...

    # ── Required: episode lifecycle ──────────────────────────────────────────

    @abstractmethod
    def reset(self, episode_id: int = 0) -> dict:
        """
        Begin a new episode. Return initial observation.
        Observation must conform to OBSERVATION SCHEMA above.
        """
        ...

    @abstractmethod
    def step(self, action: dict) -> tuple[dict, float, bool, dict]:
        """
        Agent submits an action. Chamber responds.

        action: dict with at minimum {'answer': str}
        Returns: (observation, reward, done, info)
            observation : next state (same schema as reset())
            reward      : float — positive for correct, negative for wrong
            done        : True when episode ends
            info        : dict conforming to INFO SCHEMA above
        """
        ...

    # ── Required: diagnostics ────────────────────────────────────────────────

    @abstractmethod
    def run_probes(self, episode: int) -> dict:
        """
        Diagnostic suite. Called at scheduled intervals by the runner.

        Must return at minimum:
        {
            'structural_recognition_rate': float,  # did it detect the right class?
            'surface_invariance':          float,  # performance stable across surfaces?
            'convergence_episode':         int,    # first episode with stable accuracy
            'probe_flags':                 list,   # warning strings if any
        }
        """
        ...

    # ── Optional: runtime state ──────────────────────────────────────────────

    def info(self) -> dict:
        """Runtime chamber state. Optional. Useful for dashboards and debugging."""
        return {}

    # ── Helpers available to all chambers ────────────────────────────────────

    def _make_observation(self,
                          episode_id: int,
                          step: int,
                          display: str,
                          context: dict,
                          choices: list,
                          raw_input: Any = None,
                          episodes_completed: int = 0,
                          current_accuracy: float = 0.0,
                          convergence_signal: float = 0.0) -> dict:
        """
        Helper: build a conformant observation dict.
        Chambers should use this to guarantee schema compliance.
        """
        return {
            'episode_id':  episode_id,
            'step':        step,
            'chamber_id':  self.spec.chamber_id,
            'task': {
                'display':  display,
                'context':  context,
                'choices':  [str(c) for c in choices],
                'input':    raw_input,
            },
            'viability': {
                'episodes_completed': episodes_completed,
                'current_accuracy':   current_accuracy,
                'convergence_signal': convergence_signal,
            },
        }

    def _make_info(self,
                   success: bool,
                   correct_answer: str,
                   problem_class: str = '',
                   surface: str = '',
                   structural_features: dict = None) -> dict:
        """
        Helper: build a conformant info dict.
        """
        return {
            'success':              success,
            'correct_answer':       str(correct_answer),
            'class':                problem_class,
            'surface':              surface,
            'structural_features':  structural_features or {},
        }


# ─────────────────────────────────────────────────────────────────────────────
# CHAMBER REGISTRY — the living catalogue of all chambers
# ─────────────────────────────────────────────────────────────────────────────

class SubstrateRegistry:
    """
    Global registry. Every chamber registers itself here.

    Usage:
        @substrate_registry.register('my_chamber')
        class MyChamber(SubstrateBase):
            ...

    Or manually:
        substrate_registry.add(MyChamber, 'my_chamber')
    """

    def __init__(self):
        self._chambers: dict[str, type] = {}
        self._specs:    dict[str, ChamberSpec] = {}

    def register(self, chamber_id: str):
        """Decorator. @substrate_registry.register('chamber_id')"""
        def decorator(cls):
            self.add(cls, chamber_id)
            return cls
        return decorator

    def add(self, cls: type, chamber_id: str):
        """Manually register a chamber class."""
        self._chambers[chamber_id] = cls
        # Instantiate briefly to read the spec
        try:
            instance = cls(seed=0)
            self._specs[chamber_id] = instance.spec
        except Exception:
            pass  # spec read happens lazily if instantiation fails

    def get(self, chamber_id: str, seed: int = 42) -> SubstrateBase:
        """Instantiate and return a chamber by ID."""
        if chamber_id not in self._chambers:
            raise KeyError(
                f"Chamber '{chamber_id}' not registered. "
                f"Available: {sorted(self._chambers.keys())}"
            )
        return self._chambers[chamber_id](seed=seed)

    def list_chambers(self) -> list[dict]:
        """All registered chambers with their specs."""
        result = []
        for cid, cls in self._chambers.items():
            spec = self._specs.get(cid)
            result.append({
                'chamber_id':   cid,
                'display_name': spec.display_name if spec else cid,
                'domain':       spec.domain if spec else '',
                'difficulty':   spec.difficulty if spec else 0,
                'version':      spec.version if spec else '?',
                'tags':         spec.tags if spec else [],
            })
        return sorted(result, key=lambda x: x['difficulty'])

    def __contains__(self, chamber_id: str) -> bool:
        return chamber_id in self._chambers

    def __len__(self) -> int:
        return len(self._chambers)


# ─────────────────────────────────────────────────────────────────────────────
# GLOBAL REGISTRY INSTANCE
# ─────────────────────────────────────────────────────────────────────────────

substrate_registry = SubstrateRegistry()
