"""
Noesis Substrate Suite
======================
viability_metrics.py — The Measurement Layer

VIABILITY INDICES
-----------------
An agent's performance in a chamber is not a single number.
It is a profile. Each index measures a different dimension of survival.

Structural Recognition Rate   How often the agent identified the correct problem class.
                              Proxy for: does it understand what it's looking at?

Convergence Episode           First episode where rolling accuracy exceeded threshold
                              and stayed there. Proxy for: how long to find footing?

Adaptation Velocity           Accuracy improvement per 10 episodes in the first 50.
                              Proxy for: how fast does it learn the chamber's physics?

Surface Invariance Index      Accuracy stability across surface rotations of the same rule.
                              Proxy for: is it learning structure or memorising surface?

Resilience Index              Accuracy on problem instances that were maximally different
                              from prior seen instances. Proxy for: can it generalise?

Transfer Coefficient          Correlation between performance in this chamber and
                              performance in the unified chamber. Computed post-hoc.
                              Proxy for: does it learn something that transfers?

Composite Viability Score     Weighted combination of all indices. Single number
                              for ranking and comparison. Weights reflect what matters.

BENCHMARK CATEGORIES
--------------------
EXEMPLARY     CVS >= 0.90   Structural reasoning demonstrated. Transfers.
VIABLE        CVS >= 0.75   Solid performance. May struggle on unified.
MARGINAL      CVS >= 0.55   Survives some chamber classes. Specialist behaviour.
INSUFFICIENT  CVS <  0.55   Not yet viable in this substrate.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Optional
import math


# ─────────────────────────────────────────────────────────────────────────────
# EPISODE RECORD — one row of raw data
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class EpisodeRecord:
    episode:            int
    problem_class:      str
    surface:            str
    structural_features: dict
    chosen:             str
    correct_answer:     str
    success:            bool
    substrate_used:     str = ''     # which substrate/pillar drove the decision
    convergence_signal: float = 0.0


# ─────────────────────────────────────────────────────────────────────────────
# VIABILITY PROFILE — the full measurement output
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class ViabilityProfile:
    """Complete viability assessment for one agent-chamber run."""

    chamber_id:          str
    agent_name:          str
    n_episodes:          int

    # ── Primary indices ───────────────────────────────────────────────────────
    structural_recognition_rate: float = 0.0   # 0.0 – 1.0
    convergence_episode:         int   = -1    # -1 = never converged
    adaptation_velocity:         float = 0.0   # accuracy gain per 10 ep in first 50
    surface_invariance_index:    float = 0.0   # 0.0 – 1.0
    resilience_index:            float = 0.0   # 0.0 – 1.0

    # ── Post-hoc (set externally after cross-chamber comparison) ─────────────
    transfer_coefficient:        float = 0.0   # correlation with unified chamber

    # ── Composite ────────────────────────────────────────────────────────────
    composite_viability_score:   float = 0.0   # 0.0 – 1.0

    # ── Per-class breakdown ───────────────────────────────────────────────────
    accuracy_by_class:           dict  = field(default_factory=dict)
    accuracy_curve:              list  = field(default_factory=list)  # rolling 10-ep

    # ── Benchmark category ────────────────────────────────────────────────────
    benchmark_category:          str   = ''

    def __post_init__(self):
        if not self.benchmark_category:
            self.benchmark_category = _categorise(self.composite_viability_score)

    def summary(self) -> str:
        conv = f'ep {self.convergence_episode}' if self.convergence_episode > 0 else 'never'
        lines = [
            f'  ╔══ VIABILITY PROFILE ════════════════════════════════════',
            f'  ║  Agent:    {self.agent_name}',
            f'  ║  Chamber:  {self.chamber_id}  ({self.n_episodes} episodes)',
            f'  ╠──────────────────────────────────────────────────────────',
            f'  ║  Structural Recognition Rate : {self.structural_recognition_rate:.1%}',
            f'  ║  Convergence Episode         : {conv}',
            f'  ║  Adaptation Velocity         : {self.adaptation_velocity:+.3f} / 10ep',
            f'  ║  Surface Invariance Index    : {self.surface_invariance_index:.1%}',
            f'  ║  Resilience Index            : {self.resilience_index:.1%}',
            f'  ║  Transfer Coefficient        : {self.transfer_coefficient:.3f}',
            f'  ╠──────────────────────────────────────────────────────────',
            f'  ║  Composite Viability Score   : {self.composite_viability_score:.3f}',
            f'  ║  Benchmark Category          : {self.benchmark_category}',
        ]
        if self.accuracy_by_class:
            lines.append(f'  ╠── Accuracy by class:')
            for cls, acc in sorted(self.accuracy_by_class.items()):
                bar = '█' * int(acc * 16) + '░' * (16 - int(acc * 16))
                lines.append(f'  ║    {cls:<28} {acc:.1%}  [{bar}]')
        lines.append(f'  ╚══════════════════════════════════════════════════════════')
        return '\n'.join(lines)


# ─────────────────────────────────────────────────────────────────────────────
# VIABILITY METER — computes all indices from episode records
# ─────────────────────────────────────────────────────────────────────────────

class ViabilityMeter:
    """
    Feed it episode records as they happen.
    Ask for a ViabilityProfile when the run ends.

    Usage:
        meter = ViabilityMeter(chamber_id='iq_legacy', agent_name='SextBioRAG')
        for ep in run:
            meter.record(EpisodeRecord(...))
        profile = meter.compute()
        print(profile.summary())
    """

    # Index weights for composite score
    WEIGHTS = {
        'structural_recognition':  0.25,
        'convergence':             0.20,
        'adaptation':              0.15,
        'surface_invariance':      0.20,
        'resilience':              0.20,
    }

    # Convergence = rolling accuracy above this for 10 consecutive episodes
    CONVERGENCE_THRESHOLD = 0.80
    CONVERGENCE_WINDOW    = 10

    def __init__(self, chamber_id: str, agent_name: str):
        self.chamber_id = chamber_id
        self.agent_name = agent_name
        self.records: list[EpisodeRecord] = []

    def record(self, rec: EpisodeRecord):
        self.records.append(rec)

    def compute(self) -> ViabilityProfile:
        if not self.records:
            return ViabilityProfile(
                chamber_id=self.chamber_id,
                agent_name=self.agent_name,
                n_episodes=0,
            )

        n = len(self.records)

        # ── Structural Recognition Rate ───────────────────────────────────
        # Proxy: overall accuracy (the system only gets the problem class right
        # if it reasons about structure, not surface)
        srr = sum(r.success for r in self.records) / n

        # ── Accuracy by class ─────────────────────────────────────────────
        by_class: dict[str, list] = {}
        for r in self.records:
            by_class.setdefault(r.problem_class, []).append(r.success)
        accuracy_by_class = {
            cls: sum(v) / len(v)
            for cls, v in by_class.items()
        }

        # ── Convergence Episode ───────────────────────────────────────────
        convergence_ep = _find_convergence(
            [r.success for r in self.records],
            threshold=self.CONVERGENCE_THRESHOLD,
            window=self.CONVERGENCE_WINDOW,
        )

        # ── Adaptation Velocity ───────────────────────────────────────────
        # Accuracy gain per 10 episodes in first 50 (or all if < 50)
        first_half = [r.success for r in self.records[:min(50, n)]]
        adaptation = _compute_slope(first_half, bucket_size=10)

        # ── Surface Invariance Index ──────────────────────────────────────
        # Per class: std of accuracy across surfaces. Low std = high invariance.
        # Average across classes.
        sii = _surface_invariance(self.records)

        # ── Resilience Index ──────────────────────────────────────────────
        # Accuracy in the second half of training (agent has seen the class
        # but gets novel surface instances). Proxy for generalisation.
        if n >= 20:
            second_half = [r.success for r in self.records[n//2:]]
            ri = sum(second_half) / len(second_half) if second_half else 0.0
        else:
            ri = srr  # not enough data to differentiate

        # ── Rolling accuracy curve ────────────────────────────────────────
        outcomes = [r.success for r in self.records]
        curve = _rolling_accuracy(outcomes, window=10)

        # ── Composite Viability Score ─────────────────────────────────────
        conv_score = _convergence_to_score(convergence_ep, n)
        adapt_score = min(1.0, max(0.0, adaptation * 10 + 0.5))  # normalise slope

        cvs = (
            self.WEIGHTS['structural_recognition'] * srr     +
            self.WEIGHTS['convergence']            * conv_score +
            self.WEIGHTS['adaptation']             * adapt_score +
            self.WEIGHTS['surface_invariance']     * sii     +
            self.WEIGHTS['resilience']             * ri
        )
        cvs = round(min(1.0, max(0.0, cvs)), 4)

        return ViabilityProfile(
            chamber_id=self.chamber_id,
            agent_name=self.agent_name,
            n_episodes=n,
            structural_recognition_rate=round(srr, 4),
            convergence_episode=convergence_ep,
            adaptation_velocity=round(adaptation, 4),
            surface_invariance_index=round(sii, 4),
            resilience_index=round(ri, 4),
            composite_viability_score=cvs,
            accuracy_by_class={k: round(v, 4) for k, v in accuracy_by_class.items()},
            accuracy_curve=curve,
        )


# ─────────────────────────────────────────────────────────────────────────────
# BENCHMARK REGISTRY — cross-agent, cross-chamber comparison
# ─────────────────────────────────────────────────────────────────────────────

class BenchmarkRegistry:
    """
    Collects ViabilityProfiles across runs.
    Computes transfer coefficients and leaderboard rankings.
    """

    def __init__(self):
        self._profiles: list[ViabilityProfile] = []

    def submit(self, profile: ViabilityProfile):
        self._profiles.append(profile)

    def leaderboard(self, chamber_id: str = None) -> list[dict]:
        """Ranked list of agents by composite viability score."""
        profiles = self._profiles
        if chamber_id:
            profiles = [p for p in profiles if p.chamber_id == chamber_id]
        ranked = sorted(profiles, key=lambda p: p.composite_viability_score, reverse=True)
        return [
            {
                'rank':      i + 1,
                'agent':     p.agent_name,
                'chamber':   p.chamber_id,
                'cvs':       p.composite_viability_score,
                'category':  p.benchmark_category,
                'srr':       p.structural_recognition_rate,
                'converged': p.convergence_episode,
            }
            for i, p in enumerate(ranked)
        ]

    def compute_transfer_coefficients(self,
                                      source_chamber: str,
                                      target_chamber: str):
        """
        For agents that ran in both chambers, compute correlation
        between source CVS and target CVS. Updates transfer_coefficient.
        """
        source = {p.agent_name: p for p in self._profiles
                  if p.chamber_id == source_chamber}
        target = {p.agent_name: p for p in self._profiles
                  if p.chamber_id == target_chamber}
        shared = set(source) & set(target)
        if len(shared) < 2:
            return 0.0

        src_scores = [source[a].composite_viability_score for a in shared]
        tgt_scores = [target[a].composite_viability_score for a in shared]
        coeff = _pearson(src_scores, tgt_scores)

        # Update profiles
        for p in self._profiles:
            if p.chamber_id == source_chamber and p.agent_name in shared:
                p.transfer_coefficient = round(coeff, 4)
        return coeff

    def print_leaderboard(self, chamber_id: str = None):
        board = self.leaderboard(chamber_id)
        title = chamber_id or 'ALL CHAMBERS'
        print(f'\n  ╔══ LEADERBOARD — {title} ════════════════════════')
        print(f'  ║  {"#":<4} {"Agent":<24} {"Chamber":<20} {"CVS":>6}  Category')
        print(f'  ╠──────────────────────────────────────────────────────────')
        for row in board:
            print(f'  ║  {row["rank"]:<4} {row["agent"]:<24} '
                  f'{row["chamber"]:<20} {row["cvs"]:>5.3f}  {row["category"]}')
        print(f'  ╚══════════════════════════════════════════════════════════')


# Global benchmark registry
benchmark_registry = BenchmarkRegistry()


# ─────────────────────────────────────────────────────────────────────────────
# INTERNAL HELPERS
# ─────────────────────────────────────────────────────────────────────────────

def _find_convergence(outcomes: list, threshold: float, window: int) -> int:
    """First episode where rolling accuracy >= threshold and stays there."""
    if len(outcomes) < window:
        return -1
    for i in range(len(outcomes) - window + 1):
        if sum(outcomes[i:i+window]) / window >= threshold:
            return i + 1
    return -1


def _compute_slope(outcomes: list, bucket_size: int) -> float:
    """Average accuracy improvement per bucket."""
    if len(outcomes) < bucket_size * 2:
        return 0.0
    buckets = []
    for i in range(0, len(outcomes), bucket_size):
        bucket = outcomes[i:i+bucket_size]
        if bucket:
            buckets.append(sum(bucket) / len(bucket))
    if len(buckets) < 2:
        return 0.0
    slopes = [buckets[i+1] - buckets[i] for i in range(len(buckets)-1)]
    return sum(slopes) / len(slopes)


def _surface_invariance(records: list) -> float:
    """
    For each problem class, compute accuracy across different surfaces.
    High invariance = same accuracy regardless of surface.
    Returns mean invariance across classes.
    """
    # Group by (class, surface)
    by_class_surface: dict = {}
    for r in records:
        key = r.problem_class
        by_class_surface.setdefault(key, {})
        by_class_surface[key].setdefault(r.surface, [])
        by_class_surface[key][r.surface].append(r.success)

    invariances = []
    for cls, surfaces in by_class_surface.items():
        if len(surfaces) < 2:
            invariances.append(1.0)  # only one surface — trivially invariant
            continue
        accs = [sum(v)/len(v) for v in surfaces.values()]
        mean_acc = sum(accs) / len(accs)
        variance = sum((a - mean_acc)**2 for a in accs) / len(accs)
        std = math.sqrt(variance)
        # Invariance = 1 - normalised std. Perfect invariance = 1.0
        invariances.append(max(0.0, 1.0 - std * 2))

    return sum(invariances) / len(invariances) if invariances else 0.0


def _rolling_accuracy(outcomes: list, window: int) -> list:
    curve = []
    for i in range(len(outcomes)):
        start = max(0, i - window + 1)
        window_outcomes = outcomes[start:i+1]
        curve.append(sum(window_outcomes) / len(window_outcomes))
    return [round(v, 4) for v in curve]


def _convergence_to_score(conv_ep: int, n_episodes: int) -> float:
    """Convert convergence episode to a 0-1 score. Earlier = better."""
    if conv_ep < 0:
        return 0.0  # never converged
    if n_episodes == 0:
        return 0.0
    # Score: 1.0 if converged at ep 1, 0.0 if converged at last episode
    return max(0.0, 1.0 - (conv_ep / n_episodes))


def _pearson(x: list, y: list) -> float:
    """Pearson correlation coefficient."""
    n = len(x)
    if n < 2:
        return 0.0
    mx, my = sum(x)/n, sum(y)/n
    num = sum((xi-mx)*(yi-my) for xi,yi in zip(x,y))
    dx  = math.sqrt(sum((xi-mx)**2 for xi in x))
    dy  = math.sqrt(sum((yi-my)**2 for yi in y))
    if dx == 0 or dy == 0:
        return 0.0
    return num / (dx * dy)


def _categorise(cvs: float) -> str:
    if cvs >= 0.90: return 'EXEMPLARY'
    if cvs >= 0.75: return 'VIABLE'
    if cvs >= 0.55: return 'MARGINAL'
    return 'INSUFFICIENT'
