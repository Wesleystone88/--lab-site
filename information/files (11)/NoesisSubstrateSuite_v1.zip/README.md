# Noesis Substrate Suite

Standalone, agent-agnostic reasoning environment suite.

## What it is

A collection of substrate chambers — each modeling a different class of 
structural reasoning — with a decontamination vestibule that validates 
agent compatibility before introduction.

Any agent that implements the two-method interface can be introduced 
into any chamber. The chamber doesn't know what the agent is built on. 
The agent doesn't know what the chamber is made of. The contract connects them.

## Chambers

| ID | Name | Difficulty | Domain |
|----|------|-----------|--------|
| `iq_legacy` | IQ Pattern Legacy | ★★★ | Mathematics |
| `causal_inference` | Causal Inference Under Noise | ★★★★ | Science |
| `unified` | Unified Substrate | ★★★★★ | All combined |

## Adding a chamber (5 steps)

```python
# 1. Create chambers/my_chamber.py
# 2. Import the base
from substrate_suite.core.substrate_contract import SubstrateBase, ChamberSpec, substrate_registry

# 3. Register with decorator
@substrate_registry.register('my_chamber')
class MyChamber(SubstrateBase):

    # 4. Declare spec
    @property
    def spec(self) -> ChamberSpec:
        return ChamberSpec(
            chamber_id='my_chamber',
            display_name='My Chamber',
            difficulty=3,
            domain='physics',
        )

    # 5. Implement three methods
    def reset(self, episode_id=0): ...
    def step(self, action): ...
    def run_probes(self, episode): ...
```

## Agent interface (minimum required)

```python
class MyAgent:
    def choose_action(self, context: dict, choices: list) -> tuple[str, str]:
        # Returns (answer, source)
        ...

    def update(self, condition: dict, action: str, success: bool, step: int):
        ...
```

## Quick start

```python
from substrate_suite import run, run_suite, substrate_registry
from substrate_suite.chambers.causal_inference import CausalInferenceChamber

report = run(my_agent, CausalInferenceChamber(), n_episodes=200)
print(report.profile.summary())

# All chambers
results = run_suite(my_agent)
```

## Viability Indices

- **Structural Recognition Rate** — overall accuracy (proxy: does it understand structure?)
- **Convergence Episode** — when did stable performance begin?
- **Adaptation Velocity** — accuracy gain per 10 episodes in first 50
- **Surface Invariance Index** — performance stable across surface rotations?
- **Resilience Index** — accuracy on novel instances (second half of training)
- **Transfer Coefficient** — correlation with unified chamber (computed post-hoc)
- **Composite Viability Score** — weighted combination, 0.0–1.0

## Benchmark categories

| Score | Category |
|-------|----------|
| ≥ 0.90 | EXEMPLARY |
| ≥ 0.75 | VIABLE |
| ≥ 0.55 | MARGINAL |
| < 0.55 | INSUFFICIENT |
