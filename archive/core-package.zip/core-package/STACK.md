# νόησις — Technology Stack & Architecture

This document describes the backend, frontend, and server infrastructure used in the **retired** νόησις application. Use it as a reference when rebuilding or migrating the codebase.

---

## Overview

The retired site was a **static/hybrid deployment** with:
- **Frontend**: React 19 + Vite + TypeScript (SPA)
- **Chat Backend**: Google Generative AI API (SDK: `@google/genai@^1.38.0`)
- **Hosting**: Netlify (static hosting with SPA routing)
- **Package Manager**: npm
- **Module System**: ES modules with import maps (esm.sh CDN)

There was **no traditional backend server** — it was a client-side React app calling the Google GenAI API directly.

---

## Frontend

### Technology

- **Framework**: React 19.2.3
- **Build Tool**: Vite 6.4.1
- **Language**: TypeScript ~5.8
- **Styling**: Tailwind CSS (via CDN), custom CSS
- **Math Rendering**: KaTeX (for rendered equations)
- **Markdown Rendering**: react-markdown + remark-math + rehype-katex

### Key Dependencies

```json
{
  "dependencies": {
    "react": "^19.2.3",
    "react-dom": "^19.2.3",
    "@google/genai": "^1.38.0",
    "lucide-react": "^0.563.0",
    "react-markdown": "^9.0.1",
    "remark-math": "^6.0.0",
    "rehype-katex": "^7.0.0"
  },
  "devDependencies": {
    "@types/node": "^22.14.0",
    "@vitejs/plugin-react": "^5.0.0",
    "typescript": "~5.8.2",
    "vite": "^6.2.0"
  }
}
```

### Build & Dev

```bash
npm install
npm run dev        # Vite dev server (typically localhost:3000 or 5173)
npm run build      # Vite production build → dist/
npm run preview    # Preview built site locally
```

### Module Loading

The frontend used **import maps** to load dependencies from **esm.sh CDN**:

```html
<script type="importmap">
{
  "imports": {
    "react": "https://esm.sh/react@^19.2.3",
    "react-dom/": "https://esm.sh/react-dom@^19.2.3/",
    "@google/genai": "https://esm.sh/@google/genai@^1.38.0",
    "lucide-react": "https://esm.sh/lucide-react@^0.563.0",
    ...
  }
}
</script>
```

This avoided the need for a bundler in production and kept the built output very small. **If rebuilding**, consider:
1. **Keep import maps** for lightweight CDN-based delivery, or
2. **Switch to traditional npm bundling** (Vite/Webpack/esbuild) for offline capability.

---

## Backend (LLM Integration)

### Architecture

**No traditional backend server.** The frontend called the Google Generative AI API directly:

```typescript
// services/geminiService.ts (simplified)
import { GoogleGenerativeAI } from "@google/genai";

const genAI = new GoogleGenerativeAI(process.env.VITE_GOOGLE_API_KEY);

async function sendMessageToGemini(messages) {
  const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
  const result = await model.generateContent({
    contents: messages,
    systemInstruction: "..."
  });
  return result.response.text();
}
```

### LLM Configuration

- **Provider**: Google Generative AI
- **Model**: `gemini-2.0-flash` (or whatever version was configured)
- **API Key**: Stored in environment variable `VITE_GOOGLE_API_KEY`
- **Features Used**:
  - Streaming support (if enabled)
  - System instructions for prompt engineering
  - Multi-turn conversation history
  - Token counting (optional)

### If You Need a Traditional Backend

If rebuilding with a backend server:

1. **Option A: Node.js/Express + Gemini SDK**
   ```javascript
   const { GoogleGenerativeAI } = require("@google/generative-ai");
   app.post("/api/chat", async (req, res) => {
     const genAI = new GoogleGenerativeAI(process.env.GOOGLE_API_KEY);
     const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
     const result = await model.generateContent(req.body.messages);
     res.json({ text: result.response.text() });
   });
   ```

2. **Option B: Python/FastAPI + Google AI SDK**
   ```python
   import google.generativeai as genai
   
   @app.post("/chat")
   async def chat(request: ChatRequest):
       genai.configure(api_key=os.environ["GOOGLE_API_KEY"])
       model = genai.GenerativeModel("gemini-2.0-flash")
       response = model.generate_content(request.messages)
       return {"text": response.text}
   ```

3. **Option C: Go/Gin + Vertex AI**
   ```go
   client, err := aiplatform.NewPredictionClient(ctx)
   response, err := client.Predict(ctx, predictRequest)
   ```

---

## Server & Deployment

### Hosting

- **Platform**: Netlify (static site hosting)
- **Domain**: [configured in Netlify dashboard]
- **Build Process**: None (Vite build runs locally; dist/ committed or uploaded)

### Netlify Configuration (`netlify.toml`)

```toml
[build]
  publish = "."
  command = ""  # No build command — assume local build

[[redirects]]
  from = "/chat/*"
  to = "/chat/index.html"
  status = 200

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200

[[headers]]
  for = "/*"
    [headers.values]
    X-Frame-Options = "DENY"
    X-XSS-Protection = "1; mode=block"
    X-Content-Type-Options = "nosniff"
    Referrer-Policy = "strict-origin-when-cross-origin"
```

**Key Points:**
- SPA routing: all routes redirect to `index.html`
- No backend execution (static files only)
- Security headers enabled

### Environment Variables

The frontend required:

```
VITE_GOOGLE_API_KEY=your-google-api-key
```

This was exposed to the browser (hence `VITE_` prefix). **For production, consider:**
- Storing the API key in a backend server and proxying requests.
- Using OAuth if rebuilding with user authentication.

---

## Deployment to Netlify

### Old Workflow

1. `npm run build` → `dist/`
2. Commit & push to Git
3. Netlify detects push, serves `dist/` at configured domain

### Alternative: Deploy Directory

```bash
netlify deploy --prod --dir=dist
```

---

## Cards & Documentation System

The site also hosted a **νόησις card system** (Markdown-based deck for conversation structuring):

- **Cards**: Located in `legacy/decks/` (exploration, emergence, canonical modes)
- **Seed System**: Cryptographic hashing for tamper-evident identity
- **Graph Tools**: Python scripts for relationship visualization

If rebuilding the site, you can:
- **Keep the card content** and re-host it (e.g., as a GitHub Wiki or documentation site).
- **Build a custom card viewer** in React that pulls from a Markdown API.
- **Skip cards entirely** if not needed for the new version.

---

## Development Workflow (Old)

```bash
# Clone & setup
git clone <repo>
cd legacy/chat
npm install

# Development
npm run dev
# Open http://localhost:5173

# Build & preview
npm run build
npm run preview

# Deploy
git add .
git commit -m "..."
git push origin main
# (Netlify auto-deploys)
```

---

## Migration Checklist

When rebuilding, consider:

- [ ] **Frontend Framework**: Keep React or switch (Vue, Svelte, etc.)?
- [ ] **Build Tool**: Keep Vite or migrate (Next.js, remix, etc.)?
- [ ] **LLM Integration**: Keep direct API calls or add backend server?
- [ ] **Hosting**: Keep Netlify or migrate (Vercel, AWS, custom)?
- [ ] **Styling**: Keep Tailwind CDN or install as dev dependency?
- [ ] **API Key Security**: Expose to browser or proxy through backend?
- [ ] **Card System**: Re-host cards or build custom documentation?
- [ ] **SEO**: Add meta tags and structured data if switching from static SPA.

---

## Key Files & Locations (in `legacy/`)

- `chat/package.json` — Frontend dependencies
- `chat/vite.config.ts` — Vite configuration
- `chat/src/services/geminiService.ts` — LLM integration
- `chat/src/App.tsx` — Main chat component
- `netlify.toml` — Deployment configuration
- `decks/` — Card system documentation
- `docs/` — Foundation documentation

All are archived under `legacy/` for reference.

---

## Getting Help

- **React**: https://react.dev
- **Vite**: https://vitejs.dev
- **Google Generative AI SDK**: https://ai.google.dev/docs
- **Netlify Docs**: https://docs.netlify.com
- **Tailwind CSS**: https://tailwindcss.com

---

**Last Updated**: February 28, 2026  
**Status**: Retired (archived for reference)
