# Archive & Reference

This folder contains pointers to all legacy documentation and code.

## Key Legacy Locations

All original code, configs, and documentation are in `../legacy/`:

### Frontend Code
- **`../legacy/chat/`** — React + Vite chat application
  - `src/App.tsx` — Main chat component
  - `src/services/geminiService.ts` — Google Generative AI integration
  - `src/components/` — UI components (ChatMessage, etc.)
  - `package.json` — Dependencies & build scripts
  - `vite.config.ts` — Vite bundler configuration

### Backend Configuration
- **`../legacy/netlify.toml`** — Netlify deployment config (SPA routing, headers)
- **`../legacy/chat/.env.local.example`** — Environment setup (VITE_GOOGLE_API_KEY)

### Documentation & Cards
- **`../legacy/decks/`** — νóησις card system (Markdown-based)
  - `exploration/` — Conversation grounding cards
  - `engineering/` — System design decks (emergence & canonical)
  - `templates/` — Blank templates for creating new decks
- **`../legacy/docs/`** — Foundation and project documentation
  - `docs/foundation/POLICY.md` — Governance & rules
  - `docs/foundation/SEED_SPEC.md` — Card seeding system
  - `docs/guides/GRAPH_VIEWER_README.md` — Tool for visualizing card relationships
- **`../legacy/tools/`** — Utility scripts
  - `seed-generator.py` — Cryptographic seeding for cards
  - `view-graph.py` — Graph visualization
  - `noesis-graph-viewer.py` — Full graph viewer

### Build Artifacts
- **`../legacy/chat/dist/`** — Previously built frontend (can refer for output structure)
- **`../legacy/site/`** — Static documentation site (if converted from Markdown)

## How to Use This Archive

### For Understanding the Old Stack

Read in this order:
1. `STACK.md` (in this directory) — Overview of all tech
2. `../legacy/chat/package.json` — Exact dependencies
3. `../legacy/chat/src/services/geminiService.ts` — LLM integration
4. `../legacy/netlify.toml` — Deployment setup

### For Copying Code

If rebuilding with React + Vite:
```bash
# Copy the chat app as a starting point
cp -r ../legacy/chat frontend/
cd frontend && npm install && npm run dev
```

Then modify/customize as needed.

### For Understanding the Card System

If rebuilding with card documentation:
1. Browse `../legacy/decks/engineering/canonical-v1.0/cards/` to see the format
2. Refer to `../legacy/docs/foundation/SEED_SPEC.md` to understand seeding
3. Use `../legacy/tools/noesis-graph-viewer.py` to visualize relationships

## What NOT to Do

- ❌ Don't rely on the built artifacts in `../legacy/chat/dist/` — rebuild with your stack
- ❌ Don't copy `node_modules` — run `npm install` in your environment
- ❌ Don't assume the exact same API key structure — re-configure for your deployment

## What You CAN Reuse

- ✅ React components from `src/components/`
- ✅ The Gemini service pattern from `services/geminiService.ts`
- ✅ Tailwind styles and CSS patterns
- ✅ Card system content (if keeping it)
- ✅ Netlify routing configuration (SPA redirects)

## Quick Copy-Paste Patterns

### Chat Service Integration (TypeScript)

```typescript
import { GoogleGenerativeAI } from "@google/genai";

const genAI = new GoogleGenerativeAI(import.meta.env.VITE_GOOGLE_API_KEY);

export async function sendMessageToGemini(messages) {
  const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });
  const result = await model.generateContent({
    contents: messages,
    systemInstruction: "You are a helpful assistant."
  });
  return result.response.text();
}
```

### Vite + React Setup

```bash
npm create vite@latest frontend -- --template react
cd frontend
npm install
npm install --save-dev @vitejs/plugin-react typescript
npm run dev
```

### Netlify Redirect Config

```toml
[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

## Still Have Questions?

1. **About the old tech?** Read `STACK.md`
2. **About deploying?** Check `../legacy/netlify.toml` and Netlify docs
3. **About cards?** Read `../legacy/docs/foundation/POLICY.md`
4. **About building?** Look at `../legacy/chat/vite.config.ts`

---

**Archive Created**: February 28, 2026  
**All files in `../legacy/` are read-only for reference**
