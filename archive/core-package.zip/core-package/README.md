# Core backend/frontend package

This directory is intentionally minimal. It represents the **entry point** for whoever inherits the project and needs to rebuild or re-implement the public website.

The structure here should be populated with whatever backend service, API definitions, and frontend assets the new developer requires. For now it is just a placeholder to make handoff clear.

Suggested contents:

`
core-package/
+-- backend/            # Node/Express, Python/Flask, etc. service code
+-- frontend/           # React/Vite or static HTML/CSS/JS
+-- README.md           # (this file) describe how to start/build
+-- package.json        # dependencies for the package
+-- ...
`

**What to do next:**
1. Clone this repository (or copy the core-package/ folder).
2. Implement or import your preferred backend and frontend frameworks.
3. Remove this placeholder text and update the README with getting-started instructions.

All legacy code remains in ../legacy for reference; you need not touch it unless you want to inspect the old implementation.

Build and deployment of the retired site is no longer supported here; treat it as read-only archive.
