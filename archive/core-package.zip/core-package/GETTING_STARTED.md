# Core Package — Getting Started

This is the **handoff point** for rebuilding the retired νóησις application.

## What's Here

- **`STACK.md`** — Complete technology stack reference (React, Vite, Google GenAI, Netlify)
- **`README.md`** — This file; next steps for the new developer
- **`backend/`** — Directory for your backend service (Node, Python, Go, etc.)
- **`frontend/`** — Directory for your frontend code (React, Vue, Svelte, etc.)

## Quick Start

### Option 1: Rebuild with Same Stack (React + Vite)

If you want to use the same frontend framework:

```bash
cd frontend
npm init -y
npm install react react-dom vite @vitejs/plugin-react typescript
npm install -D @types/node @types/react @types/react-dom
npm run dev
```

Then copy the React components from `legacy/chat/src/` as a reference.

### Option 2: Start Fresh

Choose your own framework:

- **React + Next.js** → better SEO, built-in backend route support
- **Vue + Nuxt** → simpler syntax, excellent docs
- **Svelte + SvelteKit** → smallest bundle, reactive by default
- **Astro** → static-first, great for markdown content (card system)
- **Plain HTML/CSS/JS** → no dependencies, maximum simplicity

### Option 3: Use the Legacy Chat App

Copy the working chat app from the archive:

```bash
cp -r ../legacy/chat/* ./frontend/
cd frontend
npm install
npm run dev
```

This gives you a functioning chat app immediately; customize from there.

## Architecture Decision

Before you start, decide:

1. **Frontend framework** — React (recommended for familiarity) or something else?
2. **Backend approach**:
   - Keep client-side (direct API calls to Google Generative AI) — **simplest**
   - Add a backend server for API key security & custom logic — **more secure**
3. **Hosting** — Netlify (same as before), Vercel, AWS, Docker, etc.?

See `STACK.md` for detailed options under each section.

## Tech Stack Reference

| Layer | Old | Recommended | Alternative |
|-------|-----|-------------|-------------|
| **Hosting** | Netlify | Vercel, Netlify | AWS Amplify, Railway |
| **Frontend** | React 19 + Vite | React + Next.js, Vue + Nuxt | Svelte, Astro, Angular |
| **Styling** | Tailwind CDN | Tailwind + PostCSS | Bootstrap, UnoCSS, Pico |
| **LLM** | Google GenAI (direct) | Backend proxy + Google GenAI | OpenAI, Anthropic, local Ollama |
| **Database** | None | Firebase, MongoDB, PostgreSQL | SQLite, DynamoDB |
| **Auth** | None | Auth0, Clerk, Firebase Auth | Cognito, NextAuth.js |

## Environment Setup

### Prerequisites

- Node.js 18+ (or 20+)
- npm or yarn or pnpm
- Git
- A Google Generative AI API key (if using Google models)

### First Steps

1. **Install Node.js**:
   ```bash
   # macOS
   brew install node
   
   # Windows (via choco)
   choco install nodejs
   
   # Linux
   curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
   sudo apt install nodejs
   ```

2. **Get API Keys**:
   - Google Generative AI: https://ai.google.dev (free tier available)
   - Other providers: OpenAI, Anthropic, etc. (links in `STACK.md`)

3. **Set up environment**:
   ```bash
   echo "VITE_GOOGLE_API_KEY=your-key-here" > frontend/.env.local
   ```

4. **Install & run**:
   ```bash
   cd frontend
   npm install
   npm run dev
   ```

## Git Workflow

Once you've picked your approach:

```bash
# Initialize your frontend
cd core-package/frontend
npm init -y && npm install

# Commit changes
git add .
git commit -m "Initialize new frontend with [framework]"
git push origin main

# Netlify will auto-deploy on push (if configured)
```

## Deployment

### Netlify (Same as Before)

1. Push code to GitHub/GitLab
2. Link repo in Netlify dashboard
3. Set build command: `npm run build`
4. Set publish directory: `dist/` (or `.next/`, `.svelte-kit/`, etc.)
5. Add environment variables in Netlify Settings

### Other Hosting

See `STACK.md` for platform-specific instructions.

## Reference Materials

All legacy code is preserved in `../legacy/`:

- `legacy/chat/` — Full React chat app source
- `legacy/decks/` — Card system (Markdown)
- `legacy/docs/` — Documentation
- `legacy/tools/` — Utility scripts

Use as reference or copy pieces you want to reuse.

## Questions?

Refer to:
- **`STACK.md`** for full tech stack details
- **`legacy/README.md`** for original project overview
- **`legacy/chat/README.md`** for chat app specifics
- Framework docs (React, Vite, etc.)

## Next: What to Do Now

1. Read `STACK.md` to understand the old setup
2. Decide on your frontend framework & backend approach
3. Scaffold your project in `frontend/` and `backend/`
4. Copy components/logic from `legacy/chat/` as needed
5. Test locally (`npm run dev`)
6. Configure Netlify or your hosting platform
7. Push to Git & deploy

Good luck rebuilding! 🚀
