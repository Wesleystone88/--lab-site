# CARD-3 — Constraints
Purpose: Define physical, legal, and operational limits.
Gate: ERROR if conflicts unresolved.
