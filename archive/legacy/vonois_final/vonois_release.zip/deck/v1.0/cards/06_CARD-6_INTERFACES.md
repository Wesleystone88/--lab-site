# CARD-6 — Interfaces
Purpose: Define communication contracts.
Gate: ERROR if ambiguous.
