# CARD-4 — Structure
Purpose: Define components and interactions.
Gate: ERROR if responsibilities undefined.
