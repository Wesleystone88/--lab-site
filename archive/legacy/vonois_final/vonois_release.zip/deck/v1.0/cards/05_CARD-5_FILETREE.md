# CARD-5 — File / Asset Tree
Purpose: Translate structure into layout.
Gate: ERROR if mismatched with structure.
