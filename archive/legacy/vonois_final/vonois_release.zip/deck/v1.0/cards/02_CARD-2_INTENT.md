# CARD-2 — Intent
Purpose: Define operational goals and non-goals.
Gate: ERROR if success criteria missing.
