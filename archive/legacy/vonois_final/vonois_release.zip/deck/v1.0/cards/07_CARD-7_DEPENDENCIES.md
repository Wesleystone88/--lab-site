# CARD-7 — Dependencies
Purpose: Document external coupling risks.
Gate: ERROR if critical dependency unmitigated.
