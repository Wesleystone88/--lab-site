# CARD-1 — Write-Up
Purpose: Capture narrative, motivation, examples, and risks.
Gate: ERROR if empty.
