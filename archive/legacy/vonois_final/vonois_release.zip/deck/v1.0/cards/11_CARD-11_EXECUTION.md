# CARD-11 — Execution
Purpose: Build plan and validation strategy.
Gate: ERROR if violates upstream constraints.
