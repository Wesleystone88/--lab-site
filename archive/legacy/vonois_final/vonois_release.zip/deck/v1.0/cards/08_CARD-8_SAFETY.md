# CARD-8 — Safety & Security
Purpose: Threat modeling and mitigation.
Gate: ERROR if critical threat unmitigated.
