# CARD-0 — Package
Purpose: Define domain envelope and rigor expectations.
Gate: Must exist before any other card.
