# CARD-9 — Failure & Recovery
Purpose: Define failure handling.
Gate: ERROR if no recovery path.
