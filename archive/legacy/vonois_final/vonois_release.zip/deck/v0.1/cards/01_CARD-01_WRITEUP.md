# CARD-01 — Write-Up
Purpose: Capture raw narrative and motivation.
Content includes problem story, examples, risks, assumptions, non-goals.
Gate: ERROR if empty or fewer than 3 examples.
