# CARD-08 — Safety Model
Purpose: Prevent drift and misuse.
Gate: ERROR if no threats listed.
