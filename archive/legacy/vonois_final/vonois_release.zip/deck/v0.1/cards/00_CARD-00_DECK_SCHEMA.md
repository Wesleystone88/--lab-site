# CARD-00 — Deck Schema
Purpose: Defines what a card is, ordering, validation, and LLM interaction rules.
Rules:
- Cards contain full specifications.
- Ordering must be respected.
- Humans own decisions.
Gate: ERROR if required sections missing.
