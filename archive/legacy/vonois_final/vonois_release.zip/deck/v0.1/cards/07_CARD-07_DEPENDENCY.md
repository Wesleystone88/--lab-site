# CARD-07 — Dependency Contract
Purpose: Declare external assumptions.
Gate: ERROR if mandatory dependency introduced.
