# CARD-06 — Data Contract
Purpose: Define card and deck data structure.
Gate: ERROR if non-portable formats required.
