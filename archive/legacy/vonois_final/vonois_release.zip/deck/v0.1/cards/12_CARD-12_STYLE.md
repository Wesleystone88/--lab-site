# CARD-12 — Style & Practices
Purpose: Maintain clarity and rigor.
Gate: INFO if style drift detected.
