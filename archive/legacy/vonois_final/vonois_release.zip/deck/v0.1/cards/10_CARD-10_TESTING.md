# CARD-10 — Testing Strategy
Purpose: Validate consistency and correctness.
Gate: WARNING if no review process.
