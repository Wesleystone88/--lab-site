# CARD-02 — Intent
Purpose: Convert narrative into explicit objectives and success criteria.
Gate: ERROR if objectives lack measurable success criteria.
