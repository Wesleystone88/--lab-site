# CARD-11 — Deployment Model
Purpose: Define how the deck is shared.
Gate: WARNING if unclear.
