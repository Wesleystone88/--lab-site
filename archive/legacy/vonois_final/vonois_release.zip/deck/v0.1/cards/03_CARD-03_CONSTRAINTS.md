# CARD-03 — Constraints
Purpose: Define immutable laws and system limits.
Gate: ERROR if fewer than 3 invariants.
