# CARD-04 — Architecture
Purpose: Define conceptual structure and flow.
Gate: ERROR if flow unclear.
