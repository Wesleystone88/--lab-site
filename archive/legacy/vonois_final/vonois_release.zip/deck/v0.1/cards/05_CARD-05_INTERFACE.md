# CARD-05 — Interface Contract
Purpose: Define how humans and tools interact with the deck.
Gate: ERROR if interaction unclear.
