# CARD-09 — Project Topology
Purpose: Define how cards are organized.
Gate: WARNING if layout unclear.
