
# PACKAGE (Envelope — Context Selector, NOT a Card)

Owner:
DeckMode: v0.1 | v1.0

PackageType:
ExecutionMode:
Distribution:
Longevity:
ComplianceScope:

OutputsEnabled:
- [ ] Code
- [ ] Documentation
- [ ] Models
- [ ] Experiments
- [ ] Schematics
- [ ] Other

Notes:
