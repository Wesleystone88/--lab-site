# vóṇōs Artifact Deck v1.0 — System Design Mode
Owner: Timothy Wesley Stone

CARDS:
CARD-0 Package
CARD-1 Write-Up
CARD-2 Intent
CARD-3 Constraints
CARD-4 Structure
CARD-5 File Tree
CARD-6 Interfaces
CARD-7 Dependencies
CARD-8 Safety
CARD-9 Failure & Recovery
CARD-10 Evolution & Scaling
CARD-11 Execution
