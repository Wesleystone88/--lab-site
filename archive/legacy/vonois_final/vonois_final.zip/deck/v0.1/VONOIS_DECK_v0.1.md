# vónoįs Artifact Deck v0.1 — Execution Mode
Owner: Timothy Wesley Stone

CARDS:
CARD-00 Deck Schema
CARD-01 Write-Up
CARD-02 Intent
CARD-03 Constraints
CARD-04 Architecture
CARD-05 Interface Contract
CARD-06 Data Contract
CARD-07 Dependency Contract
CARD-08 Safety Model
CARD-09 Project Topology
CARD-10 Testing Strategy
CARD-11 Deployment Model
CARD-12 Style & Practices
CARD-13 Implementation
