# CARD-XX — <NAME>
CardID:
CardName:
Version:
Status:
Owner:
UpstreamCards:
DownstreamCards:

Purpose:

Inputs:

Outputs:

Content:

Gate:

Notes:
