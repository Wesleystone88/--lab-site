# PACKAGE (Domain Envelope) — TEMPLATE
PackageType: <Software | Research | Hardware | Knowledge | Simulation | Other>

OutputsEnabled:
- [ ] Code
- [ ] Documentation
- [ ] Models
- [ ] Experiments
- [ ] Schematics
- [ ] Other

Notes:
-

Gate:
- PACKAGE must be declared before CARD-01 exists.
