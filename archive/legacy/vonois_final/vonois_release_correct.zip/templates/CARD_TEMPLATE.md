# CARD-XX — <NAME> — TEMPLATE
CardID: CARD-XX
CardName: <Name>
Version: <x.y>
Status: draft | locked
Owner: Timothy Wesley Stone
UpstreamCards: []
DownstreamCards: []

Purpose:
-

Inputs:
-

Outputs:
-

Content:
-

Gate:
- ERROR / WARNING / INFO rules
