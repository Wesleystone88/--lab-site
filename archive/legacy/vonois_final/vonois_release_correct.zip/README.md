# vónoįs / vóṇōs Artifact Decks

This release includes:
- **v0.1** (lightweight, “keep the LLM organized while coding”)
- **v1.0** (deep structural engineering deck for system design)

Each deck is provided as:
- a single master markdown file
- individual per-card markdown files (true portable artifacts)
- templates for PACKAGE and CARD authoring

Author: Timothy Wesley Stone
License: Open / Shareable
