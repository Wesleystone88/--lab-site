# CARD-09 — PROJECT TOPOLOGY

CardID: CARD-09
CardName: Project Topology
Version: 0.1
Status: draft
Owner: Timothy Wesley Stone
UpstreamCards: [CARD-08]
DownstreamCards: [CARD-10]

Purpose:
Define how cards are organized.

Content:
- Single file or folder of cards
- Numeric prefixes preserve order

Gate:
- WARNING if layout unclear.
