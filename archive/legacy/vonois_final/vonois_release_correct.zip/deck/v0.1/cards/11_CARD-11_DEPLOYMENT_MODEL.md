# CARD-11 — DEPLOYMENT MODEL

CardID: CARD-11
CardName: Deployment Model
Version: 0.1
Status: draft
Owner: Timothy Wesley Stone
UpstreamCards: [CARD-10]
DownstreamCards: [CARD-12]

Purpose:
Define how deck is shared.

Content:
- Git
- Gist
- PDF
- Copy/paste

Gate:
- WARNING if sharing path unclear.
