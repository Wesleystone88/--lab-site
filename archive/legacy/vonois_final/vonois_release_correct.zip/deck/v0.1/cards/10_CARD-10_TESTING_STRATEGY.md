# CARD-10 — TESTING STRATEGY

CardID: CARD-10
CardName: Testing Strategy
Version: 0.1
Status: draft
Owner: Timothy Wesley Stone
UpstreamCards: [CARD-09]
DownstreamCards: [CARD-11]

Purpose:
Validate correctness manually or with tools.

Content:
Checklist review of cards and consistency.

Gate:
- WARNING if no review process.
