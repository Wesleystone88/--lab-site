CARD-2 — INTENT (Operational Goal)
Purpose:
Convert narrative into executable purpose and boundaries.
Contains objectives, non-goals, success criteria, exclusions.
Gate:
Must be internally consistent.
