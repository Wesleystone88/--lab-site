CARD-11 — EXECUTION
Purpose:
Translate specification into action.
Contains milestones, validation, testing.
Gate:
Must honor all upstream cards.
