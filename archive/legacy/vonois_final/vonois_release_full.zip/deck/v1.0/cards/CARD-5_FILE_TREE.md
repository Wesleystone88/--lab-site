CARD-5 — FILE / ASSET TREE
Purpose:
Translate structure into tangible organization.
Contains directory layout, naming, versioning.
Gate:
Must reflect CARD-4.
