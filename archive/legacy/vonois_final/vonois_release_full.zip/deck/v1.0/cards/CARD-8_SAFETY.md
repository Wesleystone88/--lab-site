CARD-8 — SAFETY & SECURITY
Purpose:
Prevent harm, abuse, leakage.
Contains threat model, mitigations, audits.
Gate:
Unmitigated critical risks prohibited.
