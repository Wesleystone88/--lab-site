CARD-3 — CONSTRAINTS (System Physics)
Purpose:
Define immutable realities governing the system.
Contains budget, time, compute, regulatory limits.
Gate:
Must be respected by downstream cards.
