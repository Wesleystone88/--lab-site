CARD-9 — FAILURE & RECOVERY
Purpose:
Define failure and healing behavior.
Contains detection, rollback, recovery paths.
Gate:
Critical failures must have recovery.
