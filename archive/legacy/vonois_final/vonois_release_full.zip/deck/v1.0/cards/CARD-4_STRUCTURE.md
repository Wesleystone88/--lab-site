CARD-4 — STRUCTURE (System Topology)
Purpose:
Define what exists and how it connects.
Contains components, flows, trust boundaries.
Gate:
No undefined responsibilities.
