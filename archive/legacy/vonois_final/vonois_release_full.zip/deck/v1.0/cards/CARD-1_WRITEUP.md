CARD-1 — WRITE-UP (Narrative Anchor)
Purpose:
Capture the raw human story before formalization.
Contains narrative, risks, motivations, and examples.
Gate:
Must exist before CARD-2.
