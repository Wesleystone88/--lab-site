CARD-7 — DEPENDENCIES
Purpose:
Expose external reliance and fragility.
Contains libraries, services, risks, replacements.
Gate:
All dependencies justified.
