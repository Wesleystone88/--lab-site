CARD-6 — INTERFACES / API
Purpose:
Define all communication boundaries.
Contains schemas, errors, auth, versioning.
Gate:
No ambiguous interfaces.
