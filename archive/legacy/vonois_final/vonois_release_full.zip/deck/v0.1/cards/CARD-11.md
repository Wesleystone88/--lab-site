Template for CARD-11
Fill full specification here.
