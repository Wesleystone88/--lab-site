Template for CARD-10
Fill full specification here.
