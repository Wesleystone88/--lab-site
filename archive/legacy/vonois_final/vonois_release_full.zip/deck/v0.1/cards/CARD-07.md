Template for CARD-07
Fill full specification here.
