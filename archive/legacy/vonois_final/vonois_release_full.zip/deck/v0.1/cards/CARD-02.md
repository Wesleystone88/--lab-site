Template for CARD-02
Fill full specification here.
