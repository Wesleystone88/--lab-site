Template for CARD-09
Fill full specification here.
