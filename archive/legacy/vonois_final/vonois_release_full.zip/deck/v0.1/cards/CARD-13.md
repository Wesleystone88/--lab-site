Template for CARD-13
Fill full specification here.
