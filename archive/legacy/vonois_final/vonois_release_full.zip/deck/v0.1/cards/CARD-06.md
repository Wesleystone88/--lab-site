Template for CARD-06
Fill full specification here.
