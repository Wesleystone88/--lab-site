Template for CARD-04
Fill full specification here.
