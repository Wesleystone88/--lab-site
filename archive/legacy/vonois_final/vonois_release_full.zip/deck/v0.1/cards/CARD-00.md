Template for CARD-00
Fill full specification here.
