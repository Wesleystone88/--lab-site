Template for CARD-01
Fill full specification here.
