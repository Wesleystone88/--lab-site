Template for CARD-08
Fill full specification here.
