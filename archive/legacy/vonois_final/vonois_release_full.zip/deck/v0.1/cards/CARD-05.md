Template for CARD-05
Fill full specification here.
