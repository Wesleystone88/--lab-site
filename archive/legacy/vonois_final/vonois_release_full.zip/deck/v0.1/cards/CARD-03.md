Template for CARD-03
Fill full specification here.
