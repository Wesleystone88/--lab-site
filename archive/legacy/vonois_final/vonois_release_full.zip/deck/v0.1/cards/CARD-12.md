Template for CARD-12
Fill full specification here.
