CARD TEMPLATE
Purpose:
Inputs:
Outputs:
Content:
Gate:
