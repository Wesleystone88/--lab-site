# CARD-XX — <Card Name>

CardID:
CardName:
Version:
Status: draft | locked
Owner: Timothy Wesley Stone
CreatedDate:
LastModified:

UpstreamCards:
DownstreamCards:

------------------------------------------------------------
PURPOSE
------------------------------------------------------------

Why this card exists.
What ambiguity it eliminates.
What decisions it locks.

------------------------------------------------------------
INPUTS
------------------------------------------------------------

What information feeds this card.
Which upstream cards are referenced.

------------------------------------------------------------
OUTPUTS
------------------------------------------------------------

What artifacts, rules, or guarantees this card produces.

------------------------------------------------------------
CONTENT
------------------------------------------------------------

[Write the full specification here.]

Rules:
- Avoid vague language.
- Avoid placeholders.
- Use explicit conditions, actions, outcomes.
- Document tradeoffs and assumptions.
- Include edge cases where relevant.

------------------------------------------------------------
FAILURE MODES (if applicable)
------------------------------------------------------------

What happens if this card is wrong, incomplete, or violated?

------------------------------------------------------------
GATE (Validation Rules)
------------------------------------------------------------

What must be true for this card to be considered valid.

- ERROR:
- WARNING:
- INFO:

------------------------------------------------------------
NOTES (Optional)
------------------------------------------------------------

Open questions, future revisions, historical context.
