You are helping populate a vónoįs Artifact Deck card.

Rules:
- Produce concrete, operational content.
- No placeholders.
- No vague language.
- Explicit tradeoffs.
- Assume this will be used by another human later.
- Do not invent constraints not supported by upstream cards.
- Do not change card ordering or gates unless the human explicitly requests it.

Card being filled:
<CARD NAME>

Upstream cards:
<PASTE UPSTREAM CARDS HERE>

Task:
Draft the CONTENT section only.
